package com.hdstream.live.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hdstream.live.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class StreamRepository(private val context: Context? = null) {

    var cloudApiBaseUrl: String = "https://stream-admin-backend.vercel.app"

    private val _feedState = MutableStateFlow<MobileFeedResponse?>(null)
    val feedState: StateFlow<MobileFeedResponse?> = _feedState.asStateFlow()

    private val gson = Gson()
    private val PREFS_NAME = "hd_stream_feed_cache"
    private val KEY_CACHED_FEED = "cached_feed_json"

    // Remote GitHub Raw & CDN Endpoints (Zero APK Update Architecture)
    private val githubLiveMatchesUrls = listOf(
        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/live_matches.json",
        "https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/data/live_matches.json"
    )

    private val githubCategoriesUrls = listOf(
        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/categories.json",
        "https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/data/categories.json"
    )

    init {
        // Fast instant boot from SharedPreferences local cache
        loadFromLocalCache()
        if (_feedState.value == null) {
            _feedState.value = getOfficialDefaultFeed()
        }
    }

    private fun loadFromLocalCache() {
        if (context == null) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(KEY_CACHED_FEED, null)
            if (!json.isNullOrBlank()) {
                val cached = gson.fromJson(json, MobileFeedResponse::class.java)
                if (cached != null) {
                    _feedState.value = cached
                }
            }
        } catch (_: Exception) {}
    }

    private fun saveToLocalCache(feed: MobileFeedResponse) {
        if (context == null) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = gson.toJson(feed)
            prefs.edit().putString(KEY_CACHED_FEED, json).apply()
        } catch (_: Exception) {}
    }

    private fun httpGet(urlStr: String, timeoutMs: Int = 4500): String? {
        var curUrl = urlStr
        var redirects = 0
        while (redirects < 5) {
            try {
                val url = URL(curUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = timeoutMs
                conn.readTimeout = timeoutMs
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; HDStream/3.2.2)")
                conn.setRequestProperty("Accept", "*/*")
                conn.setRequestProperty("Cache-Control", "no-cache")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        curUrl = loc
                        redirects++
                        continue
                    }
                }
                if (code in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val content = reader.readText()
                    reader.close()
                    return content
                }
                return null
            } catch (_: Exception) {
                return null
            }
        }
        return null
    }

    companion object {
        fun getTeamFlagUrl(teamName: String): String {
            val t = teamName.lowercase().trim()
            return when {
                t.contains("india") || t == "ind" -> "https://flagcdn.com/w160/in.png"
                t.contains("new zealand") || t.contains("zealand") || t == "nz" -> "https://flagcdn.com/w160/nz.png"
                t.contains("australia") || t == "aus" -> "https://flagcdn.com/w160/au.png"
                t.contains("england") || t == "eng" -> "https://flagcdn.com/w160/gb-eng.png"
                t.contains("pakistan") || t == "pak" -> "https://flagcdn.com/w160/pk.png"
                t.contains("south africa") || t == "sa" -> "https://flagcdn.com/w160/za.png"
                t.contains("bangladesh") || t == "ban" || t == "bd" -> "https://flagcdn.com/w160/bd.png"
                t.contains("sri lanka") || t == "sl" || t == "lk" -> "https://flagcdn.com/w160/lk.png"
                t.contains("afghanistan") || t == "afg" -> "https://flagcdn.com/w160/af.png"
                t.contains("nepal") || t == "nep" || t == "npl" -> "https://flagcdn.com/w160/np.png"
                t.contains("west indies") || t == "wi" -> "https://flagcdn.com/w160/jm.png"
                t.contains("zimbabwe") || t == "zim" -> "https://flagcdn.com/w160/zw.png"
                t.contains("ireland") || t == "ire" -> "https://flagcdn.com/w160/ie.png"
                t.contains("scotland") || t == "sco" -> "https://flagcdn.com/w160/gb-sct.png"
                t.contains("netherlands") || t == "ned" -> "https://flagcdn.com/w160/nl.png"
                t.contains("usa") || t.contains("united states") -> "https://flagcdn.com/w160/us.png"
                t.contains("canada") || t == "can" -> "https://flagcdn.com/w160/ca.png"
                else -> ""
            }
        }
    }

    private fun mapMatchItem(m: GDriveMatchItem, defaultStatus: String, index: Int): LiveStreamEvent {
        val title = (m.matchName ?: m.title ?: "Live Match ${index + 1}").trim()
        val status = (m.status ?: defaultStatus).uppercase()
        var team1Name = m.team1Obj?.name ?: m.teamAObj?.name ?: m.team1Name ?: ""
        var team2Name = m.team2Obj?.name ?: m.teamBObj?.name ?: m.team2Name ?: ""
        if (team1Name.isBlank() && team2Name.isBlank()) {
            if (title.contains(" vs ", ignoreCase = true)) {
                val parts = title.split(Regex(" vs ", RegexOption.IGNORE_CASE))
                team1Name = parts.getOrNull(0)?.trim() ?: "Team 1"
                team2Name = parts.getOrNull(1)?.trim() ?: "Team 2"
            } else if (title.contains(" - ")) {
                val parts = title.split(" - ")
                team1Name = parts.getOrNull(0)?.trim() ?: "Team 1"
                team2Name = parts.getOrNull(1)?.trim() ?: "Team 2"
            } else {
                team1Name = title
                team2Name = "Opponent"
            }
        }
        if (team1Name.isBlank()) team1Name = "Team 1"
        if (team2Name.isBlank()) team2Name = "Team 2"

        val streams = (m.streams ?: emptyList()).mapIndexed { sIdx, s ->
            val rawUrl = (s.url ?: "").trim()
            val streamUrl = if (rawUrl.startsWith("http")) rawUrl else "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
            val isMpd = (s.type ?: "").equals("mpd", ignoreCase = true) || streamUrl.contains(".mpd")
            val isHls = (s.type ?: "").equals("hls", ignoreCase = true) || streamUrl.contains(".m3u8")
            val streamType = if (isMpd) "MPD" else if (isHls) "M3U8" else "DIRECT"
            StreamSource(
                id = "stream_${index}_$sIdx",
                title = s.title ?: "Server ${sIdx + 1} HD",
                streamType = streamType,
                streamUrl = streamUrl,
                quality = "1080p HD",
                headers = mapOf("User-Agent" to "ExoPlayer-Media3/1.4.0")
            )
        }

        val flag1 = getTeamFlagUrl(team1Name)
        val flag2 = getTeamFlagUrl(team2Name)
        var t1Logo = if (flag1.isNotBlank()) flag1 else (m.team1Obj?.logo ?: m.teamAObj?.logo ?: m.team1Obj?.flag ?: m.teamAObj?.flag ?: m.team1Logo ?: "")
        var t2Logo = if (flag2.isNotBlank()) flag2 else (m.team2Obj?.logo ?: m.teamBObj?.logo ?: m.team2Obj?.flag ?: m.teamBObj?.flag ?: m.team2Logo ?: "")

        if (t1Logo.isBlank() || t1Logo.contains("wikimedia", ignoreCase = true)) {
            if (flag1.isNotBlank()) t1Logo = flag1
        }
        if (t2Logo.isBlank() || t2Logo.contains("wikimedia", ignoreCase = true)) {
            if (flag2.isNotBlank()) t2Logo = flag2
        }

        val t1Score = m.team1Obj?.score ?: m.teamAObj?.score ?: ""
        val t2Score = m.team2Obj?.score ?: m.teamBObj?.score ?: ""

        val matchTime = if (!m.time.isNullOrBlank() && !m.date.isNullOrBlank()) {
            "${m.time} • ${m.date}"
        } else {
            m.time ?: m.date ?: "LIVE NOW"
        }

        val matchBanner = (m.banner ?: m.bannerUrlSnake ?: m.bannerUrlCamel ?: m.image ?: "").trim()

        return LiveStreamEvent(
            id = "event_${index}_${Math.abs(title.hashCode())}",
            title = title,
            category = m.category ?: "Live Cricket",
            status = status,
            startTime = matchTime,
            bannerUrl = matchBanner,
            description = m.result ?: "",
            team1 = TeamInfo(name = team1Name, shortName = team1Name.take(4).uppercase(), logo = t1Logo, score = t1Score),
            team2 = TeamInfo(name = team2Name, shortName = team2Name.take(4).uppercase(), logo = t2Logo, score = t2Score),
            totalStreams = streams.size,
            streams = streams
        )
    }

    suspend fun getFeed(): MobileFeedResponse = withContext(Dispatchers.IO) {
        // Step 1: Ensure initial memory state has local cache so UI is never blocked
        if (_feedState.value == null) {
            loadFromLocalCache()
        }

        // Step 2: Priority 1 -> Google Drive Direct Fetch (User Primary Live Event & Category Source)
        val driveFeed = fetchDirectFromGoogleDrive()
        if (driveFeed != null && (driveFeed.liveEvents.isNotEmpty() || driveFeed.categories.isNotEmpty())) {
            saveToLocalCache(driveFeed)
            _feedState.value = driveFeed
            return@withContext driveFeed
        }

        // Step 3: Priority 2 -> GitHub Raw / CDN Direct Fetch (Backup dynamic updates)
        val githubFeed = fetchFromGitHubRaw()
        if (githubFeed != null) {
            saveToLocalCache(githubFeed)
            _feedState.value = githubFeed
            return@withContext githubFeed
        }

        // Step 4: Priority 3 -> Return local cached state if available
        _feedState.value?.let { return@withContext it }

        // Step 5: Priority 4 -> Bundled default fallback
        val fallback = getOfficialDefaultFeed()
        _feedState.value = fallback
        fallback
    }

    suspend fun fetchFromGitHubRaw(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch Live Matches from GitHub
            var liveJson: String? = null
            for (url in githubLiveMatchesUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    liveJson = res
                    break
                }
            }

            if (liveJson.isNullOrBlank()) return@withContext null

            val liveResponse = try {
                gson.fromJson(liveJson, GDriveLiveFeedResponse::class.java)
            } catch (_: Exception) { null } ?: return@withContext null

            // 2. Fetch Categories from GitHub
            var catJson: String? = null
            for (url in githubCategoriesUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    catJson = res
                    break
                }
            }

            val parsedCategories: List<FeedCategory>? = if (!catJson.isNullOrBlank()) {
                val catType = object : TypeToken<List<FeedCategory>>() {}.type
                try { gson.fromJson(catJson, catType) } catch (_: Exception) { null }
            } else null

            val cleanCategories = parsedCategories?.mapIndexed { idx, c ->
                val name = c.displayName
                c.copy(
                    id = if (c.id.isNotBlank()) c.id else "gcat_${idx + 1}",
                    name = name,
                    slug = if (c.slug.isNotBlank()) c.slug else name.lowercase().replace(Regex("[^a-z0-9]+"), "-")
                )
            } ?: emptyList()

            val liveList = liveResponse.liveMatches?.mapIndexed { idx, it -> mapMatchItem(it, "LIVE", idx) } ?: emptyList()
            val upList = liveResponse.upcomingMatches?.mapIndexed { idx, it -> mapMatchItem(it, "UPCOMING", idx) } ?: emptyList()
            val finList = liveResponse.finishedMatches?.mapIndexed { idx, it -> mapMatchItem(it, "FINISHED", idx) } ?: emptyList()

            val official = getOfficialDefaultFeed()
            val announcementText = if (!liveResponse.announcement.isNullOrBlank()) liveResponse.announcement else official.appConfig.announcement
            val announcementEnabled = liveResponse.announcementEnabled ?: official.appConfig.announcementEnabled

            MobileFeedResponse(
                status = "success",
                timestamp = System.currentTimeMillis(),
                appConfig = official.appConfig.copy(
                    announcement = announcementText,
                    announcementEnabled = announcementEnabled
                ),
                categories = if (cleanCategories.isNotEmpty()) cleanCategories else official.categories,
                liveEvents = liveList,
                upcomingEvents = upList,
                recentEvents = finList,
                vodSection = official.vodSection
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun fetchDirectFromGoogleDrive(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch Categories from Google Drive (Primary User Source)
            val driveCatUrls = listOf(
                "https://drive.google.com/uc?export=download&id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO",
                "https://docs.google.com/uc?export=download&id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO",
                "https://drive.usercontent.google.com/download?id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO&export=download"
            )
            var catJson: String? = null
            for (url in driveCatUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    catJson = res
                    break
                }
            }

            val catType = object : TypeToken<List<FeedCategory>>() {}.type
            val parsedCategories: List<FeedCategory>? = if (!catJson.isNullOrBlank()) {
                try { gson.fromJson(catJson, catType) } catch (_: Exception) { null }
            } else null

            val cleanCategories = parsedCategories?.mapIndexed { idx, c ->
                val name = c.displayName
                c.copy(
                    id = if (c.id.isNotBlank()) c.id else "gcat_${idx + 1}",
                    name = name,
                    slug = if (c.slug.isNotBlank()) c.slug else name.lowercase().replace(Regex("[^a-z0-9]+"), "-")
                )
            } ?: emptyList()

            // 2. Fetch Live Events from Google Drive (Primary User Source)
            val driveLiveUrls = listOf(
                "https://drive.google.com/uc?export=download&id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu",
                "https://docs.google.com/uc?export=download&id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu",
                "https://drive.usercontent.google.com/download?id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu&export=download"
            )
            var liveJson: String? = null
            for (url in driveLiveUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    liveJson = res
                    break
                }
            }

            val driveLiveResponse = if (!liveJson.isNullOrBlank()) {
                try { gson.fromJson(liveJson, GDriveLiveFeedResponse::class.java) } catch (_: Exception) { null }
            } else null

            val allMatches = driveLiveResponse?.liveMatches ?: emptyList()
            val liveList = allMatches
                .filter { (it.status ?: "LIVE").equals("LIVE", ignoreCase = true) }
                .mapIndexed { idx, it -> mapMatchItem(it, "LIVE", idx) }
            val upList = (driveLiveResponse?.upcomingMatches ?: emptyList())
                .plus(allMatches.filter { (it.status ?: "").equals("UPCOMING", ignoreCase = true) })
                .mapIndexed { idx, it -> mapMatchItem(it, "UPCOMING", idx) }
            val finList = (driveLiveResponse?.finishedMatches ?: emptyList())
                .plus(allMatches.filter { (it.status ?: "").equals("FINISHED", ignoreCase = true) || (it.status ?: "").equals("ENDED", ignoreCase = true) })
                .mapIndexed { idx, it -> mapMatchItem(it, "FINISHED", idx) }

            if (cleanCategories.isEmpty() && liveList.isEmpty() && upList.isEmpty()) {
                return@withContext null
            }

            val official = getOfficialDefaultFeed()
            MobileFeedResponse(
                status = "success",
                timestamp = System.currentTimeMillis(),
                appConfig = official.appConfig,
                categories = if (cleanCategories.isNotEmpty()) cleanCategories else official.categories,
                liveEvents = if (liveList.isNotEmpty()) liveList else official.liveEvents,
                upcomingEvents = upList,
                recentEvents = finList,
                vodSection = official.vodSection
            )
        } catch (_: Exception) {
            null
        }
    }

    fun addCustomLiveEvent(event: LiveStreamEvent) {
        val current = _feedState.value ?: getOfficialDefaultFeed()
        val updatedEvents = listOf(event) + current.liveEvents.filter { it.id != event.id }
        _feedState.value = current.copy(liveEvents = updatedEvents)
        saveToLocalCache(_feedState.value!!)
    }

    fun addCustomLiveEvents(events: List<LiveStreamEvent>) {
        if (events.isEmpty()) return
        val current = _feedState.value ?: getOfficialDefaultFeed()
        val existingIds = events.map { it.id }.toSet()
        val updatedEvents = events + current.liveEvents.filter { !existingIds.contains(it.id) }
        _feedState.value = current.copy(liveEvents = updatedEvents)
        saveToLocalCache(_feedState.value!!)
    }

    suspend fun getMoviesFeed(context: android.content.Context? = null): List<CinexMovieItem> = withContext(Dispatchers.IO) {
        // 1. Try GitHub Raw data.json
        val ghMoviesJson = httpGet("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/cinex_movies.json")
        if (!ghMoviesJson.isNullOrBlank()) {
            try {
                val parsed = gson.fromJson(ghMoviesJson, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) return@withContext parsed.matches
            } catch (_: Exception) {}
        }

        // 2. Try cloud Vercel backend
        try {
            val endpoint = if (cloudApiBaseUrl.endsWith("/")) "${cloudApiBaseUrl}api/movies/data.json" else "$cloudApiBaseUrl/api/movies/data.json"
            val json = httpGet(endpoint)
            if (!json.isNullOrBlank()) {
                val parsed = gson.fromJson(json, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) return@withContext parsed.matches
            }
        } catch (_: Exception) {}

        // 3. Resilient fallback to bundled assets/cinex_movies.json (160+ Titles instant boot!)
        if (context != null) {
            try {
                val inputStream = context.assets.open("cinex_movies.json")
                val reader = BufferedReader(InputStreamReader(inputStream))
                val json = reader.readText()
                reader.close()
                val parsed = gson.fromJson(json, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) {
                    return@withContext parsed.matches
                }
            } catch (_: Exception) {}
        }

        emptyList()
    }

    fun getOfficialDefaultFeed(): MobileFeedResponse {
        val liveList = listOf(
            LiveStreamEvent(
                id = "event_default_live_cricket",
                title = "Live Cricket || India vs New Zealand",
                category = "Live Cricket",
                status = "LIVE",
                startTime = "7:00 AM",
                bannerUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=1200&auto=format&fit=crop",
                description = "",
                team1 = TeamInfo(name = "India", shortName = "IND", logo = "https://flagcdn.com/w160/in.png"),
                team2 = TeamInfo(name = "New Zealand", shortName = "NZ", logo = "https://flagcdn.com/w160/nz.png"),
                totalStreams = 2,
                streams = listOf(
                    StreamSource(
                        id = "stream_ind_nz_1",
                        title = "Server 1 - Hindi 1080p HD",
                        streamType = "M3U8",
                        streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                        quality = "1080p HD"
                    ),
                    StreamSource(
                        id = "stream_ind_nz_2",
                        title = "Server 2 - English 4K 60FPS",
                        streamType = "M3U8",
                        streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                        quality = "4K 60FPS"
                    )
                )
            )
        )
        val upcomingList = listOf(
            LiveStreamEvent(
                id = "event_default_up_cricket",
                title = "Live Cricket || Australia vs England",
                category = "Live Cricket",
                status = "UPCOMING",
                startTime = "1:30 PM",
                bannerUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=1200&auto=format&fit=crop",
                description = "",
                team1 = TeamInfo(name = "Australia", shortName = "AUS", logo = "https://flagcdn.com/w160/au.png"),
                team2 = TeamInfo(name = "England", shortName = "ENG", logo = "https://flagcdn.com/w160/gb-eng.png"),
                totalStreams = 1,
                streams = listOf(
                    StreamSource(
                        id = "stream_aus_eng_1",
                        title = "Server 1 - HD Stream",
                        streamType = "M3U8",
                        streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                        quality = "1080p HD"
                    )
                )
            )
        )

        val categoriesList = listOf(
            FeedCategory("gcat_0", "HD STREAM", "hd-stream", "tv", "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/logo.png", "https://cinexcricket.com/api/tv/data.json"),
            FeedCategory("gcat_1", "JIO TV+", "jio-tv", "tv", "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/logos/jiotv.png", "https://allinonereborn2.online/jiotv-m3u/jtv25.m3u8"),
            FeedCategory("gcat_3", "MIX TV", "mix-tv", "tv", "https://i.ibb.co/9vj6jqy/mixtv.png", "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/tv/mix.json"),
            FeedCategory("gcat_4", "VZY", "vzy", "tv", "https://i.ibb.co/m0f242m/vzy.png", "https://pastyx.pages.dev/api/paste/vzy-playlist-m3u/raw"),
            FeedCategory("gcat_5", "PAKISTAN TV", "pakistan-tv", "tv", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBLV9kgm97df5xLeoC-7i8uhp65boAZKw3__9QNW9WGYA0HHk7hS2MBvDa&s=10", "https://iptv-org.github.io/iptv/countries/pk.m3u"),
            FeedCategory("gcat_6", "TOFFEE", "toffee", "tv", "https://i.ibb.co/Wc6K87q/toffee.png", "https://iptv-org.github.io/iptv/languages/hin.m3u"),
            FeedCategory("gcat_7", "IRAN TV", "iran-tv", "tv", "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/logos/iran.png", "https://iptv-org.github.io/iptv/countries/ir.m3u"),
            FeedCategory("gcat_8", "Afghanistan TV", "afghanistan-tv", "tv", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-i-alUhNqSc08Q7HHJO2i7fCxKxZKBJCXfKf7QymkpmqVhEK4G75wQgs&s=10", "https://iptv-org.github.io/iptv/countries/af.m3u"),
            FeedCategory("gcat_9", "CARTOON MOVIE", "cartoon-movie", "tv", "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/logos/cartoon.png", "https://drive.google.com/uc?export=download&id=1UZ1M-R5Lx58Hi7qkbi5Ylnf8UirfRFPH"),
            FeedCategory("gcat_10", "MX PLAYER", "mx-player", "tv", "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/MX_Player_Logo.png/512px-MX_Player_Logo.png", "https://playlist-by-xfireflix.pages.dev/India/mxplayer"),
            FeedCategory("gcat_11", "YUPPY TV", "yuppy-tv", "tv", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/YuppTV_Logo.png/512px-YuppTV_Logo.png", "https://raw.githubusercontent.com/abusaeeidx/Yupptv-Playlist/refs/heads/main/playlist.m3u"),
            FeedCategory("gcat_12", "STALKER PORTAL LIVE", "stalker-portal", "tv", "https://i.ibb.co/4WH7p38/stalker.png", "http://134.119.176.239/stalker_portal/c/"),
            FeedCategory("gcat_13", "CINEX MOVIES", "cinex-movies", "film", "https://image.tmdb.org/t/p/w500/dswjf9LMu2DAffcvTBzqYK3pu10.jpg", "https://stream-admin-backend.vercel.app/api/movies/data.json")
        )

        val vodList = emptyList<VodShow>()

        return MobileFeedResponse(
            status = "success",
            timestamp = System.currentTimeMillis(),
            appConfig = AppConfig(
                appName = "HD STREAM",
                announcement = "🔴 HD STREAM is LIVE! ⚡ 24/7 Live Sports & Channels!",
                announcementEnabled = false,
                appVersion = "3.2.2",
                minVersion = "1.0.0",
                apkDownloadUrl = "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/HD-STREAM.apk",
                telegramLink = "https://t.me/livetvofficialapp"
            ),
            categories = categoriesList,
            liveEvents = liveList,
            upcomingEvents = upcomingList,
            recentEvents = emptyList(),
            vodSection = vodList
        )
    }
}
