package com.hdstream.live.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.hdstream.live.R
import com.hdstream.live.data.StreamRepository
import com.hdstream.live.model.*
import com.hdstream.live.util.DeviceUtils
import com.hdstream.live.player.M3uParser
import com.hdstream.live.player.ParsedChannelItem
import com.hdstream.live.ui.theme.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.BorderStroke
import com.hdstream.live.player.ExoPlayerHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    streamRepository: StreamRepository,
    onPlayStreamSource: (StreamSource, List<ParsedChannelItem>) -> Unit
) {
    val context = LocalContext.current
    val isTv = remember { DeviceUtils.isTv(context) }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val cachedFeed = remember { streamRepository.feedState.value ?: streamRepository.getOfficialDefaultFeed() }
    var feedData by remember { mutableStateOf(cachedFeed) }
    val liveFeedState by streamRepository.feedState.collectAsState()

    LaunchedEffect(liveFeedState) {
        liveFeedState?.let { feedData = it }
    }

    var selectedBottomTab by remember { mutableIntStateOf(0) } // Default: 0 (VIP Live Events Screen)
    var selectedSportsCategory by remember { mutableStateOf("All") }
    var selectedStatusFilter by remember { mutableStateOf("All") } // All, Live, Upcoming, Finished

    // Dialog State for "Multiple links available"
    var activeMatchForLinks by remember { mutableStateOf<LiveStreamEvent?>(null) }

    // Dialog State for "Custom Stream URL / M3U / DRM Player"
    var showStreamLinkDialog by remember { mutableStateOf(false) }

    // State for viewing Category Episodes (Screenshot 3)
    var activeCategoryForEpisodes by remember { mutableStateOf<FeedCategory?>(null) }

    // Search query state
    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    // Favorites state & storage (Rich Channel JSON + URL Set for instant lookup)
    val favoritePrefs = remember { context.getSharedPreferences("hd_favorites", Context.MODE_PRIVATE) }
    val gson = remember { com.google.gson.Gson() }
    val initialFavChannels = remember {
        val json = favoritePrefs.getString("fav_channels_json", null)
        val list = if (!json.isNullOrBlank()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<List<ParsedChannelItem>>() {}.type
                gson.fromJson<List<ParsedChannelItem>>(json, type) ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }
        list
    }
    var favoriteChannels by remember { mutableStateOf<List<ParsedChannelItem>>(initialFavChannels) }
    var favoriteUrls by remember {
        val setFromPrefs = favoritePrefs.getStringSet("fav_urls", emptySet())?.toSet() ?: emptySet()
        val setFromChannels = favoriteChannels.map { it.streamUrl }.toSet()
        mutableStateOf(setFromPrefs + setFromChannels)
    }
    var showFavoritesOnly by remember { mutableStateOf(false) }

    // Modals
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }
    var showAnnouncementDialog by remember { mutableStateOf(false) }

    // Direct Play Stream Handler (100% Ad-Free, Instant Playback)
    val handlePlayStreamWithAdCheck: (StreamSource, List<ParsedChannelItem>) -> Unit = { source, channels ->
        onPlayStreamSource(source, channels)
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current

    // Auto-refresh feed when screen opens or returns from background (ON_RESUME)
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                scope.launch {
                    try {
                        val freshFeed = streamRepository.getFeed()
                        feedData = freshFeed
                    } catch (_: Exception) {}
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(Unit) {
        try {
            val feed = streamRepository.getFeed()
            feedData = feed
        } catch (_: Exception) {}
    }

    // Auto-refresh when switching bottom tabs (VIP Live <-> Live Channels)
    LaunchedEffect(selectedBottomTab) {
        try {
            val feed = streamRepository.getFeed()
            feedData = feed
        } catch (_: Exception) {}
    }

    // BackHandlers to prevent app from accidentally closing when pressing back
    BackHandler(enabled = activeCategoryForEpisodes != null) {
        activeCategoryForEpisodes = null
    }

    BackHandler(enabled = activeCategoryForEpisodes == null && showFavoritesOnly) {
        showFavoritesOnly = false
    }

    var lastBackPressTime by remember { mutableLongStateOf(0L) }
    BackHandler(enabled = activeCategoryForEpisodes == null && !showFavoritesOnly) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastBackPressTime < 2000) {
            (context as? android.app.Activity)?.finish()
        } else {
            lastBackPressTime = currentTime
            Toast.makeText(context, "Press back again to exit HD STREAM", Toast.LENGTH_SHORT).show()
        }
    }

    val onToggleFavorite: (ParsedChannelItem) -> Unit = { channel ->
        val url = channel.streamUrl
        val isFav = favoriteUrls.contains(url)
        val newFavUrls = if (isFav) favoriteUrls - url else favoriteUrls + url
        val newFavChannels = if (isFav) {
            favoriteChannels.filter { it.streamUrl != url }
        } else {
            favoriteChannels.filter { it.streamUrl != url } + channel
        }
        favoriteUrls = newFavUrls
        favoriteChannels = newFavChannels

        favoritePrefs.edit()
            .putStringSet("fav_urls", newFavUrls)
            .putString("fav_channels_json", gson.toJson(newFavChannels))
            .apply()

        Toast.makeText(
            context,
            if (!isFav) "${channel.title} added to Favorites ❤️" else "${channel.title} removed from Favorites",
            Toast.LENGTH_SHORT
        ).show()
    }

    if (activeCategoryForEpisodes != null) {
        CategoryDetailView(
            category = activeCategoryForEpisodes!!,
            favoriteUrls = favoriteUrls,
            onToggleFavorite = onToggleFavorite,
            onPlayStreamSource = handlePlayStreamWithAdCheck,
            onBack = { activeCategoryForEpisodes = null }
        )
    } else {
        ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF121217),
                drawerContentColor = TextWhite
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF2B0E05), Color(0xFF121217))
                            )
                        )
                        .statusBarsPadding()
                        .padding(24.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo),
                        contentDescription = "HD STREAM Logo",
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(14.dp))
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "HD STREAM",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = OrangeTab
                    )
                    Text(
                        text = "Live Sports & Enterprise OTT v3.0",
                        fontSize = 12.sp,
                        color = TextGray
                    )
                }

                HorizontalDivider(color = Color(0xFF262626))

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Link, contentDescription = null, tint = OrangeTab) },
                    label = { Text("Play Custom M3U / Stream Link", color = TextWhite) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showStreamLinkDialog = true
                    }
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Favorite, contentDescription = null, tint = LiveRed) },
                    label = { Text(if (showFavoritesOnly) "Show All Channels" else "Show Favorite Channels Only", color = TextWhite) },
                    selected = showFavoritesOnly,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showFavoritesOnly = !showFavoritesOnly
                        Toast.makeText(context, if (showFavoritesOnly) "Showing Favorites ❤️" else "All Channels", Toast.LENGTH_SHORT).show()
                    }
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = UpcomingCyan) },
                    label = { Text("Reload Cloud Feed", color = TextWhite) },
                    selected = false,
                    onClick = {
                        scope.launch {
                            drawerState.close()
                            feedData = streamRepository.getFeed()
                            Toast.makeText(context, "Feed Updated!", Toast.LENGTH_SHORT).show()
                        }
                    }
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Send, contentDescription = null, tint = UpcomingCyan) },
                    label = { Text("Join Telegram Channel", color = TextWhite) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        try {
                            val tgUrl = if (feedData.appConfig.telegramLink.isNotBlank()) feedData.appConfig.telegramLink else "https://t.me/livetvofficialapp"
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(tgUrl))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(context, "Telegram: https://t.me/livetvofficialapp", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Security, contentDescription = null, tint = AccentGreen) },
                    label = { Text("Privacy Policy", color = TextWhite) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showPrivacyPolicyDialog = true
                    }
                )

                Spacer(modifier = Modifier.weight(1f))

                Text(
                    text = "Pure Live Streaming • 100% Free",
                    fontSize = 11.sp,
                    color = TextDarkGray,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    ) {
        Scaffold(
            containerColor = BgDark,
            topBar = {
                // Exact Top Bar from Screenshots: Hamburger + Title + Heart + Refresh + Search
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgDark)
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                var isMenuFocused by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clickable { scope.launch { drawerState.open() } }
                                        .onFocusChanged { isMenuFocused = it.isFocused }
                                        .focusable(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Menu,
                                        contentDescription = "Menu",
                                        tint = if (isMenuFocused) OrangeTab else TextWhite,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                if (selectedBottomTab == 0) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.fast_tv_logo),
                                            contentDescription = "HD STREAM",
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "HD ",
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.Black,
                                                color = TextWhite
                                            )
                                            Text(
                                                text = "STREAM",
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.Black,
                                                color = OrangeTab
                                            )
                                        }
                                    }
                                } else if (selectedBottomTab == 1) {
                                    Text(
                                        text = "Categories",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                } else {
                                    Text(
                                        text = "Movies & Series",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                }
                            }

                            // Top Bar Right: Telegram Circle
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                var isTgFocused by remember { mutableStateOf(false) }
                                // TELEGRAM CIRCLE
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .onFocusChanged { isTgFocused = it.isFocused }
                                        .focusable()
                                        .clip(CircleShape)
                                        .background(Color(0xFF0088CC))
                                        .border(
                                            width = if (isTgFocused) 2.5.dp else 1.5.dp,
                                            color = if (isTgFocused) Color(0xFF00E676) else Color(0xFF40C4FF),
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/livetvofficialapp"))
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Telegram",
                                        tint = Color.White,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }
                            }
                        }

                        // Search input if open
                    if (isSearchActive) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search matches, channels or shows...", color = TextGray, fontSize = 13.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            singleLine = true,
                            shape = RoundedCornerShape(25.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = OrangeTab,
                                unfocusedBorderColor = CardBorderOrange.copy(alpha = 0.5f),
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = null, tint = TextGray)
                                    }
                                }
                            }
                        )
                    }
                }
            },
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0C0D14))
                        .navigationBarsPadding()
                ) {
                    // Hairline top border
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFF1E2230))
                    )

                    // CLEAN MODERN BOTTOM NAVIGATION BAR: Live Matches | Live Channels | Movies (NO yellow/orange box on mobile)
                    NavigationBar(
                        containerColor = Color(0xFF0C0D14),
                        tonalElevation = 0.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                    ) {
                        // Item 1: Live Matches (Broadcast Icon)
                        val isLiveActive = (selectedBottomTab == 0)
                        var isLiveFocused by remember { mutableStateOf(false) }
                        NavigationBarItem(
                            selected = isLiveActive,
                            onClick = {
                                selectedBottomTab = 0
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.CellTower,
                                    contentDescription = "Live Matches",
                                    modifier = Modifier.size(23.dp),
                                    tint = if (isLiveActive) OrangeTab else TextGray
                                )
                            },
                            label = {
                                Text(
                                    text = "Live Matches",
                                    fontSize = 11.sp,
                                    fontWeight = if (isLiveActive) FontWeight.Black else FontWeight.Normal,
                                    color = if (isLiveActive) OrangeTab else TextGray
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .onFocusChanged { isLiveFocused = it.isFocused }
                                .focusable()
                                .then(
                                    if (isTv && isLiveFocused) {
                                        Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(OrangeTab.copy(alpha = 0.25f))
                                            .border(2.5.dp, OrangeTab, RoundedCornerShape(12.dp))
                                    } else Modifier
                                )
                        )

                        // Item 2: Live Channels (TV Icon)
                        val isCategoriesActive = (selectedBottomTab == 1)
                        var isChannelsFocused by remember { mutableStateOf(false) }
                        NavigationBarItem(
                            selected = isCategoriesActive,
                            onClick = {
                                selectedBottomTab = 1
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.LiveTv,
                                    contentDescription = "Live Channels",
                                    modifier = Modifier.size(23.dp),
                                    tint = if (isCategoriesActive) OrangeTab else TextGray
                                )
                            },
                            label = {
                                Text(
                                    text = "Live Channels",
                                    fontSize = 11.sp,
                                    fontWeight = if (isCategoriesActive) FontWeight.Black else FontWeight.Normal,
                                    color = if (isCategoriesActive) OrangeTab else TextGray
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .onFocusChanged { isChannelsFocused = it.isFocused }
                                .focusable()
                                .then(
                                    if (isTv && isChannelsFocused) {
                                        Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(OrangeTab.copy(alpha = 0.25f))
                                            .border(2.5.dp, OrangeTab, RoundedCornerShape(12.dp))
                                    } else Modifier
                                )
                        )

                        // Item 3: Movies & Web Series (Film Icon)
                        val isMoviesActive = (selectedBottomTab == 2)
                        var isMoviesFocused by remember { mutableStateOf(false) }
                        NavigationBarItem(
                            selected = isMoviesActive,
                            onClick = {
                                selectedBottomTab = 2
                            },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Movie,
                                    contentDescription = "Movies",
                                    modifier = Modifier.size(23.dp),
                                    tint = if (isMoviesActive) OrangeTab else TextGray
                                )
                            },
                            label = {
                                Text(
                                    text = "Movies",
                                    fontSize = 11.sp,
                                    fontWeight = if (isMoviesActive) FontWeight.Black else FontWeight.Normal,
                                    color = if (isMoviesActive) OrangeTab else TextGray
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .onFocusChanged { isMoviesFocused = it.isFocused }
                                .focusable()
                                .then(
                                    if (isTv && isMoviesFocused) {
                                        Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(OrangeTab.copy(alpha = 0.25f))
                                            .border(2.5.dp, OrangeTab, RoundedCornerShape(12.dp))
                                    } else Modifier
                                )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(BgDark)
            ) {
                if (showFavoritesOnly) {
                    FavoritesTabContent(
                        favoriteChannels = favoriteChannels,
                        favoriteUrls = favoriteUrls,
                        onToggleFavorite = onToggleFavorite,
                        onPlayStreamSource = handlePlayStreamWithAdCheck
                    )
                } else if (selectedBottomTab == 0) {
                    // Screen 1: VIP Live Events
                    LiveEventsTabContent(
                        feedData = feedData,
                        selectedSportsCategory = selectedSportsCategory,
                        onSelectSportsCategory = { selectedSportsCategory = it },
                        selectedStatusFilter = selectedStatusFilter,
                        onSelectStatusFilter = { selectedStatusFilter = it },
                        searchQuery = searchQuery,
                        onMatchClick = { match ->
                            activeMatchForLinks = match
                        },
                        onPlayStreamSource = handlePlayStreamWithAdCheck
                    )
                } else if (selectedBottomTab == 1) {
                    // Screen 4: Categories Grid
                    CategoriesTabContent(
                        categories = feedData.categories,
                        searchQuery = searchQuery,
                        onCategoryClick = { cat ->
                            if (cat.slug == "cinex-movies" || cat.name.contains("CINEX", ignoreCase = true) || cat.name.contains("MOVIES", ignoreCase = true)) {
                                selectedBottomTab = 2
                            } else {
                                activeCategoryForEpisodes = cat
                            }
                        }
                    )
                } else {
                    // Screen 5: Cinex Movies & Web Series (160+ Titles from data.json)
                    MoviesTabContent(
                        streamRepository = streamRepository,
                        searchQuery = searchQuery,
                        favoriteUrls = favoriteUrls,
                        onToggleFavorite = onToggleFavorite,
                        onPlayStreamSource = handlePlayStreamWithAdCheck
                    )
                }

                // SCREENSHOT 2: "Multiple links available" Dialog
                if (activeMatchForLinks != null) {
                    val currentMatch = activeMatchForLinks!!
                    MultipleLinksDialog(
                        match = currentMatch,
                        onDismiss = { activeMatchForLinks = null },
                        onSelectStream = { stream ->
                            activeMatchForLinks = null
                            val url = if (stream.streamUrl.isNotBlank()) stream.streamUrl else stream.jsonChannelUrl
                            val src = stream.copy(
                                id = currentMatch.id,
                                title = "${currentMatch.title} - ${stream.title}",
                                streamUrl = url
                            )
                            val matchChannels = currentMatch.streams.map { st ->
                                val u = if (st.streamUrl.isNotBlank()) st.streamUrl else st.jsonChannelUrl
                                ParsedChannelItem(
                                    title = st.title.ifBlank { "Stream Link" },
                                    streamUrl = u,
                                    streamType = st.streamType.ifBlank { ExoPlayerHelper.detectStreamType(u) },
                                    category = currentMatch.category.ifBlank { "Live Match" },
                                    quality = st.quality.ifBlank { "HD" },
                                    headers = st.headers,
                                    drm = st.drm
                                )
                            }
                            handlePlayStreamWithAdCheck(src, matchChannels)
                        }
                    )
                }

                // Custom Stream URL / M3U / DRM Dialog
                if (showStreamLinkDialog) {
                    StreamLinkInputDialog(
                        onDismiss = { showStreamLinkDialog = false },
                        onPlayDirectStream = { url, title, drm, headers ->
                            showStreamLinkDialog = false
                            val customSource = StreamSource(
                                id = "custom_" + System.currentTimeMillis(),
                                title = title.ifBlank { "Live Stream" },
                                streamType = ExoPlayerHelper.detectStreamType(url),
                                streamUrl = url,
                                quality = "1080p HD",
                                headers = headers,
                                drm = drm
                            )
                            handlePlayStreamWithAdCheck(customSource, emptyList())
                        },
                        onPlayImportedChannels = { channels ->
                            showStreamLinkDialog = false
                            val first = channels.firstOrNull()
                            if (first != null) {
                                val source = StreamSource(
                                    id = "imp_${first.title.hashCode()}",
                                    title = first.title,
                                    streamType = first.streamType,
                                    streamUrl = first.streamUrl,
                                    quality = first.quality,
                                    headers = first.headers,
                                    drm = first.drm
                                )
                                handlePlayStreamWithAdCheck(source, channels)
                            }
                        }
                    )
                }

                // Privacy Policy Dialog
                if (showPrivacyPolicyDialog) {
                    PrivacyPolicyDialog(onDismiss = { showPrivacyPolicyDialog = false })
                }

                // In-App Notification / Announcement Alert
                if (showAnnouncementDialog) {
                    AnnouncementDialog(
                        announcement = feedData.appConfig.announcement,
                        onDismiss = { showAnnouncementDialog = false }
                    )
                }
            }
        }
    }
}
}

/**
 * Screen 1: Live Events Tab Content
 */
@Composable
private fun LiveEventsTabContent(
    feedData: MobileFeedResponse,
    selectedSportsCategory: String,
    onSelectSportsCategory: (String) -> Unit,
    selectedStatusFilter: String,
    onSelectStatusFilter: (String) -> Unit,
    searchQuery: String,
    onMatchClick: (LiveStreamEvent) -> Unit,
    onPlayStreamSource: (StreamSource, List<ParsedChannelItem>) -> Unit
) {
    val allEvents = remember(feedData) {
        feedData.liveEvents + feedData.upcomingEvents + feedData.recentEvents
    }

    val filteredEvents = remember(allEvents, selectedSportsCategory, selectedStatusFilter, searchQuery) {
        allEvents.filter { event ->
            val matchesCategory = if (selectedSportsCategory == "All") true
            else event.category.contains(selectedSportsCategory, ignoreCase = true) ||
                    event.title.contains(selectedSportsCategory, ignoreCase = true)

            val matchesStatus = when (selectedStatusFilter) {
                "Live" -> event.status.equals("LIVE", ignoreCase = true)
                "Upcoming" -> event.status.equals("UPCOMING", ignoreCase = true)
                "Finished" -> event.status.equals("FINISHED", ignoreCase = true)
                else -> true
            }

            val matchesSearch = if (searchQuery.isBlank()) true else {
                event.title.contains(searchQuery, ignoreCase = true) ||
                        event.team1.name.contains(searchQuery, ignoreCase = true) ||
                        event.team2.name.contains(searchQuery, ignoreCase = true)
            }

            matchesCategory && matchesStatus && matchesSearch
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Ticker / Marquee Banner: HD STREAM Official Announcement
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF141419))
                    .border(1.dp, CardBorderOrange.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("🌐", fontSize = 14.sp)
                    Text(
                        text = feedData.appConfig.announcement.ifBlank { "HD STREAM 🔴 24/7 Live TV Channels & Streams" },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextWhite,
                        maxLines = 1,
                        modifier = Modifier.basicMarquee()
                    )
                }
            }
        }

        // Status Filter Pills: Dynamic counts for All, Live, Upcoming, Finished
        item {
            val liveCount = allEvents.count { it.status.equals("LIVE", ignoreCase = true) }
            val upCount = allEvents.count { it.status.equals("UPCOMING", ignoreCase = true) }
            val finCount = allEvents.count { it.status.equals("FINISHED", ignoreCase = true) }
            val statusPills = listOf(
                StatusPillItem("All", "All (${allEvents.size})"),
                StatusPillItem("Live", "Live ($liveCount)"),
                StatusPillItem("Upcoming", "Upcoming ($upCount)"),
                StatusPillItem("Finished", "Finished ($finCount)")
            )

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(statusPills) { pill ->
                    val isSelected = selectedStatusFilter.equals(pill.key, ignoreCase = true)
                    var isPillFocused by remember { mutableStateOf(false) }

                    Box(
                        modifier = Modifier
                            .onFocusChanged { isPillFocused = it.isFocused }
                            .focusable()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                if (isPillFocused) OrangeTab.copy(alpha = 0.35f)
                                else if (isSelected) OrangeTab
                                else Color(0xFF141419)
                            )
                            .border(
                                width = if (isPillFocused) 2.5.dp else 1.dp,
                                color = if (isPillFocused) OrangeTab else if (isSelected) OrangeTab else CardBorderOrange.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { onSelectStatusFilter(pill.key) }
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (isSelected) {
                                Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            }
                            Text(
                                text = pill.label,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected || isPillFocused) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected || isPillFocused) Color.White else TextGray
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Live & Upcoming Matches
        if (filteredEvents.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("🔴", fontSize = 13.sp)
                    Text(
                        text = "LIVE & UPCOMING MATCHES (${filteredEvents.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = TextWhite,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            items(filteredEvents) { match ->
                MatchCardItem(
                    match = match,
                    onClick = { onMatchClick(match) }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        } else {
            // Clean Empty State when ZERO matches exist in Admin Panel
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 20.dp)
                        .border(1.dp, CardBorderOrange.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F14))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E1E26)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📡", fontSize = 28.sp)
                        }

                        Text(
                            text = if (selectedStatusFilter.equals("Live", ignoreCase = true)) "No Live Matches Currently"
                            else if (selectedStatusFilter.equals("Upcoming", ignoreCase = true)) "No Upcoming Matches Scheduled"
                            else "No Live Matches Available",
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Text(
                            text = if (searchQuery.isNotBlank()) "No matches found matching \"$searchQuery\""
                            else "Currently no matches found in the live feed.\nMatches will appear here as soon as they are scheduled.",
                            color = TextDarkGray,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

// Image cache for team logos
private val teamLogoBitmapCache = android.util.LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(60)

/**
 * Circular Team Logo with caching, supporting both image URLs and emoji flags
 */
@Composable
private fun TeamCircleLogo(
    logoOrFlag: String,
    teamName: String,
    modifier: Modifier = Modifier,
    sizeDp: androidx.compose.ui.unit.Dp = 58.dp
) {
    val resolvedSource = remember(logoOrFlag, teamName) {
        if (logoOrFlag.isBlank() || logoOrFlag.contains("wikimedia", ignoreCase = true)) {
            com.hdstream.live.data.StreamRepository.getTeamFlagUrl(teamName)
        } else {
            logoOrFlag
        }
    }
    val cleanSource = remember(resolvedSource) { resolvedSource.replace("&amp;", "&").trim() }
    val isHttp = cleanSource.startsWith("http://", ignoreCase = true) || cleanSource.startsWith("https://", ignoreCase = true)

    var bitmap by remember(cleanSource) {
        mutableStateOf(if (isHttp) teamLogoBitmapCache.get(cleanSource) else null)
    }

    LaunchedEffect(cleanSource) {
        if (isHttp && bitmap == null) {
            withContext(Dispatchers.IO) {
                try {
                    val url = java.net.URL(cleanSource)
                    val conn = url.openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 7000
                    conn.readTimeout = 7000
                    conn.instanceFollowRedirects = true
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile)")
                    conn.setRequestProperty("Accept", "image/png,image/*,*/*")
                    if (conn.responseCode in 200..299) {
                        val bytes = conn.inputStream.use { it.readBytes() }
                        val decoded = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (decoded != null) {
                            val imgBitmap = decoded.asImageBitmap()
                            teamLogoBitmapCache.put(cleanSource, imgBitmap)
                            bitmap = imgBitmap
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    Box(
        modifier = modifier
            .size(sizeDp)
            .clip(CircleShape)
            .background(Color.White)
            .border(1.8.dp, Color(0xFFFF5722), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = teamName,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else if (cleanSource.isNotBlank() && !isHttp) {
            Text(
                text = cleanSource,
                fontSize = (sizeDp.value * 0.45f).sp,
                textAlign = TextAlign.Center
            )
        } else {
            val t = teamName.lowercase().trim()
            val fallbackEmoji = when {
                t.contains("india") || t == "ind" -> "🇮🇳"
                t.contains("new zealand") || t.contains("zealand") || t == "nz" -> "🇳🇿"
                t.contains("australia") || t == "aus" -> "🇦🇺"
                t.contains("england") || t == "eng" -> "🏴󠁧󠁢󠁥󠁮󠁧󠁿"
                t.contains("pakistan") || t == "pak" -> "🇵🇰"
                t.contains("south africa") || t == "sa" -> "🇿🇦"
                t.contains("bangladesh") || t == "ban" || t == "bd" -> "🇧🇩"
                t.contains("sri lanka") || t == "sl" || t == "lk" -> "🇱🇰"
                t.contains("afghanistan") || t == "afg" -> "🇦🇫"
                t.contains("nepal") || t == "nep" || t == "npl" -> "🇳🇵"
                t.contains("west indies") || t == "wi" -> "🌴"
                t.contains("zimbabwe") || t == "zim" -> "🇿🇼"
                t.contains("ireland") || t == "ire" -> "🇮🇪"
                t.contains("netherlands") || t == "ned" -> "🇳🇱"
                t.contains("usa") || t.contains("united states") -> "🇺🇸"
                t.contains("canada") || t == "can" -> "🇨🇦"
                else -> "🏆"
            }
            Text(
                text = fallbackEmoji,
                fontSize = (sizeDp.value * 0.45f).sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Helper to cleanly separate time and date so they are never mixed together
 */
private fun extractTimeAndDate(raw: String): Pair<String, String> {
    if (raw.isBlank()) return Pair("LIVE NOW", "")
    val trimmed = raw.trim()
    if (trimmed.contains("•")) {
        val parts = trimmed.split("•")
        val part1 = parts[0].trim()
        val part2 = parts.getOrElse(1) { "" }.trim()
        return Pair(part1, part2)
    }
    if (trimmed.contains(" ") && (trimmed.contains("/") || trimmed.contains("-"))) {
        val tokens = trimmed.split(" ").filter { it.isNotBlank() }
        val dateToken = tokens.find { it.contains("/") || it.contains("-") } ?: ""
        val timeTokens = tokens.filter { it != dateToken }.joinToString(" ")
        if (timeTokens.isNotBlank() && dateToken.isNotBlank()) {
            return Pair(timeTokens, dateToken)
        }
    }
    if (trimmed.contains("AM", ignoreCase = true) || trimmed.contains("PM", ignoreCase = true) || trimmed.contains(":")) {
        return Pair(trimmed, "")
    }
    return Pair("", trimmed)
}

/**
 * Format match date
 */
private fun formatMatchDate(startTime: String): String {
    val regex = Regex("""\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}[/-]\d{1,2}[/-]\d{1,2})\b""")
    val match = regex.find(startTime)
    if (match != null) {
        return match.value.replace("-", "/")
    }
    return try {
        val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
        sdf.format(java.util.Date())
    } catch (_: Exception) {
        "01/11/2026"
    }
}

private fun getShortTeamName(fullName: String): String {
    val t = fullName.lowercase().trim()
    return when {
        t.contains("india") || t == "ind" -> "IND"
        t.contains("new zealand") || t.contains("zealand") || t == "nz" -> "NZ"
        t.contains("australia") || t == "aus" -> "AUS"
        t.contains("england") || t == "eng" -> "ENG"
        t.contains("pakistan") || t == "pak" -> "PAK"
        t.contains("south africa") || t == "sa" -> "SA"
        t.contains("bangladesh") || t == "ban" || t == "bd" -> "BAN"
        t.contains("sri lanka") || t == "sl" || t == "lk" -> "SL"
        t.contains("afghanistan") || t == "afg" -> "AFG"
        t.contains("zimbabwe") || t == "zim" -> "ZIM"
        t.contains("nepal") || t == "nep" || t == "npl" -> "NEP"
        t.contains("west indies") || t == "wi" -> "WI"
        t.contains("ireland") || t == "ire" -> "IRE"
        t.contains("netherlands") || t == "ned" -> "NED"
        t.contains("wbbl") -> "WBBL"
        else -> fullName.split(" ").firstOrNull()?.take(4)?.uppercase() ?: "TEAM"
    }
}

/**
 * EXACT PHOTO 3 LIVE MATCH CARD DESIGN
 * Hero match arena with CRICKET & SONY LIVE badges, bold NZ vs IND typography,
 * circular team flag badges, match info, favorite toggle, and vibrant "Watch Stream" button.
 */
@Composable
private fun MatchCardItem(
    match: LiveStreamEvent,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val isTv = remember { DeviceUtils.isTv(context) }

    val isLive = match.status.equals("LIVE", ignoreCase = true)
    val isUpcoming = match.status.equals("UPCOMING", ignoreCase = true)

    val t1Name = match.team1.name.ifBlank { "Team 1" }
    val t2Name = match.team2.name.ifBlank { "Team 2" }

    val short1 = remember(t1Name) { getShortTeamName(t1Name) }
    val short2 = remember(t2Name) { getShortTeamName(t2Name) }

    val t1Logo = match.team1.logo.ifBlank { match.team1.flag }.let {
        if (it.isBlank() || it.contains("wikimedia", ignoreCase = true)) com.hdstream.live.data.StreamRepository.getTeamFlagUrl(t1Name) else it
    }
    val t2Logo = match.team2.logo.ifBlank { match.team2.flag }.let {
        if (it.isBlank() || it.contains("wikimedia", ignoreCase = true)) com.hdstream.live.data.StreamRepository.getTeamFlagUrl(t2Name) else it
    }

    val categoryText = match.category.ifBlank { "CRICKET" }.uppercase()
    val matchDate = remember(match.startTime) { formatMatchDate(match.startTime) }

    var isCardFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .onFocusChanged { isCardFocused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isTv && isCardFocused) Color(0xFF161E30) else Color(0xFF0D121F)
        ),
        border = BorderStroke(
            width = if (isTv && isCardFocused) 2.5.dp else 1.2.dp,
            color = if (isTv && isCardFocused) OrangeTab else Color(0xFF1E283C)
        )
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Background Stadium Banner inside card (live event ma background banner lago)
            val bannerUrlToUse = match.bannerUrl.ifBlank {
                "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=1200&auto=format&fit=crop"
            }
            AsyncMatchBanner(
                bannerUrl = bannerUrlToUse,
                title = match.title,
                modifier = Modifier.matchParentSize()
            )

            // High-contrast atmospheric dark gradient overlay so text and logos are ultra-sharp
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF070A14).copy(alpha = 0.72f),
                                Color(0xFF090D1A).copy(alpha = 0.94f)
                            )
                        )
                    )
            )

            Column(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    // Top Row: Category Pill (CRICKET) & Live Status Badge (LIVE / UPCOMING)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Category Pill (Left)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.Black.copy(alpha = 0.70f))
                                .border(0.8.dp, Color(0xFF90CAF9).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = categoryText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF90CAF9),
                                letterSpacing = 0.5.sp
                            )
                        }

                        // Status Badge (Right)
                        if (isLive) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color(0xFFE50914))
                                    .padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Text(
                                        text = "LIVE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }
                        } else if (isUpcoming) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color(0xFF0288D1))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "UPCOMING",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color(0xFF455A64))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "ENDED",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Teams Arena: 1st Photo (64dp) + Name | DATE & TIME on top, VS badge directly below | 2nd Photo (64dp) + Name
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // 1st Photo (Top, 64dp size matching category) + 1st Name (Directly Below)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(105.dp)
                        ) {
                            TeamCircleLogo(
                                logoOrFlag = t1Logo,
                                teamName = t1Name,
                                sizeDp = 64.dp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = t1Name,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }

                        // Center: DATE & TIME ON TOP (NOT MIXED) + VS BADGE DIRECTLY BELOW!
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            val (timeStr, dateStr) = remember(match.startTime) { extractTimeAndDate(match.startTime) }

                            // 1. Separate Time (Bold Cyan - date or time mix nahi hona chahiye)
                            if (timeStr.isNotBlank()) {
                                Text(
                                    text = timeStr,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF00E5FF)
                                )
                            }

                            // 2. Separate Date (Soft Blue Bold - date or time mix nahi hona chahiye)
                            if (dateStr.isNotBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = dateStr,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF81D4FA)
                                )
                            }

                            Spacer(modifier = Modifier.height(7.dp))

                            // 3. VS Badge (VS KA UPER DATE OR TIME)
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF131C30).copy(alpha = 0.90f))
                                    .border(1.5.dp, Color(0xFF00E5FF).copy(alpha = 0.85f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "VS",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }

                        // 2nd Photo (Top, 64dp size matching category) + 2nd Name (Directly Below)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(105.dp)
                        ) {
                            TeamCircleLogo(
                                logoOrFlag = t2Logo,
                                teamName = t2Name,
                                sizeDp = 64.dp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = t2Name,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Subtle divider line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFF1E283C).copy(alpha = 0.8f))
                )

                // 2. BOTTOM INFO & ACTION ROW
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF070B14).copy(alpha = 0.92f))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left: Title & Subtitle
                    Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                        Text(
                            text = match.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${match.category} • $matchDate",
                            fontSize = 11.sp,
                            color = Color(0xFF90A4AE),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Right: Watch Stream Button
                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCardFocused) OrangeTab else Color(0xFF1976D2)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 9.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Watch",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Watch Stream",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * SCREENSHOT 2: "Multiple links available" Dialog
 */
@Composable
private fun MultipleLinksDialog(
    match: LiveStreamEvent,
    onDismiss: () -> Unit,
    onSelectStream: (StreamSource) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF0F111A))
                .border(1.5.dp, Color(0xFFFF5722), RoundedCornerShape(20.dp))
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header: Match info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Multiple links available",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = match.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFFF8A65),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (match.streams.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Is match ke liye koi streaming link abhi available nahi hai.",
                            fontSize = 12.sp,
                            color = TextGray,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(match.streams) { stream ->
                            var isLinkFocused by remember { mutableStateOf(false) }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isLinkFocused = it.isFocused }
                                    .focusable()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isLinkFocused) OrangeTab.copy(alpha = 0.25f) else Color(0xFF1A1D2B))
                                    .border(
                                        width = if (isLinkFocused) 3.5.dp else 1.dp,
                                        color = if (isLinkFocused) OrangeTab else Color(0xFF2E344E),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onSelectStream(stream) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFFF5722).copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                tint = Color(0xFFFF5722),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Column {
                                            Text(
                                                text = stream.title.ifBlank { "Server Link" },
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${stream.quality} • ${stream.streamType}",
                                                fontSize = 10.sp,
                                                color = Color(0xFF00E5FF),
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFFFF5722))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "PLAY",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("CANCEL", color = Color(0xFFFF5722), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

/**
 * Screen 4: Categories Tab Content (3 Columns Grid)
 */
@Composable
private fun CategoriesTabContent(
    categories: List<FeedCategory>,
    searchQuery: String,
    onCategoryClick: (FeedCategory) -> Unit
) {
    val uniqueCategories = remember(categories) {
        val seen = linkedMapOf<String, FeedCategory>()
        for (cat in categories) {
            val key = (if (cat.id.isNotBlank()) cat.id else cat.name).trim().lowercase()
            if (!seen.containsKey(key)) {
                seen[key] = cat
            }
        }
        seen.values.toList()
    }

    val filtered = if (searchQuery.isBlank()) uniqueCategories else {
        uniqueCategories.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(filtered, key = { it.id.ifBlank { it.name } }) { cat ->
            var isFocused by remember { mutableStateOf(false) }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(154.dp)
                    .onFocusChanged { isFocused = it.isFocused }
                    .focusable()
                    .clickable { onCategoryClick(cat) },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isFocused) Color(0xFF24263D) else Color(0xFF13141F)
                ),
                border = if (isFocused) BorderStroke(2.5.dp, Color(0xFFFF9800)) else BorderStroke(1.dp, Color(0xFF222335))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Upper: Category Logo (Clean, High-Res Circular Logo)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(82.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (cat.imageUrl.isNotBlank()) {
                            AsyncChannelLogo(
                                logoUrl = cat.imageUrl,
                                channelTitle = cat.name,
                                modifier = Modifier.size(64.dp)
                            )
                        } else {
                            val badgeText = getCategoryBadgeText(cat.name)
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1B1C28))
                                    .border(1.5.dp, Color(0xFF2E3447), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = badgeText,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    color = OrangeTab
                                )
                            }
                        }
                    }

                    // Lower: Title & Subtitle (Generous 2-column width: CARTOON MOVIE, PAKISTAN TV fits completely!)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = cat.name.uppercase(),
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Live Channels",
                            color = Color(0xFF8E90A6),
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

private fun getCategoryBadgeText(name: String): String {
    return when {
        name.contains("JIO", ignoreCase = true) -> "JIO"
        name.contains("MIX", ignoreCase = true) -> "MIX"
        name.contains("VZY", ignoreCase = true) -> "VZY"
        name.contains("PAKISTAN", ignoreCase = true) -> "PAK"
        name.contains("TOFFEE", ignoreCase = true) -> "TOF"
        name.contains("IRAN", ignoreCase = true) -> "IRAN"
        name.contains("AFGHAN", ignoreCase = true) -> "AFG"
        name.contains("CARTOON", ignoreCase = true) -> "KIDS"
        name.contains("MX", ignoreCase = true) -> "MXP"
        name.contains("YUPPY", ignoreCase = true) -> "YUP"
        else -> name.take(4).uppercase()
    }
}

private val channelLogoCache = android.util.LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(250)

@Composable
private fun AsyncChannelLogo(
    logoUrl: String,
    channelTitle: String,
    modifier: Modifier = Modifier
) {
    val cleanUrl = remember(logoUrl) { logoUrl.replace("&amp;", "&").trim() }
    var bitmap by remember(cleanUrl) { mutableStateOf(if (cleanUrl.isNotBlank()) channelLogoCache.get(cleanUrl) else null) }

    LaunchedEffect(cleanUrl) {
        if (bitmap == null && cleanUrl.isNotBlank() && (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://"))) {
            withContext(Dispatchers.IO) {
                val candidateUrls = if (cleanUrl.contains("raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/")) {
                    listOf(
                        cleanUrl,
                        cleanUrl.replace("raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/", "cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/")
                    )
                } else {
                    listOf(cleanUrl)
                }

                for (targetUrl in candidateUrls) {
                    try {
                        val url = java.net.URL(targetUrl)
                        val conn = url.openConnection() as java.net.HttpURLConnection
                        conn.connectTimeout = 7000
                        conn.readTimeout = 7000
                        conn.instanceFollowRedirects = true
                        conn.requestMethod = "GET"
                        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile)")
                        conn.setRequestProperty("Accept", "image/png,image/*,*/*")
                        if (conn.responseCode in 200..299) {
                            val bytes = conn.inputStream.use { it.readBytes() }
                            val decoded = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (decoded != null) {
                                val imgBitmap = decoded.asImageBitmap()
                                channelLogoCache.put(cleanUrl, imgBitmap)
                                bitmap = imgBitmap
                                break
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Color(0xFF161824), CircleShape)
            .border(1.5.dp, Color(0xFF2E3447), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            val isRectangularFlag = cleanUrl.contains("flagcdn.com") || cleanUrl.contains("/flags/") || cleanUrl.contains("country")
            Image(
                bitmap = bitmap!!,
                contentDescription = channelTitle,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape),
                contentScale = if (isRectangularFlag) androidx.compose.ui.layout.ContentScale.Crop else androidx.compose.ui.layout.ContentScale.Fit
            )
        } else {
            val initials = channelTitle.split(" ")
                .filter { it.isNotBlank() }
                .take(2)
                .map { it.first().uppercaseChar() }
                .joinToString("")
                .ifBlank { "TV" }

            Text(
                text = initials,
                color = OrangeTab,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

/**
 * Screen 3: Category Detail View - Live M3U Playlist Parsing & Direct Channels
 * Exact 2-column channel grid with logo posters & language filter chips (Matching Screenshot)
 */
@Composable
private fun CategoryDetailView(
    category: FeedCategory,
    favoriteUrls: Set<String>,
    onToggleFavorite: (ParsedChannelItem) -> Unit,
    onPlayStreamSource: (StreamSource, List<ParsedChannelItem>) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var channelList by remember(category) { mutableStateOf<List<ParsedChannelItem>>(emptyList()) }
    var isLoading by remember(category) { mutableStateOf(true) }
    var channelSearch by remember { mutableStateOf("") }
    var selectedGroupFilter by remember { mutableStateOf("All") }
    var refreshKey by remember { mutableIntStateOf(0) }

    // Intercept Back button cleanly
    BackHandler {
        onBack()
    }

    LaunchedEffect(category, refreshKey) {
        isLoading = true
        try {
            val isHdStream = category.slug.contains("hd-stream", ignoreCase = true) || category.name.contains("HD STREAM", ignoreCase = true)
            val isMixTv = category.slug.contains("mix", ignoreCase = true) || category.name.contains("MIX", ignoreCase = true)

            val effectiveLink = when {
                isMixTv -> {
                    val raw = category.m3uLink.trim()
                    if (raw.isBlank() || raw.contains("cinexcricket", ignoreCase = true) || raw.contains("jiotv", ignoreCase = true) || raw.contains("allinone", ignoreCase = true)) {
                        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/tv/mix.json"
                    } else {
                        raw
                    }
                }
                isHdStream -> {
                    val raw = category.m3uLink.trim()
                    if (raw.isBlank()) "https://cinexcricket.com/api/tv/data.json" else raw
                }
                else -> category.m3uLink.trim()
            }

            val fallbackAsset = when {
                isHdStream -> "tv_channels.json"
                isMixTv -> "mix_channels.json"
                else -> null
            }

            val rawContent = if (effectiveLink.isNotBlank()) {
                try {
                    M3uParser.fetchFromUrl(effectiveLink)
                } catch (_: Exception) {
                    if (fallbackAsset != null) {
                        try {
                            context.assets.open(fallbackAsset).bufferedReader().use { it.readText() }
                        } catch (_: Exception) { "" }
                    } else ""
                }
            } else {
                if (fallbackAsset != null) {
                    try {
                        context.assets.open(fallbackAsset).bufferedReader().use { it.readText() }
                    } catch (_: Exception) { "" }
                } else ""
            }

            if (rawContent.isNotBlank()) {
                val trimmed = rawContent.trim()
                val parsed = if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                    M3uParser.parseJson(trimmed, defaultCategory = category.name)
                } else {
                    M3uParser.parseM3u(rawContent, defaultCategory = category.name)
                }
                channelList = if (parsed.isNotEmpty()) parsed else {
                    if (fallbackAsset != null) {
                        val fallback = try {
                            context.assets.open(fallbackAsset).bufferedReader().use { it.readText() }
                        } catch (_: Exception) { "" }
                        if (fallback.isNotBlank()) M3uParser.parseJson(fallback, defaultCategory = category.name) else emptyList()
                    } else emptyList()
                }
            } else {
                channelList = if (fallbackAsset != null) {
                    val fallback = try {
                        context.assets.open(fallbackAsset).bufferedReader().use { it.readText() }
                    } catch (_: Exception) { "" }
                    if (fallback.isNotBlank()) M3uParser.parseJson(fallback, defaultCategory = category.name) else emptyList()
                } else emptyList()
            }
        } catch (_: Exception) {
            val isHdStream = category.slug.contains("hd-stream", ignoreCase = true) || category.name.contains("HD STREAM", ignoreCase = true)
            val isMixTv = category.slug.contains("mix", ignoreCase = true) || category.name.contains("MIX", ignoreCase = true)
            val fallbackAsset = when {
                isHdStream -> "tv_channels.json"
                isMixTv -> "mix_channels.json"
                else -> null
            }
            channelList = if (fallbackAsset != null) {
                val fallback = try {
                    context.assets.open(fallbackAsset).bufferedReader().use { it.readText() }
                } catch (_: Exception) { "" }
                if (fallback.isNotBlank()) M3uParser.parseJson(fallback, defaultCategory = category.name) else emptyList()
            } else emptyList()
        } finally {
            isLoading = false
        }
    }

    // Dynamic Filter Chips (Languages / Groups extracted from M3U)
    val filterGroups = remember(channelList) {
        val groups = channelList.map { it.category.trim() }
            .filter { it.isNotBlank() && !it.equals("All", ignoreCase = true) && !it.equals(category.name, ignoreCase = true) }
            .distinct()
            .sorted()
        listOf("All") + groups
    }

    val displayChannels = remember(channelList, channelSearch, selectedGroupFilter) {
        channelList.filter { item ->
            val matchesSearch = if (channelSearch.isBlank()) true else {
                item.title.contains(channelSearch, ignoreCase = true) ||
                item.category.contains(channelSearch, ignoreCase = true)
            }
            val matchesGroup = if (selectedGroupFilter == "All") true else {
                item.category.equals(selectedGroupFilter, ignoreCase = true)
            }
            matchesSearch && matchesGroup
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0D14))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // TOP BAR: <- Back | Search in {category.name} | Refresh
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            var isBackFocused by remember { mutableStateOf(false) }
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .onFocusChanged { isBackFocused = it.isFocused }
                    .focusable()
                    .border(if (isBackFocused) 2.dp else 0.dp, Color(0xFFFF9800), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextWhite
                )
            }

            OutlinedTextField(
                value = channelSearch,
                onValueChange = { channelSearch = it },
                placeholder = {
                    Text(
                        text = "Search in ${category.name}",
                        color = Color(0xFF7A7D94),
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF383564),
                    unfocusedBorderColor = Color(0xFF222334),
                    focusedContainerColor = Color(0xFF141522),
                    unfocusedContainerColor = Color(0xFF141522),
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                singleLine = true,
                trailingIcon = {
                    if (channelSearch.isNotEmpty()) {
                        IconButton(onClick = { channelSearch = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextGray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            )

            var isRefreshFocused by remember { mutableStateOf(false) }
            IconButton(
                onClick = { refreshKey++ },
                modifier = Modifier
                    .size(40.dp)
                    .onFocusChanged { isRefreshFocused = it.isFocused }
                    .focusable()
                    .border(if (isRefreshFocused) 2.dp else 0.dp, Color(0xFFFF9800), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh",
                    tint = TextWhite
                )
            }
        }

        // HORIZONTAL FILTER CHIPS: All • {count} | Assamese | Bengali | ...
        if (!isLoading && channelList.isNotEmpty() && filterGroups.size > 1) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(filterGroups) { group ->
                    val isSelected = (group == selectedGroupFilter)
                    var isChipFocused by remember { mutableStateOf(false) }
                    val label = if (group == "All") {
                        val countStr = java.text.NumberFormat.getIntegerInstance().format(channelList.size)
                        "All • $countStr"
                    } else {
                        group
                    }

                    Surface(
                        onClick = { selectedGroupFilter = group },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) Color(0xFF35315E) else if (isChipFocused) Color(0xFF26273B) else Color(0xFF161724),
                        border = BorderStroke(
                            if (isChipFocused) 2.dp else 1.dp,
                            if (isChipFocused) Color(0xFFFF9800) else if (isSelected) Color(0xFF5D5896) else Color(0xFF252638)
                        ),
                        modifier = Modifier
                            .onFocusChanged { isChipFocused = it.isFocused }
                            .focusable()
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) TextWhite else Color(0xFF9EA1B8),
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // CONTENT: 2-Column Channel Grid
        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(color = OrangeTab)
                    Text("Loading ${category.name} channels...", color = TextGray, fontSize = 13.sp)
                }
            }
        } else if (displayChannels.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No channels found in ${category.name}", color = TextGray, fontSize = 14.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayChannels, key = { it.streamUrl + it.title }) { channel ->
                    val isFav = favoriteUrls.contains(channel.streamUrl)
                    ChannelGridCard(
                        channel = channel,
                        isFavorite = isFav,
                        onToggleFavorite = { onToggleFavorite(channel) },
                        onClick = {
                            ExoPlayerHelper.releaseActivePlayer()
                            val source = StreamSource(
                                id = "cat_${category.id}_${channel.title.hashCode()}",
                                title = channel.title,
                                streamType = channel.streamType,
                                streamUrl = channel.streamUrl,
                                quality = channel.quality,
                                headers = channel.headers,
                                drm = channel.drm
                            )
                            onPlayStreamSource(source, channelList)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelGridCard(
    channel: ParsedChannelItem,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    var isCardFocused by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(154.dp)
            .onFocusChanged { isCardFocused = it.isFocused }
            .focusable()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCardFocused) Color(0xFF24263D) else Color(0xFF13141F)
        ),
        border = if (isCardFocused) BorderStroke(2.5.dp, Color(0xFFFF9800)) else BorderStroke(1.dp, Color(0xFF222335))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Upper: Channel Logo (Circular 64dp, exactly matching Category) + Heart / Favorite Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(82.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncChannelLogo(
                    logoUrl = channel.logo,
                    channelTitle = channel.title,
                    modifier = Modifier.size(64.dp)
                )

                // Top-Right Heart / Favorite Toggle Button
                var isHeartFocused by remember { mutableStateOf(false) }
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(30.dp)
                        .onFocusChanged { isHeartFocused = it.isFocused }
                        .focusable()
                        .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                        .border(if (isHeartFocused) 2.dp else 0.dp, Color(0xFFFF9800), CircleShape)
                        .padding(2.dp)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) LiveRed else TextWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Lower: Title & Category / Quality (Generous 2-column width)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = channel.title.uppercase(),
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = channel.category.ifBlank { "Live TV" },
                        color = Color(0xFF8E90A6),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Text(
                        text = channel.quality.ifBlank { "HD" },
                        color = OrangeTab,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelCard(
    channel: ParsedChannelItem,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    var isCardFocused by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { isCardFocused = it.isFocused }
            .focusable()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCardFocused) Color(0xFF22263C) else Color(0xFF101016))
            .border(
                width = if (isCardFocused) 2.5.dp else 1.dp,
                color = if (isCardFocused) Color(0xFF00E676) else Color(0xFF22222E),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (channel.logo.isNotBlank()) {
                    AsyncChannelLogo(
                        logoUrl = channel.logo,
                        channelTitle = channel.title,
                        modifier = Modifier.size(42.dp)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF20130A))
                            .border(1.dp, Color(0xFF2E3447), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = OrangeTab,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = channel.title,
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(LiveRed, CircleShape)
                        )
                        Text(
                            text = "LIVE • ${channel.quality}",
                            color = OrangeTab,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.size(38.dp)
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) LiveRed else TextGray,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun FavoritesTabContent(
    favoriteChannels: List<ParsedChannelItem>,
    favoriteUrls: Set<String>,
    onToggleFavorite: (ParsedChannelItem) -> Unit,
    onPlayStreamSource: (StreamSource, List<ParsedChannelItem>) -> Unit
) {
    // Combine rich stored items with any URL-only legacy items
    val displayItems = remember(favoriteChannels, favoriteUrls) {
        val existingUrls = favoriteChannels.map { it.streamUrl }.toSet()
        val missingUrls = favoriteUrls - existingUrls
        val legacyItems = missingUrls.map { url ->
            ParsedChannelItem(
                title = "Favorite Live Channel",
                streamUrl = url,
                quality = "1080p HD"
            )
        }
        favoriteChannels + legacyItems
    }

    if (displayItems.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(24.dp)
            ) {
                Text("❤️", fontSize = 48.sp)
                Text(
                    text = "No Favorite Channels Yet!",
                    color = TextWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Tap the Heart (❤️) icon on any channel in Categories to save your favorites here for 1-click watching.",
                    color = TextGray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 10.dp)
        ) {
            Text(
                text = "❤️ MY FAVORITE CHANNELS (${displayItems.size})",
                color = OrangeTab,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayItems, key = { it.streamUrl + it.title }) { channel ->
                    ChannelGridCard(
                        channel = channel,
                        isFavorite = true,
                        onToggleFavorite = { onToggleFavorite(channel) },
                        onClick = {
                            ExoPlayerHelper.releaseActivePlayer()
                            val source = StreamSource(
                                id = "fav_${channel.streamUrl.hashCode()}",
                                title = channel.title,
                                streamType = channel.streamType,
                                streamUrl = channel.streamUrl,
                                quality = channel.quality,
                                headers = channel.headers,
                                drm = channel.drm
                            )
                            onPlayStreamSource(source, displayItems)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141419),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Security, contentDescription = null, tint = OrangeTab)
                Text("Privacy Policy", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "HD STREAM is committed to protecting your privacy. We do not collect, track, or share any personal identity, contacts, or sensitive user data.\n\nAll playlists and media stream URLs are user-provided or aggregated from publicly accessible network endpoints. We do not host any copyrighted media files on our servers.\n\nFor official updates, announcements, and channel requests, join our Telegram:\nhttps://t.me/livetvofficialapp",
                    color = TextGray,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = OrangeTab)
            ) {
                Text("Close", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun AnnouncementDialog(
    announcement: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF16161E),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🔔", fontSize = 20.sp)
                Text("Important Update", color = OrangeTab, fontWeight = FontWeight.Black, fontSize = 17.sp)
            }
        },
        text = {
            Text(
                text = announcement,
                color = TextWhite,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = OrangeTab)
            ) {
                Text("OK", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )
}

/**
 * Custom Stream URL, M3U Playlist & DRM Player Modal Dialog
 */
@Composable
fun StreamLinkInputDialog(
    onDismiss: () -> Unit,
    onPlayDirectStream: (url: String, title: String, drm: DrmConfig, headers: Map<String, String>) -> Unit,
    onPlayImportedChannels: (channels: List<ParsedChannelItem>) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var inputTab by remember { mutableStateOf(0) } // 0: Direct Stream & DRM, 1: M3U / JSON Playlist

    // Direct stream state
    var streamUrl by remember { mutableStateOf("") }
    var streamTitle by remember { mutableStateOf("") }
    var drmType by remember { mutableStateOf("none") } // "none", "clearkey", "widevine"
    var clearkeyId by remember { mutableStateOf("") }
    var clearkeyKey by remember { mutableStateOf("") }
    var widevineLicenseUrl by remember { mutableStateOf("") }

    // Custom headers
    var customUserAgent by remember { mutableStateOf("") }
    var customReferer by remember { mutableStateOf("") }
    var customCookie by remember { mutableStateOf("") }

    // Playlist state
    var playlistInput by remember { mutableStateOf("") }
    var isPlaylistLoading by remember { mutableStateOf(false) }
    var parsedChannels by remember { mutableStateOf<List<ParsedChannelItem>>(emptyList()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF13131A)),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderOrange.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Modal Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(OrangeTab.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = OrangeTab, modifier = Modifier.size(18.dp))
                        }
                        Column {
                            Text("Stream Link & DRM Player", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            Text("Play M3U8, MPD, ClearKey & Widevine", color = TextGray, fontSize = 10.sp)
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextWhite)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1B1B26), RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabs = listOf("🔗 Direct Stream / DRM", "📑 M3U / JSON Playlist")
                    tabs.forEachIndexed { idx, name ->
                        val isSel = inputTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) OrangeTab else Color.Transparent)
                                .clickable { inputTab = idx }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                color = if (isSel) Color.White else TextGray,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Content
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (inputTab == 0) {
                        // ==========================================
                        // TAB 0: Direct Stream URL & DRM
                        // ==========================================
                        item {
                            Text("1. STREAM URL *", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = streamUrl,
                                onValueChange = { streamUrl = it },
                                placeholder = { Text("https://.../master.m3u8 or .mpd", color = TextDarkGray, fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 12.sp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OrangeTab,
                                    unfocusedBorderColor = CardBorderOrange.copy(alpha = 0.4f)
                                )
                            )
                        }

                        item {
                            Text("2. STREAM TITLE (OPTIONAL)", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = streamTitle,
                                onValueChange = { streamTitle = it },
                                placeholder = { Text("e.g. Jio / Hotstar Live Cricket", color = TextDarkGray, fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 12.sp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OrangeTab,
                                    unfocusedBorderColor = CardBorderOrange.copy(alpha = 0.4f)
                                )
                            )
                        }

                        // OTT One-Tap Presets
                        item {
                            Text("⚡ OTT QUICK HEADER PRESETS:", color = OrangeTab, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        customUserAgent = "HotstarMobile/12.5.0 (Android 14; Mobile)"
                                        customReferer = "https://www.hotstar.com/"
                                        drmType = "widevine"
                                        Toast.makeText(context, "Applied Hotstar Preset", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Hotstar", fontSize = 11.sp, color = UpcomingCyan)
                                }

                                Button(
                                    onClick = {
                                        customUserAgent = "JioCinema/24.0.0 (Linux; Android 14)"
                                        customReferer = "https://www.jiocinema.com/"
                                        drmType = "widevine"
                                        Toast.makeText(context, "Applied JioCinema Preset", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("JioCinema", fontSize = 11.sp, color = LiveRed)
                                }

                                Button(
                                    onClick = {
                                        customUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"
                                        customReferer = "https://www.sonyliv.com/"
                                        Toast.makeText(context, "Applied SonyLIV Preset", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("SonyLIV", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }

                        // DRM Mode Selection
                        item {
                            Text("3. DRM PROTECTION:", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val drms = listOf(
                                    Triple("none", "None", AccentGreen),
                                    Triple("clearkey", "ClearKey", OrangeTab),
                                    Triple("widevine", "Widevine", UpcomingCyan)
                                )
                                drms.forEach { (type, label, col) ->
                                    val isSel = drmType == type
                                    Surface(
                                        onClick = { drmType = type },
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSel) col.copy(alpha = 0.2f) else Color(0xFF1A1A24),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) col else Color.Transparent),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text(label, color = if (isSel) col else TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        // ClearKey Inputs
                        if (drmType == "clearkey") {
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1C1322), RoundedCornerShape(10.dp))
                                        .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("🔑 ClearKey DRM Keys (Hex / kid:key):", color = Color(0xFFA78BFA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    OutlinedTextField(
                                        value = clearkeyId,
                                        onValueChange = { clearkeyId = it },
                                        placeholder = { Text("Key ID (KID) or combined kid:key", color = TextDarkGray, fontSize = 11.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 11.sp),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = clearkeyKey,
                                        onValueChange = { clearkeyKey = it },
                                        placeholder = { Text("Key Hex (Optional if kid:key format entered above)", color = TextDarkGray, fontSize = 11.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 11.sp),
                                        singleLine = true
                                    )
                                }
                            }
                        }

                        // Widevine Inputs
                        if (drmType == "widevine") {
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF0F1E2A), RoundedCornerShape(10.dp))
                                        .border(1.dp, UpcomingCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("🛡️ Widevine Modular License Server URL:", color = UpcomingCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    OutlinedTextField(
                                        value = widevineLicenseUrl,
                                        onValueChange = { widevineLicenseUrl = it },
                                        placeholder = { Text("https://.../widevine/license", color = TextDarkGray, fontSize = 11.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 11.sp),
                                        singleLine = true
                                    )
                                }
                            }
                        }

                        // Custom Headers Expandable
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("4. OPTIONAL HEADERS (ANTI-HOTLINK):", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                OutlinedTextField(
                                    value = customUserAgent,
                                    onValueChange = { customUserAgent = it },
                                    placeholder = { Text("User-Agent (e.g. ExoPlayer or Chrome)", color = TextDarkGray, fontSize = 11.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 11.sp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = customReferer,
                                    onValueChange = { customReferer = it },
                                    placeholder = { Text("Referer (e.g. https://www.hotstar.com/)", color = TextDarkGray, fontSize = 11.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 11.sp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = customCookie,
                                    onValueChange = { customCookie = it },
                                    placeholder = { Text("Cookie / Token (e.g. hdnts=...)", color = TextDarkGray, fontSize = 11.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 11.sp),
                                    singleLine = true
                                )
                            }
                        }
                    } else {
                        // ==========================================
                        // TAB 1: M3U / JSON Playlist Importer
                        // ==========================================
                        item {
                            Text("ENTER M3U PLAYLIST OR JSON URL:", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = playlistInput,
                                onValueChange = { playlistInput = it },
                                placeholder = { Text("https://example.com/playlist.m3u or JSON URL", color = TextDarkGray, fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = androidx.compose.ui.text.TextStyle(color = TextWhite, fontSize = 12.sp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OrangeTab,
                                    unfocusedBorderColor = CardBorderOrange.copy(alpha = 0.4f)
                                )
                            )
                        }

                        item {
                            Button(
                                onClick = {
                                    val input = playlistInput.trim()
                                    if (input.isBlank()) {
                                        Toast.makeText(context, "Please enter an M3U or JSON URL", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    isPlaylistLoading = true
                                    scope.launch {
                                        try {
                                            val content = if (input.startsWith("http://") || input.startsWith("https://")) {
                                                M3uParser.fetchFromUrl(input)
                                            } else {
                                                input
                                            }
                                            val items = if (content.trim().startsWith("[") || content.trim().startsWith("{")) {
                                                M3uParser.parseJson(content)
                                            } else {
                                                M3uParser.parseM3u(content)
                                            }
                                            parsedChannels = items
                                            if (items.isEmpty()) {
                                                Toast.makeText(context, "No channels found in JSON", Toast.LENGTH_LONG).show()
                                            } else {
                                                Toast.makeText(context, "Loaded ${items.size} channels!", Toast.LENGTH_SHORT).show()
                                            }
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                                        } finally {
                                            isPlaylistLoading = false
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                if (isPlaylistLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = OrangeTab)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Downloading & Parsing...", color = OrangeTab, fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.Download, contentDescription = null, tint = OrangeTab, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("⚡ Fetch & Parse Playlist Channels", color = OrangeTab, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (parsedChannels.isNotEmpty()) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("CHANNELS FOUND (${parsedChannels.size}):", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    TextButton(onClick = { onPlayImportedChannels(parsedChannels) }) {
                                        Text("+ Add All to App Feed", color = OrangeTab, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            items(parsedChannels) { ch ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onPlayImportedChannels(listOf(ch))
                                        },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF181822)),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderOrange.copy(alpha = 0.2f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        AsyncChannelLogo(
                                            logoUrl = ch.logo,
                                            channelTitle = ch.title,
                                            modifier = Modifier.size(42.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(ch.title, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                if (ch.drm.enabled) {
                                                    Box(
                                                        modifier = Modifier
                                                            .background(Color(0xFF8B5CF6).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("DRM", color = Color(0xFFA78BFA), fontSize = 8.sp, fontWeight = FontWeight.Black)
                                                    }
                                                }
                                            }
                                            Text("${ch.category} • ${ch.streamType}", color = TextDarkGray, fontSize = 10.sp)
                                        }

                                        Icon(Icons.Default.PlayCircle, contentDescription = "Play", tint = OrangeTab, modifier = Modifier.size(24.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action Button (for Tab 0)
                if (inputTab == 0) {
                    Button(
                        onClick = {
                            val url = streamUrl.trim()
                            if (url.isBlank()) {
                                Toast.makeText(context, "Please enter a valid Stream URL", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val headers = mutableMapOf<String, String>()
                            if (customUserAgent.isNotBlank()) headers["User-Agent"] = customUserAgent.trim()
                            if (customReferer.isNotBlank()) headers["Referer"] = customReferer.trim()
                            if (customCookie.isNotBlank()) headers["Cookie"] = customCookie.trim()

                            val drm = when (drmType) {
                                "clearkey" -> DrmConfig(
                                    enabled = true,
                                    scheme = "clearkey",
                                    keyId = clearkeyId.trim(),
                                    key = clearkeyKey.trim()
                                )
                                "widevine" -> DrmConfig(
                                    enabled = true,
                                    scheme = "widevine",
                                    key = widevineLicenseUrl.trim(),
                                    licenseUrl = widevineLicenseUrl.trim()
                                )
                                else -> DrmConfig(enabled = false)
                            }

                            val title = streamTitle.ifBlank { "Live Stream Channel" }
                            onPlayDirectStream(url, title, drm, headers)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = OrangeTab),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("▶ PLAY IN VIDEO PLAYER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

/**
 * Screen 5: Movies & Web Series Tab (Cinex Full 160+ Titles JSON)
 */
@Composable
private fun MoviesTabContent(
    streamRepository: StreamRepository,
    searchQuery: String,
    favoriteUrls: Set<String>,
    onToggleFavorite: (ParsedChannelItem) -> Unit,
    onPlayStreamSource: (StreamSource, List<ParsedChannelItem>) -> Unit
) {
    val context = LocalContext.current
    var movies by remember { mutableStateOf<List<CinexMovieItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedGenre by remember { mutableStateOf("All") }
    var activeMovieForDetail by remember { mutableStateOf<CinexMovieItem?>(null) }
    var localSearch by remember { mutableStateOf("") }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey) {
        isLoading = true
        try {
            val list = streamRepository.getMoviesFeed(context)
            movies = list
        } catch (_: Exception) {
        } finally {
            isLoading = false
        }
    }

    // Dynamic Genre Chips extracted from 160 movies
    val genreList = remember(movies) {
        val genres = linkedSetOf<String>()
        genres.add("All")
        for (m in movies) {
            val cats = m.categories.split(",")
            for (c in cats) {
                val clean = c.trim()
                if (clean.isNotBlank() && clean.length > 2 && !clean.all { it.isDigit() }) {
                    genres.add(clean)
                }
            }
        }
        genres.toList().take(20)
    }

    val effectiveSearch = if (searchQuery.isNotBlank()) searchQuery else localSearch

    val filteredMovies = remember(movies, effectiveSearch, selectedGenre) {
        movies.filter { m ->
            val matchesSearch = if (effectiveSearch.isBlank()) true else {
                m.title.contains(effectiveSearch, ignoreCase = true) ||
                m.heading.contains(effectiveSearch, ignoreCase = true) ||
                m.categories.contains(effectiveSearch, ignoreCase = true) ||
                m.metadata.stars.any { it.contains(effectiveSearch, ignoreCase = true) } ||
                m.metadata.director.contains(effectiveSearch, ignoreCase = true)
            }
            val matchesGenre = if (selectedGenre == "All") true else {
                m.categories.contains(selectedGenre, ignoreCase = true) ||
                m.metadata.genre.any { it.equals(selectedGenre, ignoreCase = true) }
            }
            matchesSearch && matchesGenre
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0B10))
    ) {
        // Search & Refresh Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = localSearch,
                onValueChange = { localSearch = it },
                placeholder = {
                    Text(
                        text = "Search 160+ Movies & Series...",
                        color = Color(0xFF7A7D94),
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OrangeTab,
                    unfocusedBorderColor = Color(0xFF222334),
                    focusedContainerColor = Color(0xFF141522),
                    unfocusedContainerColor = Color(0xFF141522),
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = OrangeTab, modifier = Modifier.size(18.dp))
                },
                trailingIcon = {
                    if (localSearch.isNotEmpty()) {
                        IconButton(onClick = { localSearch = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextGray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            )

            var isRefFocused by remember { mutableStateOf(false) }
            IconButton(
                onClick = { refreshKey++ },
                modifier = Modifier
                    .size(40.dp)
                    .onFocusChanged { isRefFocused = it.isFocused }
                    .focusable()
                    .border(if (isRefFocused) 2.dp else 0.dp, Color(0xFFFF9800), CircleShape)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextWhite)
            }
        }

        // Horizontal Genre Filter Chips
        if (!isLoading && movies.isNotEmpty()) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(genreList) { genre ->
                    val isSelected = (genre == selectedGenre)
                    var isChipFocused by remember { mutableStateOf(false) }
                    val label = if (genre == "All") "All • ${movies.size}" else genre
                    Surface(
                        onClick = { selectedGenre = genre },
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) Color(0xFFE65100) else if (isChipFocused) Color(0xFF26273B) else Color(0xFF161724),
                        border = BorderStroke(
                            if (isChipFocused) 2.dp else 1.dp,
                            if (isChipFocused) Color(0xFFFF9800) else if (isSelected) Color(0xFFFF9800) else Color(0xFF252638)
                        ),
                        modifier = Modifier
                            .onFocusChanged { isChipFocused = it.isFocused }
                            .focusable()
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) TextWhite else Color(0xFFB0B3C7),
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Poster Grid (3 Columns)
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(color = OrangeTab)
                    Text("Loading Cinex Movies & Series...", color = TextGray, fontSize = 13.sp)
                }
            }
        } else if (filteredMovies.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No movies found", color = TextGray, fontSize = 14.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredMovies, key = { it.id }) { movie ->
                    val primaryStreamUrl = movie.channels.firstOrNull()?.streamUrl ?: ""
                    val isFav = favoriteUrls.contains(primaryStreamUrl)
                    MoviePosterCard(
                        movie = movie,
                        isFavorite = isFav,
                        onToggleFavorite = {
                            if (primaryStreamUrl.isNotBlank()) {
                                onToggleFavorite(
                                    ParsedChannelItem(
                                        title = movie.title,
                                        streamUrl = primaryStreamUrl,
                                        logo = movie.poster,
                                        category = movie.categories.split(",").firstOrNull()?.trim() ?: "Movies",
                                        quality = movie.metadata.quality.ifBlank { "HD" }
                                    )
                                )
                            }
                        },
                        onClick = {
                            activeMovieForDetail = movie
                        }
                    )
                }
            }
        }
    }

    // Movie Detail / Episode Selector Dialog
    if (activeMovieForDetail != null) {
        val currentMovie = activeMovieForDetail!!
        MovieDetailDialog(
            movie = currentMovie,
            onDismiss = { activeMovieForDetail = null },
            onPlayChannel = { ch: CinexMovieChannel ->
                activeMovieForDetail = null
                ExoPlayerHelper.releaseActivePlayer()
                val src = StreamSource(
                    id = "cinex_${currentMovie.id}_${ch.id}",
                    title = "${currentMovie.heading.ifBlank { currentMovie.title }} - ${ch.name}",
                    streamType = ExoPlayerHelper.detectStreamType(ch.streamUrl, ch.streamType),
                    streamUrl = ch.streamUrl,
                    quality = currentMovie.metadata.quality.ifBlank { "1080p HD" }
                )
                val movieChannels = currentMovie.channels.map { mc ->
                    ParsedChannelItem(
                        title = "${currentMovie.heading.ifBlank { currentMovie.title }} - ${mc.name}",
                        streamUrl = mc.streamUrl,
                        streamType = ExoPlayerHelper.detectStreamType(mc.streamUrl, mc.streamType),
                        category = "Movies",
                        quality = currentMovie.metadata.quality.ifBlank { "1080p HD" }
                    )
                }
                onPlayStreamSource(src, movieChannels)
            }
        )
    }
}

@Composable
private fun MoviePosterCard(
    movie: CinexMovieItem,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(154.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isFocused) Color(0xFF24263D) else Color(0xFF13141F)
        ),
        border = if (isFocused) BorderStroke(2.5.dp, Color(0xFFFF9800)) else BorderStroke(1.dp, Color(0xFF222335))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Upper Box: Circular Logo (64dp, exactly matching Category) + Quality + Heart Favorite
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(82.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncMoviePoster(
                    posterUrl = movie.poster,
                    title = movie.title,
                    modifier = Modifier.size(64.dp),
                    isCircle = true
                )

                // Quality Badge (Top-Left)
                val qualityText = movie.metadata.quality.ifBlank { "HD" }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFE65100).copy(alpha = 0.9f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = qualityText,
                        color = Color.White,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Top-Right Heart / Favorite Toggle Button
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(30.dp)
                        .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                        .padding(2.dp)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) LiveRed else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Episodes/Servers count pill (Bottom-Right if multiple)
                if (movie.channels.size > 1) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Black.copy(alpha = 0.8f))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${movie.channels.size} EPs",
                            color = OrangeTab,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Lower: Title & Subtitle (Generous 2-column width)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = (movie.heading.ifBlank { movie.title }).uppercase(),
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = movie.metadata.language.ifBlank { "Movie / Series" },
                        color = Color(0xFF8E90A6),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (movie.metadata.imdbRating.isNotBlank() && movie.metadata.imdbRating != "X/10") {
                        Text(
                            text = "★ ${movie.metadata.imdbRating}",
                            color = Color(0xFFFFB74D),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MovieDetailDialog(
    movie: CinexMovieItem,
    onDismiss: () -> Unit,
    onPlayChannel: (CinexMovieChannel) -> Unit
) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF141520)),
            border = BorderStroke(1.dp, Color(0xFF282A3E))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Top Row: Poster & Metadata
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(90.dp)
                            .height(130.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF222335))
                    ) {
                        AsyncMoviePoster(
                            posterUrl = movie.poster,
                            title = movie.title,
                            modifier = Modifier.fillMaxSize(),
                            isCircle = false
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = movie.heading.ifBlank { movie.title },
                            color = TextWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFE65100))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = movie.metadata.quality.ifBlank { "1080p HD" },
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = movie.metadata.language.ifBlank { "Dual Audio" },
                                color = UpcomingCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (movie.metadata.stars.isNotEmpty()) {
                            Text(
                                text = "Cast: ${movie.metadata.stars.take(3).joinToString(", ")}",
                                color = Color(0xFF9EA1B8),
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (movie.metadata.director.isNotBlank()) {
                            Text(
                                text = "Director: ${movie.metadata.director}",
                                color = Color(0xFF7A7D94),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Trailer Link (if available)
                        if (movie.trailer.embedUrl.isNotBlank()) {
                            Text(
                                text = "▶ Watch Trailer",
                                color = OrangeTab,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable {
                                    try {
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(movie.trailer.embedUrl))
                                        context.startActivity(intent)
                                    } catch (_: Exception) {}
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = Color(0xFF26273B))
                Spacer(modifier = Modifier.height(10.dp))

                // Episodes or Play Stream List
                Text(
                    text = if (movie.channels.size > 1) "SELECT EPISODE / SERVER (${movie.channels.size})" else "STREAM SERVER",
                    color = OrangeTab,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(movie.channels) { ch ->
                        var isEpFocused by remember { mutableStateOf(false) }
                        Surface(
                            onClick = { onPlayChannel(ch) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isEpFocused) Color(0xFF332015) else Color(0xFF1B1C2A),
                            border = BorderStroke(
                                if (isEpFocused) 2.dp else 1.dp,
                                if (isEpFocused) Color(0xFFFF9800) else Color(0xFF2B2D42)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { isEpFocused = it.isFocused }
                                .focusable()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircle,
                                        contentDescription = "Play",
                                        tint = OrangeTab,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = ch.name,
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF10B981).copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "HLS 1080p",
                                        color = Color(0xFF10B981),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222436)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close", color = TextWhite, fontSize = 13.sp)
                }
            }
        }
    }
}

private val moviePosterCache = android.util.LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(200)

@Composable
private fun AsyncMoviePoster(
    posterUrl: String,
    title: String,
    modifier: Modifier = Modifier,
    isCircle: Boolean = true
) {
    val cleanUrl = remember(posterUrl) { posterUrl.replace("&amp;", "&").trim() }
    var bitmap by remember(cleanUrl) { mutableStateOf(if (cleanUrl.isNotBlank()) moviePosterCache.get(cleanUrl) else null) }

    LaunchedEffect(cleanUrl) {
        if (bitmap == null && cleanUrl.isNotBlank() && (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://"))) {
            withContext(Dispatchers.IO) {
                try {
                    val url = java.net.URL(cleanUrl)
                    val conn = url.openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 7000
                    conn.readTimeout = 7000
                    conn.instanceFollowRedirects = true
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile)")
                    conn.setRequestProperty("Accept", "image/png,image/*,*/*")
                    if (conn.responseCode in 200..299) {
                        val bytes = conn.inputStream.use { it.readBytes() }
                        val decoded = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (decoded != null) {
                            val imgBitmap = decoded.asImageBitmap()
                            moviePosterCache.put(cleanUrl, imgBitmap)
                            bitmap = imgBitmap
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    val shape = if (isCircle) CircleShape else RoundedCornerShape(10.dp)

    Box(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFF161824), shape)
            .border(1.5.dp, Color(0xFF2E3447), shape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = title,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (isCircle) 3.dp else 0.dp)
                    .clip(shape),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        } else {
            val initials = title.split(" ")
                .filter { it.isNotBlank() }
                .take(2)
                .map { it.first().uppercaseChar() }
                .joinToString("")
                .ifBlank { "MV" }

            Text(
                text = initials,
                color = OrangeTab,
                fontSize = if (isCircle) 17.sp else 22.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

private val matchBannerCache = android.util.LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(40)

@Composable
private fun AsyncMatchBanner(
    bannerUrl: String,
    title: String,
    modifier: Modifier = Modifier
) {
    val cleanUrl = remember(bannerUrl) { bannerUrl.replace("&amp;", "&").trim() }
    var bitmap by remember(cleanUrl) { mutableStateOf(if (cleanUrl.isNotBlank()) matchBannerCache.get(cleanUrl) else null) }

    LaunchedEffect(cleanUrl) {
        if (bitmap == null && cleanUrl.isNotBlank() && (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://"))) {
            withContext(Dispatchers.IO) {
                try {
                    val url = java.net.URL(cleanUrl)
                    val conn = url.openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 6000
                    conn.readTimeout = 6000
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    if (conn.responseCode == 200) {
                        val stream = conn.inputStream
                        val decoded = android.graphics.BitmapFactory.decodeStream(stream)
                        stream.close()
                        if (decoded != null) {
                            val imgBitmap = decoded.asImageBitmap()
                            matchBannerCache.put(cleanUrl, imgBitmap)
                            bitmap = imgBitmap
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!,
            contentDescription = title,
            modifier = modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
    } else {
        Box(
            modifier = modifier.background(
                Brush.linearGradient(
                    listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364))
                )
            ),
            contentAlignment = Alignment.Center
        ) {
            Text("🏏", fontSize = 42.sp)
        }
    }
}


