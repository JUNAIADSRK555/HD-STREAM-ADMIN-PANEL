package com.hdstream.live

import android.app.Application
import android.os.Bundle
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.hdstream.live.data.StreamRepository

class HDStreamApp : Application() {

    lateinit var streamRepository: StreamRepository
        private set

    var firebaseAnalytics: FirebaseAnalytics? = null
        private set

    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
            firebaseAnalytics = Firebase.analytics
            val bundle = Bundle().apply {
                putString("app_name", "HD STREAM")
                putString("version", "3.1.5")
                putLong("launch_timestamp", System.currentTimeMillis())
            }
            firebaseAnalytics?.logEvent("app_active_session", bundle)
        } catch (_: Exception) {}

        streamRepository = StreamRepository(this)
    }
}
