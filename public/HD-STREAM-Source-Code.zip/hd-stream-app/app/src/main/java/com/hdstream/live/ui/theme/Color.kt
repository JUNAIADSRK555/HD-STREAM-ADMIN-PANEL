package com.hdstream.live.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF000000)
val CardDark = Color(0xFF0F0F12)
val CardBorderOrange = Color(0xFFFF5722)
val CardBorderDark = Color(0xFF4A1A0B)
val OrangePrimary = Color(0xFFFF5722)
val OrangeTab = Color(0xFFFF6D00)
val LiveRed = Color(0xFFFF1744)
val UpcomingCyan = Color(0xFF00E5FF)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFA0A0A0)
val TextDarkGray = Color(0xFF666666)
val DialogBg = Color(0xFF262626)
val AccentGreen = Color(0xFF10B981)
