package com.hdstream.live

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.hdstream.live.model.StreamSource
import com.hdstream.live.player.ExoPlayerHelper
import com.hdstream.live.player.ParsedChannelItem
import com.hdstream.live.ui.screens.HomeScreen
import com.hdstream.live.ui.screens.PlayerScreen
import com.hdstream.live.ui.theme.HDStreamTheme
import com.hdstream.live.util.DeviceUtils

class MainActivity : ComponentActivity() {

    companion object {
        // High-priority TV Remote key listener for active PlayerScreen
        var playerKeyEventListener: ((KeyEvent) -> Boolean)? = null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Give active Video Player full priority over TV remote D-Pad, OK, and media keys
        val listener = playerKeyEventListener
        if (listener != null && listener(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android TV / Fire TV Stick / Mi Box Environment Detection
        if (DeviceUtils.isTv(this)) {
            // Lock to Landscape on TV/Firestick/Mi Box for true 16:9 big-screen TV experience
            try {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } catch (_: Exception) {}
        }

        // 1. Enable true edge-to-edge window rendering without system window fit letterboxing
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // 2. Extend window into camera cutouts and notches on all edges (eliminates left/right notch pillarbox)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = lp
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val app = application as HDStreamApp
        val streamRepository = app.streamRepository

        // Track First Install & Active User Graphics in Firebase Analytics
        try {
            val prefs = getSharedPreferences("hd_analytics_meta", MODE_PRIVATE)
            val isFirstInstall = !prefs.getBoolean("has_logged_install", false)
            if (isFirstInstall) {
                prefs.edit().putBoolean("has_logged_install", true).putLong("installed_at", System.currentTimeMillis()).apply()
                val installBundle = Bundle().apply {
                    putString("event_type", "apk_first_installed")
                    putString("app_name", "HD STREAM")
                    putLong("timestamp", System.currentTimeMillis())
                }
                app.firebaseAnalytics?.logEvent("apk_install_success", installBundle)
            }
            val activeBundle = Bundle().apply {
                putString("device_model", Build.MODEL)
                putString("os_version", "Android ${Build.VERSION.RELEASE}")
            }
            app.firebaseAnalytics?.logEvent("active_device_ping", activeBundle)
        } catch (_: Exception) {}

        setContent {
            HDStreamTheme {
                var activeStreamSource by remember { mutableStateOf<StreamSource?>(null) }
                var activeCategoryChannels by remember { mutableStateOf<List<ParsedChannelItem>>(emptyList()) }

                Box(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(
                        streamRepository = streamRepository,
                        onPlayStreamSource = { streamSource, channels ->
                            ExoPlayerHelper.releaseActivePlayer()
                            activeStreamSource = streamSource
                            activeCategoryChannels = channels
                        }
                    )

                    if (activeStreamSource != null) {
                        PlayerScreen(
                            streamSource = activeStreamSource!!,
                            categoryChannels = activeCategoryChannels,
                            onSelectChannel = { newSource ->
                                ExoPlayerHelper.releaseActivePlayer()
                                activeStreamSource = newSource
                            },
                            streamRepository = streamRepository,
                            onNavigateBack = {
                                ExoPlayerHelper.releaseActivePlayer()
                                activeStreamSource = null
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (DeviceUtils.isTv(this)) {
            try {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } catch (_: Exception) {}
        }
    }

    override fun onPause() {
        super.onPause()
        ExoPlayerHelper.pauseActivePlayer()
    }

    override fun onStop() {
        super.onStop()
        ExoPlayerHelper.pauseActivePlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        ExoPlayerHelper.releaseActivePlayer()
    }
}
