package com.hdstream.live.ui.screens

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.hdstream.live.R
import com.hdstream.live.data.StreamRepository
import com.hdstream.live.model.StreamSource
import com.hdstream.live.player.AudioTrackOption
import com.hdstream.live.player.ExoPlayerHelper
import com.hdstream.live.player.ParsedChannelItem
import com.hdstream.live.player.VideoTrackOption
import com.hdstream.live.MainActivity
import com.hdstream.live.ui.theme.*
import com.hdstream.live.util.DeviceUtils

enum class TvPlayerFocus {
    PLAY_PAUSE,
    REWIND,
    FORWARD,
    TOP_BACK,
    TOP_LANG,
    TOP_QUALITY,
    BOTTOM_SPEED,
    BOTTOM_LANG,
    BOTTOM_ASPECT,
    BOTTOM_QUALITY,
    BOTTOM_FAV
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    streamSource: StreamSource,
    categoryChannels: List<ParsedChannelItem> = emptyList(),
    onSelectChannel: (StreamSource) -> Unit = {},
    streamRepository: StreamRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isTv = remember { DeviceUtils.isTv(context) }
    val favoritePrefs = remember { context.getSharedPreferences("hd_favorites", Context.MODE_PRIVATE) }
    var isFavorite by remember(streamSource.streamUrl) {
        val favs = favoritePrefs.getStringSet("fav_urls", emptySet()) ?: emptySet()
        mutableStateOf(favs.contains(streamSource.streamUrl))
    }

    var isFullscreen by remember { mutableStateOf(isTv) }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var reloadTrigger by remember { mutableIntStateOf(0) }

    // TV / Firestick / Mi Box 16:9 Landscape Lock
    LaunchedEffect(isTv) {
        if (isTv) {
            val act = context as? Activity
            try {
                act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } catch (_: Exception) {}
        }
    }

    // Physical orientation tracking
    val configuration = LocalConfiguration.current
    val isDeviceLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val effectiveFullscreen = isTv || isFullscreen || isDeviceLandscape

    // Video Quality State
    var selectedQualityLabel by remember { mutableStateOf("Auto") }
    var showQualityDialog by remember { mutableStateOf(false) }
    var availableQualities by remember { mutableStateOf<List<VideoTrackOption>>(emptyList()) }
    var tvQualityIndex by remember { mutableIntStateOf(0) }

    // Audio / Language State
    var selectedLanguageLabel by remember { mutableStateOf("Audio") }
    var showAudioDialog by remember { mutableStateOf(false) }
    var availableLanguages by remember { mutableStateOf<List<AudioTrackOption>>(emptyList()) }
    var tvAudioIndex by remember { mutableIntStateOf(0) }

    // TV Remote D-Pad Navigation State Machine
    var tvFocusItem by remember { mutableStateOf(TvPlayerFocus.PLAY_PAUSE) }

    // Screen Resize Modes: FIT / ZOOM / FILL
    val resizeModes = remember {
        listOf(
            Triple(AspectRatioFrameLayout.RESIZE_MODE_FIT, "FIT", "16:9 Standard"),
            Triple(AspectRatioFrameLayout.RESIZE_MODE_ZOOM, "ZOOM", "Crop to Fill"),
            Triple(AspectRatioFrameLayout.RESIZE_MODE_FILL, "FILL", "Stretch 100%")
        )
    }
    var resizeModeIndex by remember { mutableIntStateOf(1) } // Default: ZOOM (100% Fill, No Black Bars)
    var activePlayerView by remember { mutableStateOf<PlayerView?>(null) }

    fun applyResizeMode(newIndex: Int) {
        resizeModeIndex = newIndex
        val (mode, label, _) = resizeModes[newIndex]

        // 1. Configure ExoPlayer's video scaling mode
        player?.let { p ->
            p.videoScalingMode = when (mode) {
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                else -> C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            }
        }

        // 2. Immediately update PlayerView & AspectRatioFrameLayout
        activePlayerView?.let { pv ->
            pv.resizeMode = mode
            try {
                val cf = pv.findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)
                cf?.setResizeMode(mode)
                cf?.requestLayout()
            } catch (_: Exception) {}
            pv.videoSurfaceView?.requestLayout()
            pv.requestLayout()
        }

        Toast.makeText(context, "Mode: $label", Toast.LENGTH_SHORT).show()
    }

    // Player state tracking
    var isPlayerPreparing by remember { mutableStateOf(true) }
    var playbackErrorMessage by remember { mutableStateOf<String?>(null) }
    var autoRetryCount by remember { mutableIntStateOf(0) }
    var isAutoRetrying by remember { mutableStateOf(false) }

    // Controls timeout
    val scope = rememberCoroutineScope()
    var showControls by remember { mutableStateOf(true) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Network Connectivity Auto-Recovery: Seamlessly resume stream when network reconnects
    DisposableEffect(context) {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                scope.launch(Dispatchers.Main) {
                    if (playbackErrorMessage != null || isAutoRetrying || (player != null && player?.playbackState == androidx.media3.common.Player.STATE_IDLE)) {
                        playbackErrorMessage = null
                        isPlayerPreparing = true
                        autoRetryCount = 0
                        isAutoRetrying = false
                        try {
                            player?.seekToDefaultPosition()
                            player?.prepare()
                            player?.play()
                        } catch (_: Exception) {
                            reloadTrigger++
                        }
                    }
                }
            }
        }
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        try {
            connectivityManager?.registerNetworkCallback(request, networkCallback)
        } catch (_: Exception) {}

        onDispose {
            try {
                connectivityManager?.unregisterNetworkCallback(networkCallback)
            } catch (_: Exception) {}
        }
    }

    // Playback Progress & Seeking State
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var isPlayingState by remember { mutableStateOf(true) }
    var isUserExplicitlyPaused by remember { mutableStateOf(false) }
    var isUserScrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }

    // Quick Seek Overlay Feedback (-10s / +10s anim)
    var showSeekFeedback by remember { mutableStateOf(false) }
    var seekFeedbackText by remember { mutableStateOf("+10s") }
    var seekFeedbackJob by remember { mutableStateOf<Job?>(null) }

    // Controls Lock State
    var isControlsLocked by remember { mutableStateOf(false) }

    // Playback Speed State
    val speedOptions = remember { listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f) }
    var currentSpeedIndex by remember { mutableIntStateOf(1) } // Default: 1.0x

    // Volume & Brightness Gesture Controls
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var currentVolumePercent by remember {
        val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        mutableFloatStateOf(cur.toFloat() / maxVolume)
    }

    val act = context as? Activity
    var currentBrightness by remember {
        val b = act?.window?.attributes?.screenBrightness ?: -1f
        mutableFloatStateOf(if (b > 0f) b else 0.5f)
    }

    var showGestureOverlay by remember { mutableStateOf(false) }
    var gestureOverlayType by remember { mutableStateOf("VOLUME") }
    var gestureOverlayPercent by remember { mutableIntStateOf(50) }
    var gestureDismissJob by remember { mutableStateOf<Job?>(null) }

    // Periodic time & state updater loop
    LaunchedEffect(player) {
        while (true) {
            val p = player
            if (p != null) {
                if (!isUserScrubbing) {
                    currentPositionMs = p.currentPosition.coerceAtLeast(0L)
                    val dur = p.duration
                    totalDurationMs = if (dur > 0L) dur else 0L
                }
                isPlayingState = p.isPlaying
            }
            delay(500)
        }
    }

    // Auto-hide controls timer (5.5s on TV for easy remote navigation, 3.5s on phone)
    LaunchedEffect(showControls, lastInteractionTime, showQualityDialog, showAudioDialog) {
        if (showControls && !isControlsLocked && !showQualityDialog && !showAudioDialog) {
            delay(if (isTv) 5500L else 3500L)
            showControls = false
        }
    }

    // Synchronize video scaling mode & resize mode
    val currentResizeMode = resizeModes[resizeModeIndex].first
    LaunchedEffect(currentResizeMode, player) {
        player?.videoScalingMode = when (currentResizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            else -> C.VIDEO_SCALING_MODE_SCALE_TO_FIT
        }
        activePlayerView?.let { pv ->
            pv.resizeMode = currentResizeMode
            try {
                val cf = pv.findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)
                cf?.setResizeMode(currentResizeMode)
                cf?.requestLayout()
            } catch (_: Exception) {}
            pv.videoSurfaceView?.requestLayout()
            pv.requestLayout()
        }
    }

    // Safe seek function with visual HUD feedback
    fun triggerSeek(offsetMs: Long) {
        val p = player ?: return
        lastInteractionTime = System.currentTimeMillis()
        val current = p.currentPosition
        val dur = p.duration
        val target = current + offsetMs
        val safePos = if (dur > 0L) target.coerceIn(0L, dur) else target.coerceAtLeast(0L)
        p.seekTo(safePos)
        currentPositionMs = safePos

        seekFeedbackText = if (offsetMs >= 0) "+${offsetMs / 1000}s" else "${offsetMs / 1000}s"
        showSeekFeedback = true
        seekFeedbackJob?.cancel()
        seekFeedbackJob = scope.launch {
            delay(850)
            showSeekFeedback = false
        }
    }

    // Format milliseconds to mm:ss or hh:mm:ss
    fun formatMs(ms: Long): String {
        if (ms <= 0L) return "00:00"
        val totalSec = ms / 1000
        val hr = totalSec / 3600
        val min = (totalSec % 3600) / 60
        val sec = totalSec % 60
        return if (hr > 0) {
            String.format("%02d:%02d:%02d", hr, min, sec)
        } else {
            String.format("%02d:%02d", min, sec)
        }
    }

    // Edge-to-Edge System Bars
    LaunchedEffect(effectiveFullscreen) {
        val act = context as? Activity ?: return@LaunchedEffect
        val window = act.window ?: return@LaunchedEffect
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        if (effectiveFullscreen) {
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
            window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            val lp = window.attributes
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            insetsController.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Initialize player asynchronously
    LaunchedEffect(streamSource, reloadTrigger) {
        isPlayerPreparing = true
        isAutoRetrying = false
        autoRetryCount = 0
        playbackErrorMessage = null
        showControls = true
        lastInteractionTime = System.currentTimeMillis()

        player?.stop()
        player?.clearMediaItems()
        player?.release()
        player = null

        try {
            val preparedStream = withContext(Dispatchers.IO) {
                ExoPlayerHelper.prepareStreamAsync(streamSource)
            }
            val newPlayer = ExoPlayerHelper.createPlayer(context, preparedStream)
            newPlayer.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                    // Prevent accidental or system-induced auto-pause
                    if (!playWhenReady && !isUserExplicitlyPaused) {
                        newPlayer.play()
                    }
                }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        androidx.media3.common.Player.STATE_READY -> {
                            isPlayerPreparing = false
                            isAutoRetrying = false
                            autoRetryCount = 0
                            playbackErrorMessage = null
                            if (!isUserExplicitlyPaused && !newPlayer.isPlaying) {
                                newPlayer.play()
                            }
                        }
                        androidx.media3.common.Player.STATE_ENDED -> {
                            // If live stream dropped connection, attempt automatic reconnect
                            if (autoRetryCount < 5) {
                                autoRetryCount++
                                isAutoRetrying = true
                                scope.launch {
                                    delay(1500L)
                                    try {
                                        newPlayer.seekToDefaultPosition()
                                        newPlayer.prepare()
                                        newPlayer.play()
                                    } catch (_: Exception) {}
                                }
                            }
                        }
                    }
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    // Behind Live Window: Jump straight to live edge without interrupting user
                    if (error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                        try {
                            newPlayer.seekToDefaultPosition()
                            newPlayer.prepare()
                            newPlayer.play()
                            return
                        } catch (_: Exception) {}
                    }

                    // Network Fluctuation Auto-Retry: Retry up to 5 times with backoff
                    if (autoRetryCount < 5) {
                        autoRetryCount++
                        isAutoRetrying = true
                        isPlayerPreparing = true
                        playbackErrorMessage = null
                        scope.launch {
                            delay(1000L * autoRetryCount)
                            try {
                                newPlayer.seekToDefaultPosition()
                                newPlayer.prepare()
                                newPlayer.play()
                            } catch (_: Exception) {
                                reloadTrigger++
                            }
                        }
                    } else {
                        isAutoRetrying = false
                        isPlayerPreparing = false
                        playbackErrorMessage = error.message ?: "Playback error: Stream may be offline"
                    }
                }
                override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                    availableQualities = ExoPlayerHelper.getAvailableVideoQualities(newPlayer)
                    val langs = ExoPlayerHelper.getAvailableAudioLanguages(newPlayer)
                    availableLanguages = langs
                    val sel = langs.firstOrNull { it.isSelected }
                    if (sel != null) {
                        selectedLanguageLabel = sel.label
                    } else if (langs.isNotEmpty()) {
                        selectedLanguageLabel = langs.first().label
                    }
                }
            })
            player = newPlayer
            availableQualities = ExoPlayerHelper.getAvailableVideoQualities(newPlayer)
            val initialLangs = ExoPlayerHelper.getAvailableAudioLanguages(newPlayer)
            availableLanguages = initialLangs
            if (initialLangs.isNotEmpty()) {
                selectedLanguageLabel = initialLangs.first().label
            }
        } catch (e: Exception) {
            isPlayerPreparing = false
            playbackErrorMessage = e.message ?: "Failed to start stream"
        }
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, streamSource) {
        val act = context as? Activity
        val window = act?.window
        // Prevent screen sleep / timeout during playback on all devices
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> {
                    // Only pause if user minimizes app to background (Home button pressed)
                    player?.pause()
                }
                androidx.lifecycle.Lifecycle.Event.ON_START,
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> {
                    // Automatically resume if not manually paused by user
                    if (!isUserExplicitlyPaused && player != null) {
                        player?.play()
                    }
                }
                androidx.lifecycle.Lifecycle.Event.ON_DESTROY -> {
                    player?.stop()
                    player?.clearMediaItems()
                    player?.release()
                    player = null
                    ExoPlayerHelper.releaseActivePlayer()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            player?.stop()
            player?.clearMediaItems()
            player?.release()
            player = null
            ExoPlayerHelper.releaseActivePlayer()
            if (!isTv) {
                act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else {
                act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
            if (window != null) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    fun releasePlayerAndExit() {
        player?.stop()
        player?.clearMediaItems()
        player?.release()
        player = null
        ExoPlayerHelper.releaseActivePlayer()
        val act = context as? Activity
        if (isTv) {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        val window = act?.window
        if (window != null) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            val insetsController = WindowCompat.getInsetsController(window, window.decorView)
            insetsController.show(WindowInsetsCompat.Type.systemBars())
        }
        onNavigateBack()
    }

    // Intercept Back Button
    BackHandler {
        if (showQualityDialog) {
            showQualityDialog = false
        } else if (showAudioDialog) {
            showAudioDialog = false
        } else if (showControls && isTv) {
            showControls = false
        } else if (!isTv && isFullscreen) {
            isFullscreen = false
            val act = context as? Activity
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            val window = act?.window
            if (window != null) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.show(WindowInsetsCompat.Type.systemBars())
            }
        } else {
            releasePlayerAndExit()
        }
    }

    fun handleTvRemoteKeyDown(keyCode: Int): Boolean {
        // 1. Quality Selection Dialog Open
        if (showQualityDialog) {
            when (keyCode) {
                android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                    if (availableQualities.isNotEmpty()) {
                        tvQualityIndex = (tvQualityIndex - 1).coerceAtLeast(0)
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (availableQualities.isNotEmpty()) {
                        tvQualityIndex = (tvQualityIndex + 1).coerceAtMost(availableQualities.lastIndex)
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_CENTER,
                android.view.KeyEvent.KEYCODE_ENTER,
                android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (availableQualities.isNotEmpty() && tvQualityIndex in availableQualities.indices) {
                        val option = availableQualities[tvQualityIndex]
                        ExoPlayerHelper.setVideoQuality(player, option)
                        selectedQualityLabel = option.label
                        showQualityDialog = false
                        Toast.makeText(context, "Quality set to ${option.label}", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_BACK,
                android.view.KeyEvent.KEYCODE_ESCAPE -> {
                    showQualityDialog = false
                    return true
                }
                else -> return true
            }
        }

        // 2. Audio / Language Selection Dialog Open
        if (showAudioDialog) {
            when (keyCode) {
                android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                    if (availableLanguages.isNotEmpty()) {
                        tvAudioIndex = (tvAudioIndex - 1).coerceAtLeast(0)
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (availableLanguages.isNotEmpty()) {
                        tvAudioIndex = (tvAudioIndex + 1).coerceAtMost(availableLanguages.lastIndex)
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_CENTER,
                android.view.KeyEvent.KEYCODE_ENTER,
                android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (availableLanguages.isNotEmpty() && tvAudioIndex in availableLanguages.indices) {
                        val option = availableLanguages[tvAudioIndex]
                        ExoPlayerHelper.setAudioLanguage(player, option)
                        selectedLanguageLabel = option.label
                        showAudioDialog = false
                        Toast.makeText(context, "Audio set to: ${option.label}", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_BACK,
                android.view.KeyEvent.KEYCODE_ESCAPE -> {
                    showAudioDialog = false
                    return true
                }
                else -> return true
            }
        }

        // 3. Controls Hidden -> Wake up controls and execute immediate action
        if (!showControls) {
            when (keyCode) {
                android.view.KeyEvent.KEYCODE_DPAD_CENTER,
                android.view.KeyEvent.KEYCODE_ENTER,
                android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    showControls = true
                    tvFocusItem = TvPlayerFocus.PLAY_PAUSE
                    lastInteractionTime = System.currentTimeMillis()
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                    showControls = true
                    tvFocusItem = TvPlayerFocus.TOP_QUALITY
                    lastInteractionTime = System.currentTimeMillis()
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                    showControls = true
                    tvFocusItem = TvPlayerFocus.BOTTOM_QUALITY
                    lastInteractionTime = System.currentTimeMillis()
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_LEFT,
                android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    triggerSeek(-10000L)
                    showControls = true
                    tvFocusItem = TvPlayerFocus.REWIND
                    lastInteractionTime = System.currentTimeMillis()
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_RIGHT,
                android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    triggerSeek(10000L)
                    showControls = true
                    tvFocusItem = TvPlayerFocus.FORWARD
                    lastInteractionTime = System.currentTimeMillis()
                    return true
                }
                android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    player?.let { p ->
                        isUserExplicitlyPaused = p.isPlaying
                        if (p.isPlaying) p.pause() else p.play()
                        isPlayingState = p.isPlaying
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_MEDIA_PLAY -> {
                    isUserExplicitlyPaused = false
                    player?.play()
                    isPlayingState = true
                    return true
                }
                android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    isUserExplicitlyPaused = true
                    player?.pause()
                    isPlayingState = false
                    return true
                }
                android.view.KeyEvent.KEYCODE_BACK,
                android.view.KeyEvent.KEYCODE_ESCAPE -> {
                    releasePlayerAndExit()
                    return true
                }
                else -> return false
            }
        }

        // 4. Controls are Visible -> Full D-Pad Navigation & Orange Box Highlight
        lastInteractionTime = System.currentTimeMillis()

        when (keyCode) {
            android.view.KeyEvent.KEYCODE_BACK,
            android.view.KeyEvent.KEYCODE_ESCAPE -> {
                showControls = false
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                player?.let { p ->
                    isUserExplicitlyPaused = p.isPlaying
                    if (p.isPlaying) p.pause() else p.play()
                    isPlayingState = p.isPlaying
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                tvFocusItem = when (tvFocusItem) {
                    TvPlayerFocus.FORWARD -> TvPlayerFocus.PLAY_PAUSE
                    TvPlayerFocus.PLAY_PAUSE -> TvPlayerFocus.REWIND
                    TvPlayerFocus.REWIND -> TvPlayerFocus.REWIND

                    TvPlayerFocus.TOP_QUALITY -> TvPlayerFocus.TOP_LANG
                    TvPlayerFocus.TOP_LANG -> TvPlayerFocus.TOP_BACK
                    TvPlayerFocus.TOP_BACK -> TvPlayerFocus.TOP_BACK

                    TvPlayerFocus.BOTTOM_FAV -> TvPlayerFocus.BOTTOM_QUALITY
                    TvPlayerFocus.BOTTOM_QUALITY -> TvPlayerFocus.BOTTOM_ASPECT
                    TvPlayerFocus.BOTTOM_ASPECT -> TvPlayerFocus.BOTTOM_LANG
                    TvPlayerFocus.BOTTOM_LANG -> TvPlayerFocus.BOTTOM_SPEED
                    TvPlayerFocus.BOTTOM_SPEED -> TvPlayerFocus.BOTTOM_SPEED
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                tvFocusItem = when (tvFocusItem) {
                    TvPlayerFocus.REWIND -> TvPlayerFocus.PLAY_PAUSE
                    TvPlayerFocus.PLAY_PAUSE -> TvPlayerFocus.FORWARD
                    TvPlayerFocus.FORWARD -> TvPlayerFocus.FORWARD

                    TvPlayerFocus.TOP_BACK -> TvPlayerFocus.TOP_LANG
                    TvPlayerFocus.TOP_LANG -> TvPlayerFocus.TOP_QUALITY
                    TvPlayerFocus.TOP_QUALITY -> TvPlayerFocus.TOP_QUALITY

                    TvPlayerFocus.BOTTOM_SPEED -> TvPlayerFocus.BOTTOM_LANG
                    TvPlayerFocus.BOTTOM_LANG -> TvPlayerFocus.BOTTOM_ASPECT
                    TvPlayerFocus.BOTTOM_ASPECT -> TvPlayerFocus.BOTTOM_QUALITY
                    TvPlayerFocus.BOTTOM_QUALITY -> TvPlayerFocus.BOTTOM_FAV
                    TvPlayerFocus.BOTTOM_FAV -> TvPlayerFocus.BOTTOM_FAV
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                tvFocusItem = when (tvFocusItem) {
                    TvPlayerFocus.BOTTOM_SPEED, TvPlayerFocus.BOTTOM_LANG -> TvPlayerFocus.REWIND
                    TvPlayerFocus.BOTTOM_ASPECT -> TvPlayerFocus.PLAY_PAUSE
                    TvPlayerFocus.BOTTOM_QUALITY, TvPlayerFocus.BOTTOM_FAV -> TvPlayerFocus.FORWARD

                    TvPlayerFocus.REWIND -> TvPlayerFocus.TOP_BACK
                    TvPlayerFocus.PLAY_PAUSE -> TvPlayerFocus.TOP_LANG
                    TvPlayerFocus.FORWARD -> TvPlayerFocus.TOP_QUALITY

                    TvPlayerFocus.TOP_BACK, TvPlayerFocus.TOP_LANG, TvPlayerFocus.TOP_QUALITY -> tvFocusItem
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                tvFocusItem = when (tvFocusItem) {
                    TvPlayerFocus.TOP_BACK -> TvPlayerFocus.REWIND
                    TvPlayerFocus.TOP_LANG -> TvPlayerFocus.PLAY_PAUSE
                    TvPlayerFocus.TOP_QUALITY -> TvPlayerFocus.FORWARD

                    TvPlayerFocus.REWIND -> TvPlayerFocus.BOTTOM_SPEED
                    TvPlayerFocus.PLAY_PAUSE -> TvPlayerFocus.BOTTOM_ASPECT
                    TvPlayerFocus.FORWARD -> TvPlayerFocus.BOTTOM_QUALITY

                    TvPlayerFocus.BOTTOM_SPEED, TvPlayerFocus.BOTTOM_LANG,
                    TvPlayerFocus.BOTTOM_ASPECT, TvPlayerFocus.BOTTOM_QUALITY,
                    TvPlayerFocus.BOTTOM_FAV -> tvFocusItem
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                when (tvFocusItem) {
                    TvPlayerFocus.PLAY_PAUSE -> {
                        player?.let { p ->
                            isUserExplicitlyPaused = p.isPlaying
                            if (p.isPlaying) p.pause() else p.play()
                            isPlayingState = p.isPlaying
                        }
                    }
                    TvPlayerFocus.REWIND -> {
                        triggerSeek(-10000L)
                    }
                    TvPlayerFocus.FORWARD -> {
                        triggerSeek(10000L)
                    }
                    TvPlayerFocus.TOP_BACK -> {
                        releasePlayerAndExit()
                    }
                    TvPlayerFocus.TOP_LANG, TvPlayerFocus.BOTTOM_LANG -> {
                        tvAudioIndex = availableLanguages.indexOfFirst { it.label == selectedLanguageLabel }.coerceAtLeast(0)
                        showAudioDialog = true
                    }
                    TvPlayerFocus.TOP_QUALITY, TvPlayerFocus.BOTTOM_QUALITY -> {
                        tvQualityIndex = availableQualities.indexOfFirst { it.label == selectedQualityLabel }.coerceAtLeast(0)
                        showQualityDialog = true
                    }
                    TvPlayerFocus.BOTTOM_SPEED -> {
                        currentSpeedIndex = (currentSpeedIndex + 1) % speedOptions.size
                        val spd = speedOptions[currentSpeedIndex]
                        player?.setPlaybackSpeed(spd)
                        Toast.makeText(context, "Speed: ${spd}x", Toast.LENGTH_SHORT).show()
                    }
                    TvPlayerFocus.BOTTOM_ASPECT -> {
                        applyResizeMode((resizeModeIndex + 1) % resizeModes.size)
                    }
                    TvPlayerFocus.BOTTOM_FAV -> {
                        val favs = favoritePrefs.getStringSet("fav_urls", emptySet())?.toMutableSet() ?: mutableSetOf()
                        val newFavState = !isFavorite
                        if (newFavState) {
                            favs.add(streamSource.streamUrl)
                            Toast.makeText(context, "Added to Favorites ❤️", Toast.LENGTH_SHORT).show()
                        } else {
                            favs.remove(streamSource.streamUrl)
                            Toast.makeText(context, "Removed from Favorites", Toast.LENGTH_SHORT).show()
                        }
                        favoritePrefs.edit().putStringSet("fav_urls", favs).apply()
                        isFavorite = newFavState
                    }
                }
                return true
            }

            else -> return false
        }
    }

    // Register hardware TV Remote listener with MainActivity
    DisposableEffect(Unit) {
        MainActivity.playerKeyEventListener = { keyEvent ->
            if (keyEvent.action == android.view.KeyEvent.ACTION_DOWN) {
                handleTvRemoteKeyDown(keyEvent.keyCode)
            } else {
                when (keyEvent.keyCode) {
                    android.view.KeyEvent.KEYCODE_DPAD_UP,
                    android.view.KeyEvent.KEYCODE_DPAD_DOWN,
                    android.view.KeyEvent.KEYCODE_DPAD_LEFT,
                    android.view.KeyEvent.KEYCODE_DPAD_RIGHT,
                    android.view.KeyEvent.KEYCODE_DPAD_CENTER,
                    android.view.KeyEvent.KEYCODE_ENTER,
                    android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
                    android.view.KeyEvent.KEYCODE_BACK,
                    android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                    android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
                    android.view.KeyEvent.KEYCODE_MEDIA_PAUSE,
                    android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
                    android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> true
                    else -> false
                }
            }
        }
        onDispose {
            MainActivity.playerKeyEventListener = null
        }
    }

    @Composable
    fun VideoPlayerView(
        modifier: Modifier,
        isPortraitMode: Boolean
    ) {
        var lastTapTime by remember { mutableLongStateOf(0L) }
        var lastTapX by remember { mutableFloatStateOf(0f) }

        // TV & Firestick Remote Focus Controller
        val tvFocusRequester = remember { FocusRequester() }
        val playPauseFocusRequester = remember { FocusRequester() }

        // Seamless Focus Transfer to Play/Pause when controls are visible
        LaunchedEffect(showControls) {
            if (showControls) {
                delay(120)
                try {
                    playPauseFocusRequester.requestFocus()
                } catch (_: Exception) {}
            } else {
                try {
                    tvFocusRequester.requestFocus()
                } catch (_: Exception) {}
            }
        }

        Box(
            modifier = modifier
                .focusRequester(tvFocusRequester)
                .focusable(enabled = !showControls)
                .clipToBounds()
                .background(Color.Black)
                .onKeyEvent { keyEvent ->
                    if (keyEvent.type == KeyEventType.KeyDown) {
                        when (keyEvent.key) {
                            Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                                if (!showControls) {
                                    showControls = true
                                    lastInteractionTime = System.currentTimeMillis()
                                    true
                                } else {
                                    // When controls are visible, let Compose focus handle click on the focused button
                                    false
                                }
                            }
                            Key.MediaPlayPause -> {
                                player?.let { p ->
                                    isUserExplicitlyPaused = p.isPlaying
                                    if (p.isPlaying) p.pause() else p.play()
                                    isPlayingState = p.isPlaying
                                }
                                true
                            }
                            Key.MediaPlay -> {
                                isUserExplicitlyPaused = false
                                player?.play()
                                isPlayingState = true
                                true
                            }
                            Key.MediaPause -> {
                                isUserExplicitlyPaused = true
                                player?.pause()
                                isPlayingState = false
                                true
                            }
                            Key.DirectionLeft, Key.MediaRewind -> {
                                if (!showControls) {
                                    triggerSeek(-10000L)
                                    showControls = true
                                    true
                                } else {
                                    // Controls visible: let focus move to left button
                                    false
                                }
                            }
                            Key.DirectionRight, Key.MediaFastForward -> {
                                if (!showControls) {
                                    triggerSeek(10000L)
                                    showControls = true
                                    true
                                } else {
                                    // Controls visible: let focus move to right button
                                    false
                                }
                            }
                            Key.DirectionUp -> {
                                if (!showControls) {
                                    showControls = true
                                    lastInteractionTime = System.currentTimeMillis()
                                    true
                                } else {
                                    // Controls visible: let focus move up to top bar or action buttons
                                    false
                                }
                            }
                            Key.DirectionDown -> {
                                if (!showControls) {
                                    showControls = true
                                    lastInteractionTime = System.currentTimeMillis()
                                    true
                                } else {
                                    // Controls visible: let focus move down to bottom controls
                                    false
                                }
                            }
                            Key.Back, Key.Escape -> {
                                if (showControls) {
                                    showControls = false
                                    true
                                } else {
                                    player?.stop()
                                    player?.clearMediaItems()
                                    player?.release()
                                    player = null
                                    ExoPlayerHelper.releaseActivePlayer()
                                    val act = context as? Activity
                                    if (!isTv) {
                                        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    } else {
                                        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    }
                                    onNavigateBack()
                                    true
                                }
                            }
                            else -> false
                        }
                    } else {
                        false
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val startX = down.position.x
                        val isRightSide = startX > (size.width / 2)
                        var isDragging = false
                        var totalDragDistanceY = 0f

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            if (!change.pressed) {
                                if (!isDragging) {
                                    val now = System.currentTimeMillis()
                                    if (now - lastTapTime < 350L && abs(startX - lastTapX) < 140f) {
                                        // Double tap seeking
                                        if (startX < size.width * 0.35f) {
                                            triggerSeek(-10000L)
                                        } else if (startX > size.width * 0.65f) {
                                            triggerSeek(10000L)
                                        } else {
                                            if (!isControlsLocked) {
                                                showControls = !showControls
                                                lastInteractionTime = System.currentTimeMillis()
                                            }
                                        }
                                        lastTapTime = 0L
                                    } else {
                                        lastTapTime = now
                                        lastTapX = startX
                                        if (!isControlsLocked) {
                                            showControls = !showControls
                                            lastInteractionTime = System.currentTimeMillis()
                                        }
                                    }
                                } else {
                                    gestureDismissJob?.cancel()
                                    gestureDismissJob = scope.launch {
                                        delay(1200)
                                        showGestureOverlay = false
                                    }
                                }
                                break
                            }

                            val dragDeltaY = change.position.y - change.previousPosition.y
                            totalDragDistanceY += dragDeltaY

                            if (!isDragging && abs(totalDragDistanceY) > 12f) {
                                isDragging = true
                                showGestureOverlay = true
                            }

                            if (isDragging) {
                                change.consume()
                                val deltaFraction = -dragDeltaY / (size.height * 0.75f)

                                if (isRightSide) {
                                    val newBright = (currentBrightness + deltaFraction).coerceIn(0.01f, 1.0f)
                                    currentBrightness = newBright
                                    val lp = act?.window?.attributes
                                    if (lp != null) {
                                        lp.screenBrightness = newBright
                                        act.window.attributes = lp
                                    }
                                    gestureOverlayType = "BRIGHTNESS"
                                    gestureOverlayPercent = (newBright * 100).toInt().coerceIn(1, 100)
                                } else {
                                    val newVol = (currentVolumePercent + deltaFraction).coerceIn(0f, 1.0f)
                                    currentVolumePercent = newVol
                                    val targetStreamVol = (newVol * maxVolume).toInt().coerceIn(0, maxVolume)
                                    try {
                                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetStreamVol, 0)
                                    } catch (_: Exception) {}
                                    player?.volume = newVol
                                    gestureOverlayType = "VOLUME"
                                    gestureOverlayPercent = (newVol * 100).toInt().coerceIn(0, 100)
                                }
                                showGestureOverlay = true
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            if (player != null) {
                AndroidView(
                    factory = { ctx ->
                        val view = LayoutInflater.from(ctx).inflate(R.layout.media3_texture_player_view, null) as PlayerView
                        val targetMode = resizeModes[resizeModeIndex].first
                        view.apply {
                            this.player = player
                            keepScreenOn = true
                            useController = false
                            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                            setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                            resizeMode = targetMode
                            isFocusable = false
                            isFocusableInTouchMode = false
                            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                            try {
                                findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)?.setResizeMode(targetMode)
                            } catch (_: Exception) {}
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                        activePlayerView = view
                        view
                    },
                    update = { view ->
                        activePlayerView = view
                        if (view.player != player) {
                            view.player = player
                        }
                        val targetMode = resizeModes[resizeModeIndex].first
                        if (view.resizeMode != targetMode) {
                            view.resizeMode = targetMode
                            try {
                                val cf = view.findViewById<AspectRatioFrameLayout>(androidx.media3.ui.R.id.exo_content_frame)
                                cf?.setResizeMode(targetMode)
                                cf?.requestLayout()
                            } catch (_: Exception) {}
                            view.videoSurfaceView?.requestLayout()
                            view.requestLayout()
                        }
                    },
                    modifier = Modifier.fillMaxSize().clipToBounds()
                )
            }

            // Central Volume & Brightness HUD
            androidx.compose.animation.AnimatedVisibility(
                visible = showGestureOverlay,
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.85f))
                        .border(
                            1.5.dp,
                            if (gestureOverlayType == "BRIGHTNESS") Color(0xFFFFB74D) else Color(0xFF10B981),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (gestureOverlayType == "BRIGHTNESS") {
                            Icon(
                                imageVector = Icons.Default.BrightnessMedium,
                                contentDescription = "Brightness",
                                tint = Color(0xFFFFB74D),
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "Brightness: $gestureOverlayPercent%",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            val volIcon = if (gestureOverlayPercent == 0) Icons.Default.VolumeMute
                                else if (gestureOverlayPercent < 50) Icons.Default.VolumeDown
                                else Icons.Default.VolumeUp
                            Icon(
                                imageVector = volIcon,
                                contentDescription = "Volume",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "Volume: $gestureOverlayPercent%",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(120.dp)
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.White.copy(alpha = 0.25f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth((gestureOverlayPercent / 100f).coerceIn(0f, 1f))
                                    .background(if (gestureOverlayType == "BRIGHTNESS") Color(0xFFFFB74D) else Color(0xFF10B981))
                            )
                        }
                    }
                }
            }

            // Quick Seek Animated Feedback Overlay (⏩ +10s / ⏪ -10s)
            androidx.compose.animation.AnimatedVisibility(
                visible = showSeekFeedback,
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(),
                modifier = Modifier
                    .align(if (seekFeedbackText.startsWith("-")) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(24.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.Black.copy(alpha = 0.85f),
                    border = BorderStroke(1.5.dp, OrangeTab)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (seekFeedbackText.startsWith("-")) Icons.Default.FastRewind else Icons.Default.FastForward,
                            contentDescription = null,
                            tint = OrangeTab,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = seekFeedbackText,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Loading / Error / Auto-Retry
            if (isPlayerPreparing || isAutoRetrying) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(color = OrangeTab, modifier = Modifier.size(38.dp), strokeWidth = 3.dp)
                    Text(
                        text = if (isAutoRetrying) "⚡ Network Dropped • Reconnecting (Attempt $autoRetryCount/5)..." else "Loading Stream...",
                        color = if (isAutoRetrying) Color(0xFFFFB74D) else TextWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (playbackErrorMessage != null) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text("⚠️ $playbackErrorMessage", color = LiveRed, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Button(
                        onClick = {
                            autoRetryCount = 0
                            isAutoRetrying = false
                            reloadTrigger++
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Retry Stream", color = OrangeTab, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // ==========================================
            // CENTER TRANSPORT CONTROLS (⏪ 10s | ▶ / ⏸ | ⏩ 10s)
            // ==========================================
            androidx.compose.animation.AnimatedVisibility(
                visible = showControls && !isControlsLocked,
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(if (isPortraitMode) 20.dp else 28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // ⏪ REWIND 10s
                    var isRwFocused by remember { mutableStateOf(false) }
                    val isRwActive = isRwFocused || tvFocusItem == TvPlayerFocus.REWIND
                    IconButton(
                        onClick = {
                            lastInteractionTime = System.currentTimeMillis()
                            triggerSeek(-10000L)
                        },
                        modifier = Modifier
                            .size(if (isPortraitMode) 44.dp else 52.dp)
                            .onFocusChanged { isRwFocused = it.isFocused }
                            .focusable()
                            .background(if (isRwActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.70f), CircleShape)
                            .border(if (isRwActive) 3.5.dp else 1.dp, if (isRwActive) OrangeTab else Color.White.copy(alpha = 0.3f), CircleShape)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FastRewind, contentDescription = "Rewind 10s", tint = Color.White, modifier = Modifier.size(if (isPortraitMode) 20.dp else 24.dp))
                            Text("10s", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // ▶ / ⏸ PLAY / PAUSE
                    var isPlFocused by remember { mutableStateOf(false) }
                    val isPlActive = isPlFocused || tvFocusItem == TvPlayerFocus.PLAY_PAUSE
                    IconButton(
                        onClick = {
                            lastInteractionTime = System.currentTimeMillis()
                            player?.let { p ->
                                isUserExplicitlyPaused = p.isPlaying
                                if (p.isPlaying) p.pause() else p.play()
                                isPlayingState = p.isPlaying
                            }
                        },
                        modifier = Modifier
                            .size(if (isPortraitMode) 56.dp else 66.dp)
                            .focusRequester(playPauseFocusRequester)
                            .onFocusChanged { isPlFocused = it.isFocused }
                            .focusable()
                            .background(OrangeTab, CircleShape)
                            .border(if (isPlActive) 4.dp else 0.dp, Color.White, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isPlayingState) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlayingState) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(if (isPortraitMode) 32.dp else 38.dp)
                        )
                    }

                    // ⏩ FORWARD 10s
                    var isFfFocused by remember { mutableStateOf(false) }
                    val isFfActive = isFfFocused || tvFocusItem == TvPlayerFocus.FORWARD
                    IconButton(
                        onClick = {
                            lastInteractionTime = System.currentTimeMillis()
                            triggerSeek(10000L)
                        },
                        modifier = Modifier
                            .size(if (isPortraitMode) 44.dp else 52.dp)
                            .onFocusChanged { isFfFocused = it.isFocused }
                            .focusable()
                            .background(if (isFfActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.70f), CircleShape)
                            .border(if (isFfActive) 3.5.dp else 1.dp, if (isFfActive) OrangeTab else Color.White.copy(alpha = 0.3f), CircleShape)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FastForward, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(if (isPortraitMode) 20.dp else 24.dp))
                            Text("10s", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // ==========================================
            // TOP BAR OVERLAY
            // ==========================================
            androidx.compose.animation.AnimatedVisibility(
                visible = showControls,
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)))
                        .then(if (!isPortraitMode) Modifier.statusBarsPadding() else Modifier)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (!isPortraitMode) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            var isBackFocused by remember { mutableStateOf(false) }
                            val isBackActive = isBackFocused || tvFocusItem == TvPlayerFocus.TOP_BACK
                            IconButton(
                                onClick = {
                                    releasePlayerAndExit()
                                },
                                modifier = Modifier
                                    .size(34.dp)
                                    .onFocusChanged { isBackFocused = it.isFocused }
                                    .focusable()
                                    .background(if (isBackActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.5f), CircleShape)
                                    .border(if (isBackActive) 3.5.dp else 0.dp, OrangeTab, CircleShape)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit", tint = Color.White, modifier = Modifier.size(18.dp))
                            }

                            Text(
                                text = streamSource.title.ifBlank { "HD Stream Player" },
                                color = TextWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }

                    // TOP BAR RIGHT ACTIONS: Audio / Language & Video Quality buttons (accessible right at the top!)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Language Button in Top Bar
                        var isTopLangFocused by remember { mutableStateOf(false) }
                        val isTopLangActive = isTopLangFocused || tvFocusItem == TvPlayerFocus.TOP_LANG
                        Surface(
                            onClick = {
                                lastInteractionTime = System.currentTimeMillis()
                                tvAudioIndex = availableLanguages.indexOfFirst { it.label == selectedLanguageLabel }.coerceAtLeast(0)
                                showAudioDialog = true
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isTopLangActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.65f),
                            border = BorderStroke(
                                width = if (isTopLangActive) 3.5.dp else 1.dp,
                                color = if (isTopLangActive) OrangeTab else Color(0xFF10B981).copy(alpha = 0.6f)
                            ),
                            modifier = Modifier
                                .onFocusChanged { isTopLangFocused = it.isFocused }
                                .focusable()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Translate, contentDescription = null, tint = if (isTopLangActive) OrangeTab else Color(0xFF10B981), modifier = Modifier.size(13.dp))
                                Text(text = selectedLanguageLabel, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 2. Quality Button in Top Bar
                        var isTopQualityFocused by remember { mutableStateOf(false) }
                        val isTopQualityActive = isTopQualityFocused || tvFocusItem == TvPlayerFocus.TOP_QUALITY
                        Surface(
                            onClick = {
                                lastInteractionTime = System.currentTimeMillis()
                                tvQualityIndex = availableQualities.indexOfFirst { it.label == selectedQualityLabel }.coerceAtLeast(0)
                                showQualityDialog = true
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isTopQualityActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.65f),
                            border = BorderStroke(
                                width = if (isTopQualityActive) 3.5.dp else 1.dp,
                                color = OrangeTab
                            ),
                            modifier = Modifier
                                .onFocusChanged { isTopQualityFocused = it.isFocused }
                                .focusable()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, tint = OrangeTab, modifier = Modifier.size(13.dp))
                                Text(text = selectedQualityLabel, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // ==========================================
            // BOTTOM OVERLAY: TIMELINE & ACTIONS
            // ==========================================
            androidx.compose.animation.AnimatedVisibility(
                visible = showControls && !isControlsLocked,
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.88f))))
                        .padding(horizontal = 12.dp, vertical = if (isPortraitMode) 4.dp else 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Timeline Scrubber
                    if (totalDurationMs > 0L) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val displayMs = if (isUserScrubbing) (scrubFraction * totalDurationMs).toLong() else currentPositionMs
                            Text(
                                text = formatMs(displayMs),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Slider(
                                value = if (isUserScrubbing) scrubFraction else {
                                    if (totalDurationMs > 0L) (currentPositionMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f) else 0f
                                },
                                onValueChange = { frac ->
                                    isUserScrubbing = true
                                    scrubFraction = frac
                                    lastInteractionTime = System.currentTimeMillis()
                                },
                                onValueChangeFinished = {
                                    val targetMs = (scrubFraction * totalDurationMs).toLong()
                                    player?.seekTo(targetMs)
                                    currentPositionMs = targetMs
                                    isUserScrubbing = false
                                    lastInteractionTime = System.currentTimeMillis()
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = OrangeTab,
                                    activeTrackColor = OrangeTab,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                text = formatMs(totalDurationMs),
                                color = Color(0xFFAAAAAA),
                                fontSize = 10.sp
                            )

                            if (isPortraitMode) {
                                // Mini Fullscreen button right on the timeline in portrait
                                IconButton(
                                    onClick = {
                                        isFullscreen = true
                                        val act = context as? Activity
                                        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen", tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    } else if (isPortraitMode) {
                        // Portrait Live Broadcast indicator with Fullscreen button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(modifier = Modifier.size(7.dp).background(LiveRed, CircleShape))
                                Text("LIVE", color = LiveRed, fontSize = 10.sp, fontWeight = FontWeight.Black)
                            }
                            IconButton(
                                onClick = {
                                    isFullscreen = true
                                    val act = context as? Activity
                                    act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    // Fullscreen actions (in landscape / TV)
                    if (!isPortraitMode || isTv) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Speed
                            var isSpeedFocused by remember { mutableStateOf(false) }
                            val isSpeedActive = isSpeedFocused || tvFocusItem == TvPlayerFocus.BOTTOM_SPEED
                            Surface(
                                onClick = {
                                    lastInteractionTime = System.currentTimeMillis()
                                    currentSpeedIndex = (currentSpeedIndex + 1) % speedOptions.size
                                    val spd = speedOptions[currentSpeedIndex]
                                    player?.setPlaybackSpeed(spd)
                                    Toast.makeText(context, "Speed: ${spd}x", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSpeedActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.8f),
                                border = BorderStroke(if (isSpeedActive) 3.5.dp else 1.dp, if (isSpeedActive) OrangeTab else Color.White.copy(alpha = 0.25f)),
                                modifier = Modifier
                                    .onFocusChanged { isSpeedFocused = it.isFocused }
                                    .focusable()
                            ) {
                                Text(
                                    text = "${speedOptions[currentSpeedIndex]}x",
                                    color = if (isSpeedActive) Color.White else OrangeTab,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            // Options: Audio, Aspect Ratio, Quality, Fav, Exit Fullscreen
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Language
                                var isAudioFocused by remember { mutableStateOf(false) }
                                val isAudioActive = isAudioFocused || tvFocusItem == TvPlayerFocus.BOTTOM_LANG
                                Surface(
                                    onClick = {
                                        lastInteractionTime = System.currentTimeMillis()
                                        tvAudioIndex = availableLanguages.indexOfFirst { it.label == selectedLanguageLabel }.coerceAtLeast(0)
                                        showAudioDialog = true
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isAudioActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.8f),
                                    border = BorderStroke(if (isAudioActive) 3.5.dp else 1.dp, if (isAudioActive) OrangeTab else Color(0xFF10B981).copy(alpha = 0.7f)),
                                    modifier = Modifier
                                        .onFocusChanged { isAudioFocused = it.isFocused }
                                        .focusable()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Translate, contentDescription = null, tint = if (isAudioActive) OrangeTab else Color(0xFF10B981), modifier = Modifier.size(13.dp))
                                        Text(text = selectedLanguageLabel, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Aspect Ratio
                                var isAspectFocused by remember { mutableStateOf(false) }
                                val isAspectActive = isAspectFocused || tvFocusItem == TvPlayerFocus.BOTTOM_ASPECT
                                Surface(
                                    onClick = {
                                        lastInteractionTime = System.currentTimeMillis()
                                        applyResizeMode((resizeModeIndex + 1) % resizeModes.size)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isAspectActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.8f),
                                    border = BorderStroke(if (isAspectActive) 3.5.dp else 1.dp, if (isAspectActive) OrangeTab else UpcomingCyan.copy(alpha = 0.7f)),
                                    modifier = Modifier
                                        .onFocusChanged { isAspectFocused = it.isFocused }
                                        .focusable()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.AspectRatio, contentDescription = null, tint = if (isAspectActive) OrangeTab else UpcomingCyan, modifier = Modifier.size(13.dp))
                                        Text(text = resizeModes[resizeModeIndex].second, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Quality
                                var isQualityFocused by remember { mutableStateOf(false) }
                                val isQualityActive = isQualityFocused || tvFocusItem == TvPlayerFocus.BOTTOM_QUALITY
                                Surface(
                                    onClick = {
                                        lastInteractionTime = System.currentTimeMillis()
                                        tvQualityIndex = availableQualities.indexOfFirst { it.label == selectedQualityLabel }.coerceAtLeast(0)
                                        showQualityDialog = true
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isQualityActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.8f),
                                    border = BorderStroke(if (isQualityActive) 3.5.dp else 1.dp, OrangeTab),
                                    modifier = Modifier
                                        .onFocusChanged { isQualityFocused = it.isFocused }
                                        .focusable()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Tune, contentDescription = null, tint = OrangeTab, modifier = Modifier.size(13.dp))
                                        Text(text = selectedQualityLabel, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Heart Fav
                                var isFavFocused by remember { mutableStateOf(false) }
                                val isFavActive = isFavFocused || tvFocusItem == TvPlayerFocus.BOTTOM_FAV
                                IconButton(
                                    onClick = {
                                        lastInteractionTime = System.currentTimeMillis()
                                        val favs = favoritePrefs.getStringSet("fav_urls", emptySet())?.toMutableSet() ?: mutableSetOf()
                                        val newFavState = !isFavorite
                                        if (newFavState) {
                                            favs.add(streamSource.streamUrl)
                                            Toast.makeText(context, "Added to Favorites ❤️", Toast.LENGTH_SHORT).show()
                                        } else {
                                            favs.remove(streamSource.streamUrl)
                                            Toast.makeText(context, "Removed from Favorites", Toast.LENGTH_SHORT).show()
                                        }
                                        favoritePrefs.edit().putStringSet("fav_urls", favs).apply()
                                        isFavorite = newFavState
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .onFocusChanged { isFavFocused = it.isFocused }
                                        .focusable()
                                        .background(if (isFavActive) OrangeTab.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                                        .border(if (isFavActive) 3.5.dp else 1.dp, if (isFavActive) OrangeTab else Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                ) {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Fav",
                                        tint = if (isFavorite) LiveRed else Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }

                                // Fullscreen Exit (Mobile only, TV stays fullscreen)
                                if (!isTv) {
                                    IconButton(
                                        onClick = {
                                            isFullscreen = false
                                            val act = context as? Activity
                                            val window = act?.window
                                            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            if (window != null) {
                                                window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
                                                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                                                insetsController.show(WindowInsetsCompat.Type.systemBars())
                                            }
                                        },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.FullscreenExit,
                                            contentDescription = "Exit Fullscreen",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (effectiveFullscreen) {
        // ==========================================
        // 100% PURE FULLSCREEN - IMMERSIVE CINEMA MODE
        // ==========================================
        VideoPlayerView(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds(),
            isPortraitMode = false
        )
    } else {
        Scaffold(
            containerColor = BgDark,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F0F14))
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(onClick = {
                            player?.stop()
                            player?.clearMediaItems()
                            player?.release()
                            player = null
                            ExoPlayerHelper.releaseActivePlayer()
                            onNavigateBack()
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .background(if (totalDurationMs > 0) OrangeTab else LiveRed, CircleShape)
                                )
                                Text(
                                    text = if (totalDurationMs > 0) "MOVIE / VOD" else "LIVE TV",
                                    color = if (totalDurationMs > 0) OrangeTab else LiveRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text("• ${streamSource.quality.ifBlank { "HD" }}", color = OrangeTab, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = streamSource.title.ifBlank { "Live Stream" },
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Heart / Favorite Icon in TopBar
                    IconButton(onClick = {
                        val favs = favoritePrefs.getStringSet("fav_urls", emptySet())?.toMutableSet() ?: mutableSetOf()
                        val newFavState = !isFavorite
                        if (newFavState) {
                            favs.add(streamSource.streamUrl)
                            Toast.makeText(context, "${streamSource.title} added to Favorites ❤️", Toast.LENGTH_SHORT).show()
                        } else {
                            favs.remove(streamSource.streamUrl)
                            Toast.makeText(context, "${streamSource.title} removed from Favorites", Toast.LENGTH_SHORT).show()
                        }
                        favoritePrefs.edit().putStringSet("fav_urls", favs).apply()
                        isFavorite = newFavState
                    }) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFavorite) LiveRed else TextWhite
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // 1. CLEAN VIDEO PLAYER (PORTRAIT HEIGHT 225.dp)
                VideoPlayerView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(225.dp)
                        .clipToBounds(),
                    isPortraitMode = true
                )

                // 2. CHANNEL DETAILS & ACTIONS

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .navigationBarsPadding(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, CardBorderOrange.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F14))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (totalDurationMs > 0 || streamSource.id.startsWith("cinex_") || streamSource.streamType in listOf("MP4", "MKV")) OrangeTab else LiveRed)
                                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = if (totalDurationMs > 0 || streamSource.id.startsWith("cinex_") || streamSource.streamType in listOf("MP4", "MKV")) "🎬 MOVIE / VOD" else "🔴 LIVE TV",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF1E293B))
                                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = if (streamSource.streamType.isNotBlank() && streamSource.streamType != "AUTO") streamSource.streamType else if (streamSource.streamUrl.contains(".mp4", true)) "MP4" else if (streamSource.streamUrl.contains(".mkv", true)) "MKV" else "HD",
                                                color = UpcomingCyan,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Text(
                                        text = streamSource.quality.ifBlank { "1080p Full HD" },
                                        color = OrangeTab,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = streamSource.title.ifBlank { "Live TV Stream" },
                                    color = TextWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Setting Pills (Aspect Ratio, Audio, Quality)
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Aspect Ratio Pill
                            Button(
                                onClick = {
                                    applyResizeMode((resizeModeIndex + 1) % resizeModes.size)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141419)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, UpcomingCyan.copy(alpha = 0.5f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.AspectRatio, contentDescription = null, tint = UpcomingCyan, modifier = Modifier.size(14.dp))
                                    Text(resizeModes[resizeModeIndex].second, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Audio Pill
                            Button(
                                onClick = { showAudioDialog = true },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141419)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Translate, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                                    Text(selectedLanguageLabel, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                }
                            }

                            // Quality Pill
                            Button(
                                onClick = { showQualityDialog = true },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141419)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, OrangeTab.copy(alpha = 0.5f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Tune, contentDescription = null, tint = OrangeTab, modifier = Modifier.size(14.dp))
                                    Text(selectedQualityLabel, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Reload & Favorite
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    reloadTrigger++
                                    Toast.makeText(context, "Reloading stream...", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141419)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = UpcomingCyan, modifier = Modifier.size(14.dp))
                                    Text("Reload Stream", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Button(
                                onClick = {
                                    val favs = favoritePrefs.getStringSet("fav_urls", emptySet())?.toMutableSet() ?: mutableSetOf()
                                    val newFavState = !isFavorite
                                    if (newFavState) {
                                        favs.add(streamSource.streamUrl)
                                        Toast.makeText(context, "Added to Favorites ❤️", Toast.LENGTH_SHORT).show()
                                    } else {
                                        favs.remove(streamSource.streamUrl)
                                        Toast.makeText(context, "Removed from Favorites", Toast.LENGTH_SHORT).show()
                                    }
                                    favoritePrefs.edit().putStringSet("fav_urls", favs).apply()
                                    isFavorite = newFavState
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isFavorite) LiveRed.copy(alpha = 0.2f) else Color(0xFF141419)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (isFavorite) LiveRed else Color.White.copy(alpha = 0.12f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(
                                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = null,
                                        tint = if (isFavorite) LiveRed else TextWhite,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(if (isFavorite) "Favorited" else "Favorite", color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // CATEGORY CHANNELS (Quick Channel Switcher)
                    if (categoryChannels.isNotEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .background(OrangeTab, CircleShape)
                                        )
                                        Text(
                                            text = "CATEGORY CHANNELS (${categoryChannels.size})",
                                            color = Color.White,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 0.5.sp
                                        )
                                    }
                                    Text(
                                        text = "Tap to switch channel",
                                        color = Color(0xFF888B9E),
                                        fontSize = 11.sp
                                    )
                                }

                                androidx.compose.foundation.lazy.LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    items(categoryChannels, key = { it.streamUrl + it.title }) { ch ->
                                        val isCurrent = ch.streamUrl == streamSource.streamUrl
                                        ChannelMiniCard(
                                            channel = ch,
                                            isCurrent = isCurrent,
                                            onClick = {
                                                if (!isCurrent) {
                                                    val newSource = StreamSource(
                                                        id = "ch_${ch.streamUrl.hashCode()}",
                                                        title = ch.title,
                                                        streamUrl = ch.streamUrl,
                                                        streamType = ch.streamType.ifBlank { ExoPlayerHelper.detectStreamType(ch.streamUrl) },
                                                        quality = ch.quality.ifBlank { "HD" },
                                                        headers = ch.headers,
                                                        drm = ch.drm
                                                    )
                                                    onSelectChannel(newSource)
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // AUDIO / LANGUAGE SELECTION DIALOG
    // ==========================================
    if (showAudioDialog) {
        Dialog(onDismissRequest = { showAudioDialog = false }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF13131A),
                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Translate, contentDescription = null, tint = Color(0xFF10B981))
                            Text("Select Audio Language", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        var isCloseAudioFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = { showAudioDialog = false },
                            modifier = Modifier
                                .onFocusChanged { isCloseAudioFocused = it.isFocused }
                                .focusable()
                                .border(if (isCloseAudioFocused) 2.5.dp else 0.dp, OrangeTab, CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = if (isCloseAudioFocused) OrangeTab else TextGray)
                        }
                    }

                    if (availableLanguages.isEmpty()) {
                        Text(
                            text = "Stream has standard default audio. Alternate audio tracks will show here if broadcast by provider.",
                            color = TextGray,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(availableLanguages) { index, option ->
                                val isSelected = option.isSelected || option.label == selectedLanguageLabel
                                var isOptionFocused by remember { mutableStateOf(false) }
                                val isFocused = isOptionFocused || (tvAudioIndex == index)
                                Surface(
                                    onClick = {
                                        ExoPlayerHelper.setAudioLanguage(player, option)
                                        selectedLanguageLabel = option.label
                                        showAudioDialog = false
                                        Toast.makeText(context, "Audio set to: ${option.label}", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isFocused) OrangeTab.copy(alpha = 0.35f) else if (isSelected) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF1A1A24),
                                    border = BorderStroke(if (isFocused) 3.5.dp else 1.dp, if (isFocused) OrangeTab else if (isSelected) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onFocusChanged { isOptionFocused = it.isFocused }
                                        .focusable()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = option.label,
                                            color = if (isFocused) OrangeTab else if (isSelected) Color(0xFF10B981) else TextWhite,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Normal
                                        )
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF10B981))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // VIDEO QUALITY SELECTION DIALOG
    // ==========================================
    if (showQualityDialog) {
        Dialog(onDismissRequest = { showQualityDialog = false }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF13131A),
                border = BorderStroke(1.dp, OrangeTab.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Tune, contentDescription = null, tint = OrangeTab)
                            Text("Select Video Quality", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        var isCloseQualityFocused by remember { mutableStateOf(false) }
                        IconButton(
                            onClick = { showQualityDialog = false },
                            modifier = Modifier
                                .onFocusChanged { isCloseQualityFocused = it.isFocused }
                                .focusable()
                                .border(if (isCloseQualityFocused) 2.5.dp else 0.dp, OrangeTab, CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = if (isCloseQualityFocused) OrangeTab else TextGray)
                        }
                    }

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(availableQualities) { index, option ->
                            val isSelected = option.label == selectedQualityLabel
                            var isOptionFocused by remember { mutableStateOf(false) }
                            val isFocused = isOptionFocused || (tvQualityIndex == index)
                            Surface(
                                onClick = {
                                    ExoPlayerHelper.setVideoQuality(player, option)
                                    selectedQualityLabel = option.label
                                    showQualityDialog = false
                                    Toast.makeText(context, "Quality set to ${option.label}", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isFocused) OrangeTab.copy(alpha = 0.35f) else if (isSelected) OrangeTab.copy(alpha = 0.2f) else Color(0xFF1A1A24),
                                border = BorderStroke(if (isFocused) 3.5.dp else 1.dp, OrangeTab),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isOptionFocused = it.isFocused }
                                    .focusable()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = option.label,
                                            color = if (isFocused) OrangeTab else if (isSelected) OrangeTab else TextWhite,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text(
                                            text = option.sublabel,
                                            color = TextGray,
                                            fontSize = 11.sp
                                        )
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = OrangeTab)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private val playerChannelLogoCache = android.util.LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(250)

@Composable
private fun PlayerChannelLogo(
    logoUrl: String,
    title: String,
    isCurrent: Boolean = false,
    modifier: Modifier = Modifier.size(64.dp)
) {
    val cleanUrl = remember(logoUrl) { logoUrl.replace("&amp;", "&").trim() }
    var bitmap by remember(cleanUrl) { mutableStateOf(if (cleanUrl.isNotBlank()) playerChannelLogoCache.get(cleanUrl) else null) }

    LaunchedEffect(cleanUrl) {
        if (bitmap == null && cleanUrl.isNotBlank() && (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://"))) {
            withContext(Dispatchers.IO) {
                val candidateUrls = if (cleanUrl.contains("raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/")) {
                    listOf(
                        cleanUrl,
                        cleanUrl.replace("raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/", "cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/")
                    )
                } else {
                    listOf(cleanUrl)
                }

                for (targetUrl in candidateUrls) {
                    try {
                        val url = java.net.URL(targetUrl)
                        val conn = url.openConnection() as java.net.HttpURLConnection
                        conn.connectTimeout = 7000
                        conn.readTimeout = 7000
                        conn.instanceFollowRedirects = true
                        conn.requestMethod = "GET"
                        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile)")
                        conn.setRequestProperty("Accept", "image/png,image/*,*/*")
                        if (conn.responseCode in 200..299) {
                            val bytes = conn.inputStream.use { it.readBytes() }
                            val decoded = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (decoded != null) {
                                val imgBitmap = decoded.asImageBitmap()
                                playerChannelLogoCache.put(cleanUrl, imgBitmap)
                                bitmap = imgBitmap
                                break
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Color(0xFF161824), CircleShape)
            .border(1.5.dp, if (isCurrent) OrangeTab else Color(0xFF2E3447), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            val isRectangularFlag = cleanUrl.contains("flagcdn.com") || cleanUrl.contains("/flags/") || cleanUrl.contains("country")
            androidx.compose.foundation.Image(
                bitmap = bitmap!!,
                contentDescription = title,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape),
                contentScale = if (isRectangularFlag) androidx.compose.ui.layout.ContentScale.Crop else androidx.compose.ui.layout.ContentScale.Fit
            )
        } else {
            val initials = title.split(" ")
                .filter { it.isNotBlank() }
                .take(2)
                .map { it.first().uppercaseChar() }
                .joinToString("")
                .ifBlank { "TV" }

            Text(
                text = initials,
                color = OrangeTab,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun ChannelMiniCard(
    channel: ParsedChannelItem,
    isCurrent: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .width(118.dp)
            .height(140.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) Color(0xFF1E2133) else if (isFocused) Color(0xFF24263D) else Color(0xFF11121A)
        ),
        border = BorderStroke(
            width = if (isCurrent || isFocused) 2.dp else 1.dp,
            color = if (isCurrent) OrangeTab else if (isFocused) Color(0xFF00E676) else Color(0xFF222335)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            PlayerChannelLogo(
                logoUrl = channel.logo,
                title = channel.title,
                isCurrent = isCurrent,
                modifier = Modifier.size(64.dp)
            )

            Text(
                text = channel.title,
                color = Color.White,
                fontSize = 11.5.sp,
                fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            if (isCurrent) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(OrangeTab)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "PLAYING",
                        color = Color.White,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF1C2230))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = channel.category.ifBlank { "LIVE" }.take(9).uppercase(),
                        color = Color(0xFF888B9E),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
