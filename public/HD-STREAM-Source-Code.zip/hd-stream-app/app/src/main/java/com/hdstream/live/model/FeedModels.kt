package com.hdstream.live.model

import com.google.gson.annotations.SerializedName

data class MobileFeedResponse(
    @SerializedName("status") val status: String = "",
    @SerializedName("timestamp") val timestamp: Long = 0L,
    @SerializedName("appConfig") val appConfig: AppConfig = AppConfig(),
    @SerializedName("categories") val categories: List<FeedCategory> = emptyList(),
    @SerializedName("liveEvents") val liveEvents: List<LiveStreamEvent> = emptyList(),
    @SerializedName("upcomingEvents") val upcomingEvents: List<LiveStreamEvent> = emptyList(),
    @SerializedName("recentEvents") val recentEvents: List<LiveStreamEvent> = emptyList(),
    @SerializedName("vodSection") val vodSection: List<VodShow> = emptyList()
)

data class AppConfig(
    @SerializedName("appName") val appName: String = "HD STREAM",
    @SerializedName("announcement") val announcement: String = "🔴 Welcome to HD STREAM! Watch Cricket & Entertainment in 1080p 60FPS.",
    @SerializedName("announcementEnabled") val announcementEnabled: Boolean = true,
    @SerializedName("appVersion") val appVersion: String = "2.0.0",
    @SerializedName("minVersion") val minVersion: String = "2.0.0",
    @SerializedName("apkDownloadUrl") val apkDownloadUrl: String = "",
    @SerializedName("maintenanceMode") val maintenanceMode: Boolean = false,
    @SerializedName("telegramLink") val telegramLink: String = "https://t.me/livetvofficialapp",
    @SerializedName("sponsorBannerUrl") val sponsorBannerUrl: String = "",
    @SerializedName("sponsorRedirectUrl") val sponsorRedirectUrl: String = "",
    @SerializedName("adsterraEnabled") val adsterraEnabled: Boolean = false,
    @SerializedName("adsterraZoneId") val adsterraZoneId: String = "",
    @SerializedName("adsterraPublisherId") val adsterraPublisherId: String = "",
    @SerializedName("channelChangeAdFrequency") val channelChangeAdFrequency: Int = 999
)

data class FeedCategory(
    @SerializedName("id") val id: String = "",
    @SerializedName("name") val name: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("slug") val slug: String = "",
    @SerializedName("icon") val icon: String = "",
    @SerializedName("imageUrl") val imageUrl: String = "",
    @SerializedName("m3uLink") val m3uLink: String = "",
    @SerializedName("portal_url") val portalUrl: String = "",
    @SerializedName("mac") val mac: String = ""
) {
    val displayName: String get() = if (name.isNotBlank()) name else if (title.isNotBlank()) title else "Category"
}

data class LiveStreamEvent(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("category") val category: String = "Live Cricket",
    @SerializedName("status") val status: String = "LIVE", // LIVE, UPCOMING, FINISHED
    @SerializedName("format") val format: String = "T20",
    @SerializedName("startTime") val startTime: String = "",
    @SerializedName("bannerUrl") val bannerUrl: String = "",
    @SerializedName("description") val description: String = "",
    @SerializedName("isPinned") val isPinned: Boolean = false,
    @SerializedName("team1") val team1: TeamInfo = TeamInfo(),
    @SerializedName("team2") val team2: TeamInfo = TeamInfo(),
    @SerializedName("totalStreams") val totalStreams: Int = 0,
    @SerializedName("streams") val streams: List<StreamSource> = emptyList()
)

data class TeamInfo(
    @SerializedName("name") val name: String = "",
    @SerializedName("shortName") val shortName: String = "",
    @SerializedName("flag") val flag: String = "",
    @SerializedName("logo") val logo: String = "",
    @SerializedName("score") val score: String = ""
)

data class StreamSource(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("streamType") val streamType: String = "M3U8", // M3U8, MPD, DIRECT, EMBED, JSON
    @SerializedName("streamUrl") val streamUrl: String = "",
    @SerializedName("jsonChannelUrl") val jsonChannelUrl: String = "",
    @SerializedName("jsonTokenUrl") val jsonTokenUrl: String = "",
    @SerializedName("jsonToken") val jsonToken: String = "",
    @SerializedName("quality") val quality: String = "1080p HD",
    @SerializedName("headers") val headers: Map<String, String> = emptyMap(),
    @SerializedName("drm") val drm: DrmConfig = DrmConfig()
)

data class DrmConfig(
    @SerializedName("enabled") val enabled: Boolean = false,
    @SerializedName("scheme") val scheme: String = "clearkey",
    @SerializedName("keyId") val keyId: String = "",
    @SerializedName("key") val key: String = "",
    @SerializedName("licenseUrl") val licenseUrl: String? = null
)

data class VodShow(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("category") val category: String = "",
    @SerializedName("posterUrl") val posterUrl: String = "",
    @SerializedName("bannerUrl") val bannerUrl: String = "",
    @SerializedName("description") val description: String = "",
    @SerializedName("rating") val rating: String = "8.5",
    @SerializedName("releaseYear") val releaseYear: String = "2026",
    @SerializedName("totalEpisodes") val totalEpisodes: Int = 0,
    @SerializedName("episodes") val episodes: List<VodEpisode> = emptyList()
)

data class VodEpisode(
    @SerializedName("id") val id: String = "",
    @SerializedName("episodeNumber") val episodeNumber: Int = 1,
    @SerializedName("title") val title: String = "",
    @SerializedName("duration") val duration: String = "",
    @SerializedName("thumbnail") val thumbnail: String = "",
    @SerializedName("streamType") val streamType: String = "M3U8",
    @SerializedName("streamUrl") val streamUrl: String = "",
    @SerializedName("headers") val headers: Map<String, String> = emptyMap(),
    @SerializedName("drm") val drm: DrmConfig = DrmConfig()
)

data class FeaturedChannelItem(
    val name: String,
    val category: String,
    val emoji: String,
    val streamUrl: String
)

data class SportsCategoryItem(
    val name: String,
    val emoji: String,
    val count: Int,
    val isAll: Boolean = false,
    val label: String = "",
    val isLiveNow: Boolean = true
)

data class StatusPillItem(
    val key: String,
    val label: String
)

data class CinexMoviesResponse(
    @SerializedName("matches") val matches: List<CinexMovieItem> = emptyList()
)

data class CinexMovieItem(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("poster") val poster: String = "",
    @SerializedName("categories") val categories: String = "",
    @SerializedName("heading") val heading: String = "",
    @SerializedName("metadata") val metadata: CinexMovieMetadata = CinexMovieMetadata(),
    @SerializedName("trailer") val trailer: CinexMovieTrailer = CinexMovieTrailer(),
    @SerializedName("channels") val channels: List<CinexMovieChannel> = emptyList()
)

data class CinexMovieMetadata(
    @SerializedName("imdbRating") val imdbRating: String = "",
    @SerializedName("genre") val genre: List<String> = emptyList(),
    @SerializedName("stars") val stars: List<String> = emptyList(),
    @SerializedName("director") val director: String = "",
    @SerializedName("language") val language: String = "",
    @SerializedName("quality") val quality: String = "HD"
)

data class CinexMovieTrailer(
    @SerializedName("embedUrl") val embedUrl: String = "",
    @SerializedName("title") val title: String = ""
)

data class CinexMovieChannel(
    @SerializedName("id") val id: String = "",
    @SerializedName("name") val name: String = "Watch Stream",
    @SerializedName("streamType") val streamType: String = "hls",
    @SerializedName("streamUrl") val streamUrl: String = ""
)

// Google Drive & GitHub Dynamic Models
data class GDriveLiveFeedResponse(
    @SerializedName("announcement") val announcement: String? = null,
    @SerializedName("announcement_enabled") val announcementEnabledSnake: Boolean? = null,
    @SerializedName("announcementEnabled") val announcementEnabledCamel: Boolean? = null,
    @SerializedName("live_matches") val liveMatchesSnake: List<GDriveMatchItem>? = null,
    @SerializedName("liveMatches") val liveMatchesCamel: List<GDriveMatchItem>? = null,
    @SerializedName("upcoming_matches") val upcomingMatchesSnake: List<GDriveMatchItem>? = null,
    @SerializedName("upcomingMatches") val upcomingMatchesCamel: List<GDriveMatchItem>? = null,
    @SerializedName("finished_matches") val finishedMatchesSnake: List<GDriveMatchItem>? = null,
    @SerializedName("finishedMatches") val finishedMatchesCamel: List<GDriveMatchItem>? = null
) {
    val liveMatches: List<GDriveMatchItem>? get() = liveMatchesSnake ?: liveMatchesCamel
    val upcomingMatches: List<GDriveMatchItem>? get() = upcomingMatchesSnake ?: upcomingMatchesCamel
    val finishedMatches: List<GDriveMatchItem>? get() = finishedMatchesSnake ?: finishedMatchesCamel
    val announcementEnabled: Boolean? get() = announcementEnabledSnake ?: announcementEnabledCamel
}

data class GDriveTeamInfo(
    @SerializedName("name") val name: String? = null,
    @SerializedName("logo") val logo: String? = null,
    @SerializedName("flag") val flag: String? = null,
    @SerializedName("score") val score: String? = null
)

data class GDriveMatchItem(
    @SerializedName("match_name") val matchName: String? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("time") val time: String? = null,
    @SerializedName("date") val date: String? = null,
    @SerializedName("result") val result: String? = null,
    @SerializedName("category") val category: String? = null,
    @SerializedName("team1_name") val team1Name: String? = null,
    @SerializedName("team1_logo") val team1Logo: String? = null,
    @SerializedName("team1") val team1Obj: GDriveTeamInfo? = null,
    @SerializedName("team_a") val teamAObj: GDriveTeamInfo? = null,
    @SerializedName("team2_name") val team2Name: String? = null,
    @SerializedName("team2_logo") val team2Logo: String? = null,
    @SerializedName("team2") val team2Obj: GDriveTeamInfo? = null,
    @SerializedName("team_b") val teamBObj: GDriveTeamInfo? = null,
    @SerializedName("banner") val banner: String? = null,
    @SerializedName("banner_url") val bannerUrlSnake: String? = null,
    @SerializedName("bannerUrl") val bannerUrlCamel: String? = null,
    @SerializedName("image") val image: String? = null,
    @SerializedName("streams") val streams: List<GDriveStreamItem>? = null
)

data class GDriveStreamItem(
    @SerializedName("title") val title: String? = null,
    @SerializedName("url") val url: String? = null,
    @SerializedName("type") val type: String? = null
)
