package com.hdstream.live.player

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hdstream.live.model.DrmConfig
import com.hdstream.live.model.LiveStreamEvent
import com.hdstream.live.model.StreamSource
import com.hdstream.live.model.TeamInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class ParsedChannelItem(
    val title: String,
    val streamUrl: String,
    val streamType: String = "M3U8",
    val logo: String = "",
    val category: String = "Live Sports",
    val quality: String = "1080p HD",
    val headers: Map<String, String> = emptyMap(),
    val drm: DrmConfig = DrmConfig()
)

object M3uParser {

    // High-performance memory cache for parsed playlists (Eliminates repeated downloads for Jio TV & Google Drive)
    private val playlistCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, String>>()
    private const val CACHE_TTL_MS = 300_000L // 5 minutes fresh cache

    private fun extractGoogleDriveFileId(url: String): String? {
        val idRegex1 = Regex("[?&]id=([a-zA-Z0-9_-]+)")
        val match1 = idRegex1.find(url)
        if (match1 != null) return match1.groupValues[1]

        val idRegex2 = Regex("/file/d/([a-zA-Z0-9_-]+)")
        val match2 = idRegex2.find(url)
        if (match2 != null) return match2.groupValues[1]

        return null
    }

    private fun sanitizeUrl(urlString: String): String {
        val trimmed = urlString.trim()
        if (trimmed.contains("drive.google.com", ignoreCase = true)) {
            val fileId = extractGoogleDriveFileId(trimmed)
            if (!fileId.isNullOrBlank()) {
                return "https://drive.usercontent.google.com/download?id=$fileId&export=download"
            }
        }
        return trimmed
    }

    private fun fetchWithRedirects(initialUrl: String, timeoutMs: Int = 4500): String? {
        var curUrl = initialUrl
        var redirects = 0
        var cookies = ""
        while (redirects < 6) {
            try {
                val url = URL(curUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = timeoutMs
                conn.readTimeout = timeoutMs
                conn.instanceFollowRedirects = false // Handle manually to support cross-domain & 303 redirects
                conn.requestMethod = "GET"
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
                conn.setRequestProperty("Accept", "application/json, text/plain, */*")
                if (cookies.isNotBlank()) {
                    conn.setRequestProperty("Cookie", cookies)
                }

                val code = conn.responseCode
                val setCookie = conn.getHeaderField("Set-Cookie")
                if (!setCookie.isNullOrBlank()) {
                    cookies = setCookie.split(";").firstOrNull() ?: ""
                }

                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        curUrl = if (loc.startsWith("http://") || loc.startsWith("https://")) {
                            loc
                        } else {
                            URL(url, loc).toString()
                        }
                        redirects++
                        continue
                    }
                }

                if (code in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val text = reader.readText()
                    reader.close()
                    val trimmed = text.trim()
                    if (trimmed.isNotBlank() && !trimmed.contains("Checking your browser", ignoreCase = true) && !trimmed.contains("jschallenge", ignoreCase = true)) {
                        return text
                    }
                }
                return null
            } catch (_: Exception) {
                return null
            }
        }
        return null
    }

    suspend fun fetchFromUrl(urlString: String): String = withContext(Dispatchers.IO) {
        val cleanUrl = sanitizeUrl(urlString)

        // 1. Check in-memory cache first for instant 0ms load
        val cached = playlistCache[cleanUrl]
        val now = System.currentTimeMillis()
        if (cached != null && (now - cached.first) < CACHE_TTL_MS) {
            return@withContext cached.second
        }

        val targets = mutableListOf<String>()

        // 2. Primary target
        targets.add(cleanUrl)

        // 3. High-speed unblocked TV & Cricket mirrors (if targeting /tv/ or cinexcricket TV)
        if (cleanUrl.contains("/tv/", ignoreCase = true) || cleanUrl.contains("api/tv", ignoreCase = true) || cleanUrl.contains("cinexcricket", ignoreCase = true)) {
            targets.add("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/tv/data.json")
            targets.add("https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/public/tv/data.json")
            targets.add("https://stream-admin-backend.vercel.app/api/tv/data.json")
        }

        // 3b. MIX TV unblocked mirrors
        if (cleanUrl.contains("mix", ignoreCase = true) || cleanUrl.contains("streamflexsmm", ignoreCase = true)) {
            targets.add("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/tv/mix.json")
            targets.add("https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/public/tv/mix.json")
            targets.add("https://stream-admin-backend.vercel.app/api/tv/mix.json")
        }

        // 4. Movies mirrors ONLY if URL explicitly asks for movies
        if (cleanUrl.contains("/movies/", ignoreCase = true) || cleanUrl.contains("cinex_movies", ignoreCase = true)) {
            targets.add("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/movies/data.json")
            targets.add("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/cinex_movies.json")
            targets.add("https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/public/movies/data.json")
            targets.add("https://stream-admin-backend.vercel.app/api/movies/data.json")
        }

        // 5. High-Performance Web Proxies
        if (!cleanUrl.contains("drive.google.com") && !cleanUrl.contains("usercontent.google.com")) {
            val encodedUrl = try { java.net.URLEncoder.encode(cleanUrl, "UTF-8") } catch (_: Exception) { cleanUrl }
            val proxyList = listOf(
                "https://api.allorigins.win/raw?url=%s",
                "https://api.codetabs.com/v1/proxy?quest=%s",
                "https://corsproxy.io/?url=%s",
                "https://proxy.cors.sh/%s",
                "https://bypass-cors.vercel.app/api?url=%s",
                "https://jsonp.afeld.me/?url=%s",
                "https://yacdn.org/proxy/%s",
                "https://worker-cors.workers.dev/?url=%s"
            )
            for (proxy in proxyList) {
                val formatted = if (proxy.contains("?url=") || proxy.contains("?quest=")) {
                    String.format(proxy, encodedUrl)
                } else {
                    String.format(proxy, cleanUrl)
                }
                targets.add(formatted)
            }
        }

        for (target in targets) {
            val content = fetchWithRedirects(target, timeoutMs = 4500)
            if (!content.isNullOrBlank()) {
                playlistCache[cleanUrl] = Pair(System.currentTimeMillis(), content)
                return@withContext content
            }
        }

        throw java.io.IOException("Failed to load playlist from $urlString")
    }

    fun parseM3u(content: String, defaultCategory: String = "Live Sports"): List<ParsedChannelItem> {
        val lines = content.lines()
        val items = mutableListOf<ParsedChannelItem>()

        var currentTitle = ""
        var currentLogo = ""
        var currentCategory = defaultCategory
        val currentKodiProps = mutableMapOf<String, String>()
        val currentHeaders = mutableMapOf<String, String>()

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            when {
                line.startsWith("#EXTINF:", ignoreCase = true) -> {
                    // Extract title after comma
                    val commaIndex = line.lastIndexOf(',')
                    currentTitle = if (commaIndex != -1) line.substring(commaIndex + 1).trim() else "Live Stream"

                    // Extract tvg-logo
                    val logoMatch = Regex("""tvg-logo="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (logoMatch != null) currentLogo = logoMatch.groupValues[1]

                    // Extract group-title
                    val groupMatch = Regex("""group-title="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (groupMatch != null) currentCategory = groupMatch.groupValues[1]

                    // Extract headers in EXTINF
                    val uaMatch = Regex("""http-user-agent="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (uaMatch != null) currentHeaders["User-Agent"] = uaMatch.groupValues[1]

                    val refMatch = Regex("""http-referrer="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (refMatch != null) currentHeaders["Referer"] = refMatch.groupValues[1]

                    val originMatch = Regex("""http-origin="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (originMatch != null) currentHeaders["Origin"] = originMatch.groupValues[1]

                    val cookieMatch = Regex("""http-cookie="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (cookieMatch != null) currentHeaders["Cookie"] = cookieMatch.groupValues[1]

                    val authMatch = Regex("""(?:http-auth|token)="([^"]+)"""", RegexOption.IGNORE_CASE).find(line)
                    if (authMatch != null) {
                        val token = authMatch.groupValues[1]
                        currentHeaders["Authorization"] = if (token.startsWith("Bearer ", true) || token.startsWith("Basic ", true)) token else "Bearer $token"
                    }
                }
                line.startsWith("#EXTHTTP:", ignoreCase = true) -> {
                    val jsonStr = line.substring(9).trim()
                    try {
                        val obj = org.json.JSONObject(jsonStr)
                        val keys = obj.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            val v = obj.optString(k, "")
                            currentHeaders[k] = v
                            if (k.equals("cookie", ignoreCase = true)) currentHeaders["Cookie"] = v
                            if (k.equals("user-agent", ignoreCase = true)) currentHeaders["User-Agent"] = v
                            if (k.equals("referer", ignoreCase = true) || k.equals("referrer", ignoreCase = true)) currentHeaders["Referer"] = v
                            if (k.equals("origin", ignoreCase = true)) currentHeaders["Origin"] = v
                        }
                    } catch (_: Exception) {}
                }
                line.startsWith("#KODIPROP:", ignoreCase = true) -> {
                    val prop = line.substring(10).trim()
                    val eqIdx = prop.indexOf('=')
                    if (eqIdx != -1) {
                        val k = prop.substring(0, eqIdx).trim().lowercase()
                        val v = prop.substring(eqIdx + 1).trim()
                        currentKodiProps[k] = v

                        // Parse stream_headers & license_headers into currentHeaders
                        if (k.contains("stream_headers") || k.contains("license_headers")) {
                            val pairs = v.split('&')
                            for (pair in pairs) {
                                val sEq = pair.indexOf('=')
                                if (sEq > 0) {
                                    val sk = pair.substring(0, sEq).trim()
                                    val sv = pair.substring(sEq + 1).trim()
                                    currentHeaders[sk] = sv
                                }
                            }
                        }
                    }
                }
                line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                    val opt = line.substring(11).trim()
                    val eqIdx = opt.indexOf('=')
                    if (eqIdx != -1) {
                        val k = opt.substring(0, eqIdx).trim().lowercase()
                        val v = opt.substring(eqIdx + 1).trim()
                        if (k.contains("user-agent")) currentHeaders["User-Agent"] = v
                        if (k.contains("referrer") || k.contains("referer")) currentHeaders["Referer"] = v
                        if (k.contains("origin")) currentHeaders["Origin"] = v
                        if (k.contains("cookie")) currentHeaders["Cookie"] = v
                        if (k.contains("auth") || k.contains("token")) {
                            currentHeaders["Authorization"] = if (v.startsWith("Bearer ", true) || v.startsWith("Basic ", true)) v else "Bearer $v"
                        }
                    }
                }
                !line.startsWith("#") && (line.startsWith("http://") || line.startsWith("https://")) -> {
                    val streamUrl = line

                    // DRM Detection from Kodi properties
                    var drm = DrmConfig()
                    val licType = currentKodiProps["inputstream.adaptive.license_type"]?.lowercase() ?: ""
                    val licKey = currentKodiProps["inputstream.adaptive.license_key"] ?: ""

                    if (licType.contains("widevine") || licType.contains("com.widevine.alpha")) {
                        val cleanLic = licKey.split("|").firstOrNull() ?: licKey
                        drm = DrmConfig(
                            enabled = true,
                            scheme = "widevine",
                            key = cleanLic,
                            licenseUrl = cleanLic
                        )
                    } else if (licType.contains("clearkey") || licType.contains("org.w3.clearkey") || licKey.isNotBlank()) {
                        val isUrl = licKey.startsWith("http://", ignoreCase = true) || licKey.startsWith("https://", ignoreCase = true)
                        drm = DrmConfig(
                            enabled = true,
                            scheme = "clearkey",
                            keyId = if (isUrl) "" else licKey,
                            key = licKey,
                            licenseUrl = if (isUrl) licKey else ""
                        )
                    }

                    // Parse inline piped parameters (|license_type=clearkey&license_key=...&user-agent=...)
                    val parsedPipe = ExoPlayerHelper.parsePipedUrl(streamUrl, currentHeaders, drm)
                    val finalCleanUrl = parsedPipe.cleanUrl
                    val finalHeaders = parsedPipe.headers
                    val finalDrm = parsedPipe.drm

                    val streamType = when {
                        currentKodiProps["inputstream.adaptive.manifest_type"]?.equals("dash", ignoreCase = true) == true -> "MPD"
                        finalCleanUrl.contains(".mpd", ignoreCase = true) || streamUrl.contains(".mpd", ignoreCase = true) -> "MPD"
                        finalCleanUrl.contains(".ts", ignoreCase = true) -> "TS"
                        else -> "M3U8"
                    }

                    items.add(
                        ParsedChannelItem(
                            title = currentTitle.ifBlank { "Channel ${items.size + 1}" },
                            streamUrl = streamUrl,
                            streamType = streamType,
                            logo = currentLogo,
                            category = currentCategory,
                            quality = "1080p HD",
                            headers = finalHeaders,
                            drm = finalDrm
                        )
                    )

                    // Reset for next stream
                    currentTitle = ""
                    currentLogo = ""
                    currentCategory = defaultCategory
                    currentKodiProps.clear()
                    currentHeaders.clear()
                }
            }
        }
        return items
    }

    fun parseJson(content: String, defaultCategory: String = "Live Sports"): List<ParsedChannelItem> {
        val items = mutableListOf<ParsedChannelItem>()
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return items

        try {
            val allItemObjects = mutableListOf<Pair<String, org.json.JSONObject>>()

            if (trimmed.startsWith("[")) {
                val rootArray = org.json.JSONArray(trimmed)
                for (i in 0 until rootArray.length()) {
                    val obj = rootArray.optJSONObject(i)
                    if (obj != null) {
                        allItemObjects.add(Pair(defaultCategory, obj))
                    }
                }
            } else if (trimmed.startsWith("{")) {
                val root = org.json.JSONObject(trimmed)
                val keys = root.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val arr = root.optJSONArray(k)
                    if (arr != null) {
                        val catForThisArray = when (k.lowercase()) {
                            "matches", "data", "items", "channels", "streams", "list", "results" -> defaultCategory
                            "livematches", "live_matches", "live" -> "Live"
                            "upcomingmatches", "upcoming_matches", "upcoming" -> "Upcoming"
                            "finishedmatches", "finished_matches" -> "Finished"
                            else -> k
                        }
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i)
                            if (obj != null) {
                                allItemObjects.add(Pair(catForThisArray, obj))
                            }
                        }
                    } else {
                        val nestedObj = root.optJSONObject(k)
                        if (nestedObj != null && (nestedObj.has("streamUrl") || nestedObj.has("url") || nestedObj.has("channels") || nestedObj.has("streams"))) {
                            allItemObjects.add(Pair(k, nestedObj))
                        }
                    }
                }
            }

            for ((inheritedCat, itemObj) in allItemObjects) {
                val parentTitle = itemObj.optString("heading", 
                    itemObj.optString("title", 
                    itemObj.optString("match_name", 
                    itemObj.optString("name", 
                    itemObj.optString("channelName", "Live Stream")))))

                val parentPoster = itemObj.optString("poster", 
                    itemObj.optString("bannerUrl", 
                    itemObj.optString("logo", 
                    itemObj.optString("image", 
                    itemObj.optString("imageUrl", 
                    itemObj.optString("team1_logo", ""))))))

                val parentCat = itemObj.optString("categories", 
                    itemObj.optString("category", 
                    itemObj.optString("group", inheritedCat)))

                // Extract all nested streams / servers / channels / links
                val nestedArr = itemObj.optJSONArray("channels")
                    ?: itemObj.optJSONArray("streams")
                    ?: itemObj.optJSONArray("servers")
                    ?: itemObj.optJSONArray("links")
                    ?: itemObj.optJSONArray("sources")
                    ?: itemObj.optJSONArray("episodes")

                if (nestedArr != null && nestedArr.length() > 0) {
                    for (j in 0 until nestedArr.length()) {
                        val subObj = nestedArr.optJSONObject(j) ?: continue
                        val subName = subObj.optString("name", 
                            subObj.optString("title", 
                            subObj.optString("server", 
                            subObj.optString("quality", "Server ${j + 1}"))))

                        val rawUrl = subObj.optString("streamUrl", 
                            subObj.optString("url", 
                            subObj.optString("link", 
                            subObj.optString("src", 
                            subObj.optString("file", "")))))

                        if (rawUrl.isBlank()) continue

                        val subLogo = subObj.optString("logo", 
                            subObj.optString("poster", 
                            subObj.optString("icon", parentPoster)))

                        val subCat = subObj.optString("category", 
                            subObj.optString("group", parentCat))

                        // Extract DRM
                        val kid = subObj.optString("keyId", subObj.optString("kid", itemObj.optString("keyId", itemObj.optString("kid", ""))))
                        val key = subObj.optString("key", itemObj.optString("key", ""))
                        val licUrl = subObj.optString("licenseUrl", itemObj.optString("licenseUrl", ""))
                        val scheme = subObj.optString("scheme", if (licUrl.isNotBlank()) "widevine" else "clearkey")
                        val drm = if (kid.isNotBlank() || key.isNotBlank() || licUrl.isNotBlank()) {
                            DrmConfig(enabled = true, scheme = scheme, keyId = kid, key = key, licenseUrl = licUrl.ifBlank { null })
                        } else {
                            DrmConfig(enabled = false)
                        }

                        // Extract Headers
                        val headersMap = mutableMapOf<String, String>()
                        val headersObj = subObj.optJSONObject("headers") ?: itemObj.optJSONObject("headers")
                        if (headersObj != null) {
                            val it = headersObj.keys()
                            while (it.hasNext()) {
                                val hk = it.next()
                                headersMap[hk] = headersObj.optString(hk)
                            }
                        }

                        val parsedPipe = ExoPlayerHelper.parsePipedUrl(rawUrl, headersMap, drm)

                        val titleLabel = if (nestedArr.length() > 1 && !subName.equals(parentTitle, ignoreCase = true)) {
                            "$parentTitle • $subName"
                        } else {
                            parentTitle
                        }

                        items.add(
                            ParsedChannelItem(
                                title = titleLabel,
                                streamUrl = parsedPipe.cleanUrl,
                                streamType = ExoPlayerHelper.detectStreamType(parsedPipe.cleanUrl),
                                logo = subLogo,
                                category = subCat,
                                quality = subObj.optString("quality", "1080p HD"),
                                headers = parsedPipe.headers,
                                drm = parsedPipe.drm
                            )
                        )
                    }
                } else {
                    // Flat item
                    val rawUrl = itemObj.optString("streamUrl", 
                        itemObj.optString("url", 
                        itemObj.optString("stream", 
                        itemObj.optString("link", 
                        itemObj.optString("src", 
                        itemObj.optString("file", ""))))))

                    if (rawUrl.isNotBlank()) {
                        val kid = itemObj.optString("keyId", itemObj.optString("kid", ""))
                        val key = itemObj.optString("key", "")
                        val licUrl = itemObj.optString("licenseUrl", "")
                        val scheme = itemObj.optString("scheme", if (licUrl.isNotBlank()) "widevine" else "clearkey")
                        val drm = if (kid.isNotBlank() || key.isNotBlank() || licUrl.isNotBlank()) {
                            DrmConfig(enabled = true, scheme = scheme, keyId = kid, key = key, licenseUrl = licUrl.ifBlank { null })
                        } else {
                            DrmConfig(enabled = false)
                        }

                        val headersMap = mutableMapOf<String, String>()
                        val headersObj = itemObj.optJSONObject("headers")
                        if (headersObj != null) {
                            val it = headersObj.keys()
                            while (it.hasNext()) {
                                val hk = it.next()
                                headersMap[hk] = headersObj.optString(hk)
                            }
                        }

                        val parsedPipe = ExoPlayerHelper.parsePipedUrl(rawUrl, headersMap, drm)

                        items.add(
                            ParsedChannelItem(
                                title = parentTitle,
                                streamUrl = parsedPipe.cleanUrl,
                                streamType = ExoPlayerHelper.detectStreamType(parsedPipe.cleanUrl),
                                logo = parentPoster,
                                category = parentCat,
                                quality = itemObj.optString("quality", "1080p HD"),
                                headers = parsedPipe.headers,
                                drm = parsedPipe.drm
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        return items
    }

    fun toLiveStreamEvent(item: ParsedChannelItem): LiveStreamEvent {
        val eventId = "custom_event_" + System.currentTimeMillis() + "_" + (100..999).random()
        return LiveStreamEvent(
            id = eventId,
            title = item.title,
            category = item.category,
            status = "LIVE",
            format = "T20",
            bannerUrl = item.logo,
            description = "Custom stream • ${item.category}",
            isPinned = true,
            team1 = TeamInfo(name = item.title.split(" vs ").firstOrNull() ?: item.title, flag = "📺", score = ""),
            team2 = TeamInfo(name = item.title.split(" vs ").getOrElse(1) { "HD Stream" }, flag = "🔴", score = ""),
            totalStreams = 1,
            streams = listOf(
                StreamSource(
                    id = "str_" + System.currentTimeMillis(),
                    title = item.title,
                    streamType = item.streamType,
                    streamUrl = item.streamUrl,
                    quality = item.quality,
                    headers = item.headers,
                    drm = item.drm
                )
            )
        )
    }
}
