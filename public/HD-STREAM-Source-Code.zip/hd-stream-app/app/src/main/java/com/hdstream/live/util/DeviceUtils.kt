package com.hdstream.live.util

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build

object DeviceUtils {
    @Volatile
    private var cachedIsTv: Boolean? = null

    fun isTv(context: Context): Boolean {
        cachedIsTv?.let { return it }

        val pm = context.packageManager

        // 1. Official Android TV UiMode (Google TV, Sony Bravia, Nvidia Shield, Mi Box TV mode)
        val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        val isUiTv = uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

        // 2. Leanback features (Standard Android TV / Google TV / Fire TV)
        val hasLeanback = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
                pm.hasSystemFeature("android.software.leanback") ||
                pm.hasSystemFeature("android.software.leanback_only")

        // 3. Amazon Fire TV identification
        val hasFireTv = pm.hasSystemFeature("amazon.hardware.fire_tv")
        val isAmazonAft = Build.MODEL.contains("AFT", ignoreCase = true)
        val isAmazonMfr = Build.MANUFACTURER.contains("Amazon", ignoreCase = true)

        // 4. Absence of Touchscreen (TVs and set-top boxes don't have built-in touchscreens)
        val hasNoTouch = !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)

        // 5. Hardware & Device String Keywords for TV boxes (Mi Box, Chromecast, Shield, Allwinner, Amlogic, Rockchip, etc.)
        val modelKeywords = listOf(
            "tv", "box", "firetv", "mibox", "shield", "chromecast", "bravia",
            "androidtv", "smarttv", "t95", "x96", "h96", "ott", "google tv",
            "googletv", "amlogic", "rockchip", "allwinner", "realtek", "mstar"
        )
        val combinedDeviceInfo = "${Build.MODEL} ${Build.PRODUCT} ${Build.DEVICE} ${Build.MANUFACTURER} ${Build.BRAND} ${Build.HARDWARE}".lowercase()
        val hasTvKeyword = modelKeywords.any { combinedDeviceInfo.contains(it) }

        // 6. Non-telephony Landscape Default (TV boxes connected to HDMI monitor/TV)
        val hasNoTelephony = !pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)
        val dm = context.resources.displayMetrics
        val isWideLandscape = dm.widthPixels > dm.heightPixels && dm.widthPixels >= 1280

        val result = isUiTv || hasLeanback || hasFireTv || isAmazonAft || isAmazonMfr || hasNoTouch || hasTvKeyword || (hasNoTelephony && isWideLandscape)
        cachedIsTv = result
        return result
    }
}
