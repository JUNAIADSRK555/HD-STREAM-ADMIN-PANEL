package com.hdstream.live.player

import android.content.Context
import android.net.Uri
import android.os.Looper
import android.util.Base64
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.DrmInitData
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLivePlaybackSpeedControl
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.PlayerId
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.DefaultDrmSessionManagerProvider
import androidx.media3.exoplayer.drm.DrmSession
import androidx.media3.exoplayer.drm.DrmSessionEventListener
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import com.hdstream.live.model.DrmConfig
import com.hdstream.live.model.StreamSource
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CompletableFuture
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.*

@OptIn(UnstableApi::class)
object ExoPlayerHelper {
    @Volatile
    var dynamicJioAkamaiToken: String = ""

    @Volatile
    var dynamicHotstarToken: String = ""

    private var appContextRef: java.lang.ref.WeakReference<Context>? = null

    fun initAppContext(context: Context) {
        appContextRef = java.lang.ref.WeakReference(context.applicationContext)
    }


    /**
     * Proactively refreshes Jio Akamai token from upstream if currently expired.
     */
    fun refreshJioAkamaiTokenIfNeeded() {
        // Dynamic upstream token refresh without hardcoded URLs
    }

    /**
     * Checks if an Akamai or Hotstar token has expired based on exp= or Expires= timestamp.
     */
    fun isTokenExpired(tokenStr: String?): Boolean {
        if (tokenStr.isNullOrBlank()) return true
        val expMatch = Regex("""(?:exp|Expires)=(\d+)""", RegexOption.IGNORE_CASE).find(tokenStr)
        val expSec = expMatch?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        if (expSec == 0L) return false
        val nowSec = System.currentTimeMillis() / 1000L
        return expSec <= (nowSec + 10L)
    }

    /**
     * Dynamically updates the global token cache from any discovered line, cookie, or stream URL.
     */
    fun updateDynamicTokens(rawString: String) {
        if (rawString.isBlank()) return
        val hdneaMatch = Regex("""__hdnea__=([^&"\s';]+)""").find(rawString)
        if (hdneaMatch != null) {
            val token = hdneaMatch.groupValues[1]
            if (!isTokenExpired(token)) {
                if (token.contains("acl=/*") || isTokenExpired(dynamicJioAkamaiToken)) {
                    dynamicJioAkamaiToken = token
                }
            }
        }
        val hdntlMatch = Regex("""hdntl=([^&"\s';]+)""").find(rawString)
        if (hdntlMatch != null) {
            val token = "hdntl=" + hdntlMatch.groupValues[1]
            if (!isTokenExpired(token)) {
                dynamicHotstarToken = token
            }
        }
    }

    init {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })
            val sslContext = SSLContext.getInstance("TLS").apply {
                init(null, trustAllCerts, SecureRandom())
            }
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.socketFactory)
            HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
        } catch (_: Exception) {}
    }
    fun detectStreamType(url: String, defaultHint: String = ""): String {
        val clean = url.substringBefore('?').lowercase()
        val hint = defaultHint.trim().lowercase()
        return when {
            clean.endsWith(".mpd") || url.contains(".mpd", ignoreCase = true) || hint.contains("dash") || hint.contains("mpd") -> "MPD"
            clean.endsWith(".m3u8") || url.contains(".m3u8", ignoreCase = true) || hint.contains("hls") || hint.contains("m3u") -> "M3U8"
            clean.endsWith(".mp4") || url.contains(".mp4", ignoreCase = true) || hint.contains("mp4") -> "MP4"
            clean.endsWith(".mkv") || url.contains(".mkv", ignoreCase = true) || hint.contains("mkv") -> "MKV"
            clean.endsWith(".webm") || url.contains(".webm", ignoreCase = true) || hint.contains("webm") -> "WEBM"
            clean.endsWith(".ts") || url.contains(".ts", ignoreCase = true) || hint.contains("ts") -> "TS"
            defaultHint.isNotBlank() -> defaultHint.uppercase()
            else -> "AUTO"
        }
    }


    private val licenseCache = ConcurrentHashMap<String, String>()

    @Volatile
    private var currentActivePlayer: ExoPlayer? = null

    @Synchronized
    fun registerActivePlayer(player: ExoPlayer) {
        if (currentActivePlayer != null && currentActivePlayer != player) {
            try {
                currentActivePlayer?.stop()
                currentActivePlayer?.clearMediaItems()
                currentActivePlayer?.release()
            } catch (_: Exception) {}
        }
        currentActivePlayer = player
    }

    @Synchronized
    fun releaseActivePlayer() {
        try {
            currentActivePlayer?.stop()
            currentActivePlayer?.clearMediaItems()
            currentActivePlayer?.release()
        } catch (_: Exception) {}
        currentActivePlayer = null
        resetNetworkPools()
    }

    fun pauseActivePlayer() {
        try {
            currentActivePlayer?.pause()
            currentActivePlayer?.playWhenReady = false
        } catch (_: Exception) {}
    }

    /**
     * Completely resets Java/Android network connection pools, cookie stores, and ephemeral DRM caches
     * so that switching channels never has leftover TCP sockets or leaked authentication cookies.
     */
    fun resetNetworkPools() {
        try {
            // 1. Reset Java default CookieHandler so cookies from Channel A never leak into Channel B
            java.net.CookieHandler.setDefault(null)
        } catch (_: Exception) {}
        try {
            // 2. Clear license cache for dynamic/ephemeral licenses
            licenseCache.clear()
        } catch (_: Exception) {}
        try {
            // 3. Cycle system keep-alive property to force JVM to drop stale/pipelined HTTP connections
            System.setProperty("http.keepAlive", "false")
            System.setProperty("http.keepAlive", "true")
        } catch (_: Exception) {}
    }

    data class ParsedStreamInfo(
        val cleanUrl: String,
        val headers: Map<String, String>,
        val drm: DrmConfig
    )

    /**
     * Parses IPTV piped parameters such as:
     * url|license_type=clearkey&license_key=https://...&user-agent=...
     * url|license_type=clearkey&license_key=kid1:key1,kid2:key2&user-agent=...
     * url|User-Agent=...|Referer=...
     */
    fun parsePipedUrl(
        rawUrl: String,
        initialHeaders: Map<String, String> = emptyMap(),
        initialDrm: DrmConfig = DrmConfig()
    ): ParsedStreamInfo {
        val headers = initialHeaders.toMutableMap()
        var drm = initialDrm
        val trimmed = rawUrl.trim()
        if (!trimmed.contains("|")) {
            val clean = if (trimmed.endsWith("?")) trimmed.removeSuffix("?") else trimmed
            return ParsedStreamInfo(clean, headers, drm)
        }

        val pipeIndex = trimmed.indexOf('|')
        var cleanUrl = trimmed.substring(0, pipeIndex).trim()
        if (cleanUrl.endsWith("?")) {
            cleanUrl = cleanUrl.removeSuffix("?")
        }
        val paramString = trimmed.substring(pipeIndex + 1).trim()

        var licType = ""
        var licKey = ""

        // Pairs can be separated by '&' or '|'
        val tokens = paramString.split('&', '|')
        for (token in tokens) {
            val eqIndex = token.indexOf('=')
            if (eqIndex > 0) {
                val rawKey = token.substring(0, eqIndex).trim()
                val rawValue = token.substring(eqIndex + 1).trim()
                when (rawKey.lowercase()) {
                    "license_type", "drmscheme", "drm_scheme", "drm-scheme" -> {
                        licType = rawValue.lowercase()
                    }
                    "license_key", "license_url", "key_url", "drmlicense", "drm_license", "drm-license", "drmkey", "drm_key" -> {
                        licKey = rawValue
                    }
                    "keyid", "kid", "key_id" -> {
                        if (licKey.isEmpty()) licKey = rawValue else if (!licKey.contains(":")) licKey = "$rawValue:$licKey"
                    }
                    "key", "k" -> {
                        if (licKey.isEmpty()) licKey = rawValue else if (!licKey.contains(":")) licKey = "$licKey:$rawValue"
                    }
                    "user-agent", "http-user-agent" -> {
                        headers["User-Agent"] = rawValue
                        headers["user-agent"] = rawValue
                    }
                    "referer", "http-referrer", "referrer" -> {
                        headers["Referer"] = rawValue
                        headers["referer"] = rawValue
                    }
                    "origin", "http-origin" -> {
                        headers["Origin"] = rawValue
                        headers["origin"] = rawValue
                    }
                    "cookie", "http-cookie" -> {
                        headers["Cookie"] = rawValue
                        headers["cookie"] = rawValue
                    }
                    "authorization", "http-auth", "token", "auth" -> {
                        val authVal = if (rawValue.startsWith("Bearer ", true) || rawValue.startsWith("Basic ", true)) rawValue else "Bearer $rawValue"
                        headers["Authorization"] = authVal
                        headers["authorization"] = authVal
                    }
                    "stream_headers", "license_headers" -> {
                        val subTokens = rawValue.split('&')
                        for (sub in subTokens) {
                            val subEq = sub.indexOf('=')
                            if (subEq > 0) {
                                val sk = sub.substring(0, subEq).trim()
                                val sv = sub.substring(subEq + 1).trim()
                                headers[sk] = sv
                            }
                        }
                    }
                    else -> {
                        if (rawKey.isNotEmpty() && rawValue.isNotEmpty()) {
                            headers[rawKey] = rawValue
                        }
                    }
                }
            }
        }



        if (licType.isNotBlank() || licKey.isNotBlank()) {
            val scheme = if (licType.contains("widevine")) "widevine" else "clearkey"
            if (licKey.startsWith("http://", ignoreCase = true) || licKey.startsWith("https://", ignoreCase = true)) {
                // License key is an HTTP/HTTPS URL (e.g. keyid.php?id=143)
                drm = DrmConfig(
                    enabled = true,
                    scheme = scheme,
                    licenseUrl = licKey,
                    key = licKey,
                    keyId = licKey
                )
            } else {
                // License key contains single or comma-separated KID:KEY pairs
                // e.g. ae3d3b12...:4577...,911d...:c1fc...
                drm = DrmConfig(
                    enabled = true,
                    scheme = scheme,
                    key = licKey,
                    keyId = licKey
                )
            }
        }

        return ParsedStreamInfo(cleanUrl, headers, drm)
    }

    fun createPlayer(context: Context, stream: StreamSource): ExoPlayer {
        // Guarantee any previously active player instance is completely released and network connections closed
        releaseActivePlayer()
        resetNetworkPools()

        val targetUrl = if (stream.streamUrl.isNotBlank()) stream.streamUrl else stream.jsonChannelUrl
        val parsed = parsePipedUrl(targetUrl, stream.headers, stream.drm)
        val cleanUrl = parsed.cleanUrl
        val allHeaders = parsed.headers.toMutableMap()
        val streamDrm = parsed.drm

        if (stream.jsonToken.isNotBlank()) {
            val bearer = if (stream.jsonToken.startsWith("Bearer ")) stream.jsonToken else "Bearer ${stream.jsonToken}"
            allHeaders["Authorization"] = bearer
        }

        var sanitizedCleanUrl = run {
            var raw = cleanUrl.trim()
            if (raw.contains(" ")) raw = raw.replace(" ", "%20")
            val qIdx = raw.indexOf('?')
            if (qIdx != -1) {
                val pathPart = raw.substring(0, qIdx)
                val queryPart = raw.substring(qIdx)
                val sIdx = pathPart.indexOf("://")
                if (sIdx != -1) {
                    val proto = pathPart.substring(0, sIdx + 3)
                    val rest = pathPart.substring(sIdx + 3).replace(Regex("/+"), "/")
                    (proto + rest) + queryPart
                } else {
                    pathPart.replace(Regex("/+"), "/") + queryPart
                }
            } else {
                val sIdx = raw.indexOf("://")
                if (sIdx != -1) {
                    val proto = raw.substring(0, sIdx + 3)
                    val rest = raw.substring(sIdx + 3).replace(Regex("/+"), "/")
                    proto + rest
                } else {
                    cleanUrl
                }
            }
        }

        // Automatic Stalker stream resolution
        val isAlreadyResolvedStalker = (sanitizedCleanUrl.startsWith("http://", ignoreCase = true) || sanitizedCleanUrl.startsWith("https://", ignoreCase = true)) &&
            (sanitizedCleanUrl.contains(".m3u8", ignoreCase = true) || sanitizedCleanUrl.contains(".mpd", ignoreCase = true) || sanitizedCleanUrl.contains(".ts", ignoreCase = true)) &&
            !sanitizedCleanUrl.contains("localhost", ignoreCase = true)

        if (!isAlreadyResolvedStalker && (
            stream.streamType.equals("STALKER", ignoreCase = true) ||
            sanitizedCleanUrl.startsWith("ffrt ", ignoreCase = true) ||
            sanitizedCleanUrl.startsWith("ffmpeg ", ignoreCase = true) ||
            stream.cmd.isNotBlank()
        )) {
            val cmd = if (stream.cmd.isNotBlank()) stream.cmd else sanitizedCleanUrl
            val pUrl = stream.portalUrl.ifBlank { StalkerManager.DEFAULT_PORTAL_URL }
            val mac = stream.mac.ifBlank { StalkerManager.DEFAULT_MAC }
            val serial = stream.serial.ifBlank { StalkerManager.DEFAULT_SERIAL }
            val deviceId = stream.deviceId1.ifBlank { StalkerManager.DEFAULT_DEVICE_ID }
            try {
                val liveLink = java.util.concurrent.CompletableFuture.supplyAsync {
                    kotlinx.coroutines.runBlocking {
                        StalkerManager.createLiveLink(pUrl, mac, serial, deviceId, cmd)
                    }
                }.get(5000, java.util.concurrent.TimeUnit.MILLISECONDS)
                if (!liveLink.isNullOrBlank()) {
                    sanitizedCleanUrl = liveLink
                    allHeaders["User-Agent"] = StalkerManager.DEFAULT_USER_AGENT
                    allHeaders["Cookie"] = "mac=$mac; stb_lang=en; timezone=Europe/London;"
                }
            } catch (_: Exception) {}
        }

        // Clean any residual protocol wrapper prefixes to prevent ExoPlayer URI parse crashes
        if (sanitizedCleanUrl.startsWith("ffrt ", ignoreCase = true) ||
            sanitizedCleanUrl.startsWith("ffmpeg ", ignoreCase = true) ||
            sanitizedCleanUrl.startsWith("auto ", ignoreCase = true)
        ) {
            sanitizedCleanUrl = sanitizedCleanUrl.replace(Regex("""^(ffrt|ffmpeg|auto)\s+""", RegexOption.IGNORE_CASE), "").trim()
        }



        val cookieVal = allHeaders["Cookie"] ?: allHeaders["cookie"]
        if (!cookieVal.isNullOrBlank()) {
            allHeaders["Cookie"] = cookieVal
            allHeaders["cookie"] = cookieVal
        }
        val refererVal = allHeaders["Referer"] ?: allHeaders["referer"]
        if (!refererVal.isNullOrBlank()) {
            allHeaders["Referer"] = refererVal
            allHeaders["referer"] = refererVal
        }
        val originVal = allHeaders["Origin"] ?: allHeaders["origin"]
        if (!originVal.isNullOrBlank()) {
            allHeaders["Origin"] = originVal
            allHeaders["origin"] = originVal
        }

        val userAgent = allHeaders["User-Agent"]
            ?: allHeaders["user-agent"]
            ?: "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"

        allHeaders["User-Agent"] = userAgent
        allHeaders.putIfAbsent("Accept", "*/*")
        if (sanitizedCleanUrl.contains("github", ignoreCase = true)) {
            allHeaders["Accept"] = "text/plain, */*, application/x-mpegURL, application/vnd.apple.mpegurl"
        }

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setKeepPostFor302Redirects(true)
            .setDefaultRequestProperties(allHeaders)

        // Resilient Network Error Handling Policy: Automatically retry failed segments up to 8 times
        val loadErrorHandlingPolicy = object : DefaultLoadErrorHandlingPolicy(8) {
            override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
                val attempt = loadErrorInfo.errorCount
                return minOf(500L * attempt, 3000L)
            }
            override fun getMinimumLoadableRetryCount(dataType: Int): Int = 8
        }

        // Standard DefaultMediaSourceFactory with explicit dynamic headers and retry policy
        val extractorsFactory = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(httpDataSourceFactory, extractorsFactory)
            .setLoadErrorHandlingPolicy(loadErrorHandlingPolicy)
            .setLoadErrorHandlingPolicy(loadErrorHandlingPolicy)

        // ClearKey DRM Session Manager with LocalMediaDrmCallback + Dual PSSH (ClearKey & Common) for 100% reliable decryption on any manifest
        var clearKeyDrmSessionManager: DrmSessionManager? = null
        val effectiveDrm = if (!streamDrm.enabled && (streamDrm.key.isNotBlank() || streamDrm.keyId.isNotBlank() || !streamDrm.licenseUrl.isNullOrBlank())) {
            streamDrm.copy(enabled = true)
        } else {
            streamDrm
        }

        if (effectiveDrm.enabled && !effectiveDrm.scheme.contains("widevine", ignoreCase = true)) {
            val keyOrUrl = resolveClearKeyString(effectiveDrm)
            val clearKeyJson = buildClearKeyJson(keyOrUrl, allHeaders)
            if (!clearKeyJson.isNullOrEmpty()) {
                try {
                    val localCallback = LocalMediaDrmCallback(clearKeyJson.toByteArray(Charsets.UTF_8))
                    val defaultDelegate = DefaultDrmSessionManager.Builder()
                        .setUuidAndExoMediaDrmProvider(C.CLEARKEY_UUID, FrameworkMediaDrm.DEFAULT_PROVIDER)
                        .setMultiSession(true)
                        .build(localCallback)

                    val kidBytesList = extractKidBytesList(keyOrUrl, allHeaders)
                    val psshCommon = buildMultiClearKeyPssh(kidBytesList, C.COMMON_PSSH_UUID)
                    val psshClearKey = buildMultiClearKeyPssh(kidBytesList, C.CLEARKEY_UUID)
                    clearKeyDrmSessionManager = ClearKeyDrmSessionManager(defaultDelegate, psshCommon, psshClearKey)
                } catch (_: Exception) {}
            }
        }

        if (clearKeyDrmSessionManager != null) {
            mediaSourceFactory.setDrmSessionManagerProvider { _ ->
                clearKeyDrmSessionManager
            }
        }

        // High-Performance Resilient Buffering Engine (Eliminates auto-pause and freeze stalls)
        val allocator = DefaultAllocator(true, 64 * 1024)
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(
                8000,  // Min buffer: 8 seconds (fast live HLS synchronization)
                30000, // Max buffer: 30 seconds
                750,   // Ultra-fast start playback: 0.75s (instant live video start)
                1000   // Fast recovery after rebuffer: 1.0s
            )
            .setBackBuffer(
                15000, // Keep 15 seconds of back buffer
                true   // Retain from keyframe for seamless reverse jumps and codec stability
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .setUsage(C.USAGE_MEDIA)
            .build()

        // Live Playback Speed Control: Prevents drift and maintains smooth Audio-Video sync
        // Keeps safe offset so player never starves at live edge
        val livePlaybackSpeedControl = DefaultLivePlaybackSpeedControl.Builder()
            .setFallbackMinPlaybackSpeed(0.98f)
            .setFallbackMaxPlaybackSpeed(1.02f)
            .setMinUpdateIntervalMs(1000)
            .setProportionalControlFactor(0.1f)
            .build()

        val player = ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setRenderersFactory(renderersFactory)
            .setAudioAttributes(audioAttributes, true) // Enable audio focus handling so Android OS can pause it
            .setWakeMode(C.WAKE_MODE_NONE) // Release wake locks so CPU/WiFi sleep when backgrounded
            .setHandleAudioBecomingNoisy(true) // Pause on headphone unplug
            .setLivePlaybackSpeedControl(livePlaybackSpeedControl)
            .setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT)
            .build()

        player.volume = 1.0f

        val cleanStream = stream.copy(
            streamUrl = sanitizedCleanUrl,
            headers = allHeaders,
            drm = streamDrm
        )
        val mediaItem = buildMediaItem(cleanStream)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true

        registerActivePlayer(player)

        return player
    }

    private fun buildMediaItem(stream: StreamSource): MediaItem {
        val targetUrl = if (stream.streamUrl.isNotBlank()) stream.streamUrl else stream.jsonChannelUrl
        val parsed = parsePipedUrl(targetUrl, stream.headers, stream.drm)
        val allHeaders = parsed.headers.toMutableMap()

        if (stream.jsonToken.isNotBlank()) {
            val bearer = if (stream.jsonToken.startsWith("Bearer ") || stream.jsonToken.startsWith("Basic ")) stream.jsonToken else "Bearer ${stream.jsonToken}"
            allHeaders["Authorization"] = bearer
        }

        val cleanUrlSanitized = run {
            var raw = parsed.cleanUrl.trim()
            if (raw.contains(" ")) raw = raw.replace(" ", "%20")
            if (raw.contains("?")) {
                val qIdx = raw.indexOf("?")
                val pathPart = raw.substring(0, qIdx)
                val queryPart = raw.substring(qIdx)
                val sIdx = pathPart.indexOf("://")
                if (sIdx != -1) {
                    val proto = pathPart.substring(0, sIdx + 3)
                    val rest = pathPart.substring(sIdx + 3).replace(Regex("/+"), "/")
                    (proto + rest) + queryPart
                } else {
                    pathPart.replace(Regex("/+"), "/") + queryPart
                }
            } else {
                val sIdx = raw.indexOf("://")
                if (sIdx != -1) {
                    val proto = raw.substring(0, sIdx + 3)
                    val rest = raw.substring(sIdx + 3).replace(Regex("/+"), "/")
                    proto + rest
                } else {
                    raw
                }
            }
        }

        val uri = Uri.parse(cleanUrlSanitized)
        val builder = MediaItem.Builder()
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(stream.title)
                    .build()
            )

        val detected = detectStreamType(parsed.cleanUrl, stream.streamType)
        when (detected) {
            "MPD", "DASH" -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
            "M3U8", "HLS" -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            "MP4" -> builder.setMimeType(MimeTypes.VIDEO_MP4)
            "MKV" -> builder.setMimeType(MimeTypes.VIDEO_MATROSKA)
            "WEBM" -> builder.setMimeType(MimeTypes.VIDEO_WEBM)
            "TS" -> builder.setMimeType(MimeTypes.VIDEO_MP2T)
            else -> {
                // Auto-detect format via DefaultExtractorsFactory
            }
        }

        // Live Stream Playback: Gentle speed adaptation to maintain buffer runway
        if (detected == "M3U8" || detected == "HLS" || detected == "MPD" || detected == "DASH" || detected == "AUTO" || detected == "TS") {
            builder.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setMinPlaybackSpeed(0.97f)
                    .setMaxPlaybackSpeed(1.03f)
                    .build()
            )
        }

        // DRM Engine: Widevine (Jio, Hotstar, TataPlay) & ClearKey DRM (Single + Multi-Key support)
        val drm = if (!parsed.drm.enabled && (parsed.drm.key.isNotBlank() || parsed.drm.keyId.isNotBlank() || !parsed.drm.licenseUrl.isNullOrBlank())) {
            parsed.drm.copy(enabled = true)
        } else {
            parsed.drm
        }
        if (drm.enabled) {
            val scheme = drm.scheme.lowercase()
            val licUrl = drm.licenseUrl?.ifEmpty { null }

            if (scheme.contains("widevine")) {
                // Widevine Modular DRM
                if (!licUrl.isNullOrEmpty()) {
                    val drmBuilder = MediaItem.DrmConfiguration.Builder(C.WIDEVINE_UUID)
                        .setLicenseUri(Uri.parse(licUrl))
                        .setMultiSession(true)

                    if (allHeaders.isNotEmpty()) {
                        drmBuilder.setLicenseRequestHeaders(allHeaders)
                    }
                    builder.setDrmConfiguration(drmBuilder.build())
                }
            } else {
                // ClearKey DRM (Native W3C in-memory decryption handled by LocalMediaDrmCallback or setLicenseUri)
                val keyOrUrl = resolveClearKeyString(drm)
                val drmBuilder = MediaItem.DrmConfiguration.Builder(C.CLEARKEY_UUID)
                    .setMultiSession(true)
                if (keyOrUrl.startsWith("http://", ignoreCase = true) || keyOrUrl.startsWith("https://", ignoreCase = true)) {
                    drmBuilder.setLicenseUri(Uri.parse(keyOrUrl))
                }
                if (allHeaders.isNotEmpty()) {
                    drmBuilder.setLicenseRequestHeaders(allHeaders)
                }
                builder.setDrmConfiguration(drmBuilder.build())
            }
        }

        return builder.build()
    }

    /**
     * Normalizes various ClearKey DRM responses (Standard W3C {"keys":[...]}, single objects,
     * raw JSON arrays, and kid:key hex pairs) into standard W3C ClearKey JSON.
     */
    fun normalizeClearKeyResponse(rawResponse: String): String? {
        val trimmed = rawResponse.trim()
        if (trimmed.isEmpty()) return null

        // If response is HTML (Bot verification, Cloudflare, LiteSpeed, 404, etc.), reject it
        if (trimmed.startsWith("<") || trimmed.contains("<title>", ignoreCase = true) || trimmed.contains("lsrecaptcha", ignoreCase = true)) {
            return null
        }

        // 1. JSON Object
        if (trimmed.startsWith("{")) {
            try {
                val json = JSONObject(trimmed)
                if (json.has("keys")) {
                    val arr = json.optJSONArray("keys")
                    if (arr != null && arr.length() > 0) {
                        return trimmed
                    }
                }
                // Single key object: {"kty":"oct","k":"...","kid":"..."} or {"kid":"...","k":"..."}
                val kid = json.optString("kid").ifBlank { json.optString("key_id") }
                val k = json.optString("k").ifBlank { json.optString("key") }
                if (kid.isNotBlank() && k.isNotBlank()) {
                    val kidB64 = formatKeyToBase64Url(kid)
                    val kB64 = formatKeyToBase64Url(k)
                    val arr = JSONArray().apply {
                        put(JSONObject().apply {
                            put("kty", "oct")
                            put("kid", kidB64)
                            put("k", kB64)
                        })
                    }
                    return JSONObject().apply {
                        put("keys", arr)
                        put("type", "temporary")
                    }.toString()
                }
            } catch (_: Exception) {}
        }

        // 2. JSON Array: [{"kty":"oct","k":"...","kid":"..."}, ...]
        if (trimmed.startsWith("[")) {
            try {
                val arr = JSONArray(trimmed)
                val outArr = JSONArray()
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val kid = item.optString("kid").ifBlank { item.optString("key_id") }
                    val k = item.optString("k").ifBlank { item.optString("key") }
                    if (kid.isNotBlank() && k.isNotBlank()) {
                        outArr.put(JSONObject().apply {
                            put("kty", "oct")
                            put("kid", formatKeyToBase64Url(kid))
                            put("k", formatKeyToBase64Url(k))
                        })
                    }
                }
                if (outArr.length() > 0) {
                    return JSONObject().apply {
                        put("keys", outArr)
                        put("type", "temporary")
                    }.toString()
                }
            } catch (_: Exception) {}
        }

        // 3. Comma/newline-separated kid:key pairs (e.g. hex:hex)
        val keysArray = JSONArray()
        val pairs = trimmed.split(',', ';', '\n', '\r')
        for (pair in pairs) {
            val trimmedPair = pair.trim()
            if (!trimmedPair.contains(":")) continue
            val parts = trimmedPair.split(":")
            val kidRaw = parts[0].trim()
            val keyRaw = parts.getOrElse(1) { "" }.trim()
            if (kidRaw.isEmpty() || keyRaw.isEmpty()) continue

            val kidBase64 = formatKeyToBase64Url(kidRaw)
            val kBase64 = formatKeyToBase64Url(keyRaw)

            if (kidBase64.isNotEmpty() && kBase64.isNotEmpty()) {
                val keyObj = JSONObject().apply {
                    put("kty", "oct")
                    put("kid", kidBase64)
                    put("k", kBase64)
                }
                keysArray.put(keyObj)
            }
        }

        if (keysArray.length() > 0) {
            return JSONObject().apply {
                put("keys", keysArray)
                put("type", "temporary")
            }.toString()
        }

        return null
    }

    /**
     * Directly fetches JSON license for ClearKey over network on background thread
     * and caches result so channel re-creation is instantaneous (0 ms).
     */
    fun fetchLicenseJsonDirect(licUrl: String, headers: Map<String, String>): String? {
        val cached = licenseCache[licUrl]
        if (!cached.isNullOrEmpty()) return cached

        return try {
            val url = java.net.URL(licUrl)
            val conn = url.openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 2500
            conn.readTimeout = 2500
            conn.instanceFollowRedirects = true

            val reqHeaders = headers.toMutableMap()
            if (!reqHeaders.containsKey("User-Agent") && !reqHeaders.containsKey("user-agent")) {
                reqHeaders["User-Agent"] = "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"
            }

            reqHeaders.forEach { (k, v) -> conn.setRequestProperty(k, v) }

            if (conn.responseCode in 200..299) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val normalized = normalizeClearKeyResponse(response)
                if (!normalized.isNullOrBlank()) {
                    licenseCache[licUrl] = normalized
                    return normalized
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Non-blocking license fetcher:
     * If called on Android Main UI Thread, returns cached license or triggers async fetch without freezing the UI!
     * If called on a worker thread, fetches directly.
     */
    fun fetchLicenseJson(licUrl: String, headers: Map<String, String>): String? {
        val cached = licenseCache[licUrl]
        if (!cached.isNullOrEmpty()) return cached

        if (Looper.myLooper() == Looper.getMainLooper()) {
            return try {
                val future = CompletableFuture.supplyAsync {
                    fetchLicenseJsonDirect(licUrl, headers)
                }
                future.get(2500, java.util.concurrent.TimeUnit.MILLISECONDS)
            } catch (_: Exception) {
                null
            }
        }

        return fetchLicenseJsonDirect(licUrl, headers)
    }

    /**
     * Prepares stream asynchronously on Dispatchers.IO:
     * Resolves piped URLs, tokens, headers, and pre-fetches ClearKey licenses in background.
     */
    suspend fun prepareStreamAsync(stream: StreamSource): StreamSource = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var targetUrl = if (stream.streamUrl.isNotBlank()) stream.streamUrl else stream.jsonChannelUrl

        // Stalker Middleware Live Link Resolution
        val isStalkerStream = stream.streamType.equals("STALKER", ignoreCase = true) ||
                stream.cmd.isNotBlank() ||
                targetUrl.startsWith("ffrt ", ignoreCase = true) ||
                targetUrl.startsWith("ffmpeg ", ignoreCase = true) ||
                targetUrl.startsWith("stalker://", ignoreCase = true)

        if (isStalkerStream) {
            val cmd = if (stream.cmd.isNotBlank()) {
                stream.cmd
            } else if (targetUrl.startsWith("stalker://", ignoreCase = true)) {
                val qIdx = targetUrl.indexOf('?')
                if (qIdx != -1) {
                    val q = targetUrl.substring(qIdx + 1)
                    val pMap = q.split("&").associate {
                        val parts = it.split("=")
                        parts[0] to (if (parts.size > 1) java.net.URLDecoder.decode(parts[1], "UTF-8") else "")
                    }
                    pMap["cmd"] ?: targetUrl
                } else targetUrl
            } else {
                targetUrl
            }

            val pUrl = stream.portalUrl.ifBlank { StalkerManager.DEFAULT_PORTAL_URL }
            val mac = stream.mac.ifBlank { StalkerManager.DEFAULT_MAC }
            val serial = stream.serial.ifBlank { StalkerManager.DEFAULT_SERIAL }
            val deviceId = stream.deviceId1.ifBlank { StalkerManager.DEFAULT_DEVICE_ID }
            val resolvedStalker = StalkerManager.createLiveLink(
                portalUrl = pUrl,
                mac = mac,
                serial = serial,
                deviceId = deviceId,
                cmd = cmd
            )
            if (!resolvedStalker.isNullOrBlank()) {
                targetUrl = resolvedStalker
            }
        }

        val initialDrm = stream.drm

        val parsed = parsePipedUrl(targetUrl, stream.headers, initialDrm)
        var cleanUrl = parsed.cleanUrl
        val headers = parsed.headers.toMutableMap()
        var drm = parsed.drm

        if (stream.jsonToken.isNotBlank()) {
            val bearer = if (stream.jsonToken.startsWith("Bearer ") || stream.jsonToken.startsWith("Basic ")) stream.jsonToken else "Bearer ${stream.jsonToken}"
            headers["Authorization"] = bearer
        }

        if (isStalkerStream || cleanUrl.contains("packetcdn.me", ignoreCase = true) || stream.portalUrl.isNotBlank()) {
            val mac = stream.mac.ifBlank { StalkerManager.DEFAULT_MAC }
            headers["User-Agent"] = StalkerManager.DEFAULT_USER_AGENT
            headers["Cookie"] = "mac=$mac; stb_lang=en; timezone=Europe/London;"
        }

        if (drm.enabled && !drm.scheme.contains("widevine", ignoreCase = true)) {
            val keyOrUrl = resolveClearKeyString(drm)
            if (keyOrUrl.startsWith("http://", ignoreCase = true) || keyOrUrl.startsWith("https://", ignoreCase = true)) {
                val fetched = fetchLicenseJsonDirect(keyOrUrl, headers)
                val normalized = if (!fetched.isNullOrBlank()) normalizeClearKeyResponse(fetched) else null
                if (!normalized.isNullOrBlank()) {
                    drm = drm.copy(key = normalized, licenseUrl = "")
                }
            }
        }

        stream.copy(
            streamUrl = cleanUrl,
            headers = headers,
            drm = drm
        )
    }

    /**
     * Builds W3C compliant ClearKey JSON string supporting URLs, JSON payloads, or single/multiple comma-separated keys:
     * kid1:key1,kid2:key2,kid3:key3... (Supports Hex, UUIDs, Base64, and pre-formatted JSON)
     */
    fun buildClearKeyJson(rawKeyOrUrl: String, headers: Map<String, String> = emptyMap()): String? {
        val cleanStr = rawKeyOrUrl.trim()
        if (cleanStr.isEmpty()) return null

        // If it's a remote URL (e.g. keyid.php?id=143)
        if (cleanStr.startsWith("http://", ignoreCase = true) || cleanStr.startsWith("https://", ignoreCase = true)) {
            val fetched = fetchLicenseJson(cleanStr, headers)
            if (!fetched.isNullOrEmpty()) return normalizeClearKeyResponse(fetched)
            return null
        }

        return normalizeClearKeyResponse(cleanStr)
    }

    private fun formatKeyToBase64Url(keyStr: String): String {
        val trimmed = keyStr.trim()
        val hexClean = trimmed.replace("[^0-9a-fA-F]".toRegex(), "")

        // 128-bit key in Hex (32 hex characters)
        if (hexClean.length == 32 && (trimmed.length == 32 || trimmed.length == 36)) {
            val bytes = ByteArray(16)
            for (i in 0 until 16) {
                val index = i * 2
                bytes[i] = hexClean.substring(index, index + 2).toInt(16).toByte()
            }
            return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP).trim()
        }

        // Already Base64 (22 to 24 chars)
        if (trimmed.length in 22..24 && !trimmed.contains(" ")) {
            return trimmed.replace('+', '-').replace('/', '_').replace("=", "").trim()
        }

        // General even-length Hex fallback
        if (hexClean.isNotEmpty() && hexClean.length % 2 == 0) {
            val bytes = ByteArray(hexClean.length / 2)
            for (i in bytes.indices) {
                val index = i * 2
                bytes[i] = hexClean.substring(index, index + 2).toInt(16).toByte()
            }
            return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP).trim()
        }

        return trimmed.replace('+', '-').replace('/', '_').replace("=", "").trim()
    }

    fun resolveClearKeyString(drm: DrmConfig): String {
        val licUrl = drm.licenseUrl?.trim() ?: ""
        val kid = drm.keyId.trim()
        val key = drm.key.trim()

        if (key.contains(":") || key.startsWith("{") || key.contains(",")) {
            return key
        }
        if (kid.isNotEmpty() && key.isNotEmpty()) {
            return "$kid:$key"
        }
        if (licUrl.startsWith("http://", ignoreCase = true) || licUrl.startsWith("https://", ignoreCase = true)) {
            return licUrl
        }
        if (licUrl.contains(":") || licUrl.startsWith("{") || licUrl.contains(",")) {
            return licUrl
        }
        if (key.isNotEmpty()) return key
        if (licUrl.isNotEmpty()) return licUrl
        return kid
    }

    fun extractKidBytesList(keyOrUrl: String, headers: Map<String, String> = emptyMap()): List<ByteArray> {
        val cleanStr = keyOrUrl.trim()
        if (cleanStr.isEmpty()) return emptyList()

        val result = mutableListOf<ByteArray>()

        // If it's a URL, fetch JSON and parse KIDs
        if (cleanStr.startsWith("http://", ignoreCase = true) || cleanStr.startsWith("https://", ignoreCase = true)) {
            val json = fetchLicenseJson(cleanStr, headers)
            if (!json.isNullOrEmpty()) {
                return extractKidsFromJson(json)
            }
            return emptyList()
        }

        // If it's JSON (Object or Array)
        if (cleanStr.startsWith("{") || cleanStr.startsWith("[")) {
            return extractKidsFromJson(cleanStr)
        }

        // Comma-separated pairs: kid1:key1,kid2:key2...
        val pairs = cleanStr.split(',', ';', '\n', '\r')
        for (pair in pairs) {
            val trimmedPair = pair.trim()
            if (!trimmedPair.contains(":")) continue
            val parts = trimmedPair.split(":")
            val kidRaw = parts[0].trim()
            val kidBytes = parseKeyTo16Bytes(kidRaw)
            if (kidBytes != null) {
                result.add(kidBytes)
            }
        }
        return result
    }

    private fun extractKidsFromJson(jsonStr: String): List<ByteArray> {
        val list = mutableListOf<ByteArray>()
        try {
            val normalized = normalizeClearKeyResponse(jsonStr) ?: jsonStr
            val obj = JSONObject(normalized)
            val arr = obj.optJSONArray("keys") ?: return emptyList()
            for (i in 0 until arr.length()) {
                val keyObj = arr.getJSONObject(i)
                val kidB64 = keyObj.optString("kid")
                if (kidB64.isNotEmpty()) {
                    val bytes = Base64.decode(kidB64, Base64.URL_SAFE or Base64.DEFAULT)
                    if (bytes != null && bytes.size == 16) {
                        list.add(bytes)
                    }
                }
            }
        } catch (_: Exception) {}
        return list
    }

    private fun parseKeyTo16Bytes(keyStr: String): ByteArray? {
        val trimmed = keyStr.trim()
        val hexClean = trimmed.replace("[^0-9a-fA-F]".toRegex(), "")
        if (hexClean.length == 32) {
            val bytes = ByteArray(16)
            for (i in 0 until 16) {
                val idx = i * 2
                bytes[i] = hexClean.substring(idx, idx + 2).toInt(16).toByte()
            }
            return bytes
        }
        if (trimmed.length in 22..24) {
            try {
                val bytes = Base64.decode(trimmed, Base64.URL_SAFE or Base64.DEFAULT)
                if (bytes != null && bytes.size == 16) return bytes
            } catch (_: Exception) {}
        }
        return null
    }

    fun buildMultiClearKeyPssh(kidBytesList: List<ByteArray>, uuid: UUID = C.COMMON_PSSH_UUID): ByteArray {
        val count = if (kidBytesList.isEmpty()) 1 else kidBytesList.size
        val size = 36 + count * 16
        val pssh = ByteArray(size)
        val bb = java.nio.ByteBuffer.wrap(pssh)
        bb.putInt(size)
        bb.put("pssh".toByteArray(Charsets.US_ASCII))
        bb.put(1.toByte()) // Version 1
        bb.put(0.toByte()); bb.put(0.toByte()); bb.put(0.toByte()) // Flags = 0
        bb.putLong(uuid.mostSignificantBits)
        bb.putLong(uuid.leastSignificantBits)
        bb.putInt(count)
        if (kidBytesList.isNotEmpty()) {
            for (k in kidBytesList) {
                val padded = ByteArray(16)
                System.arraycopy(k, 0, padded, 0, minOf(k.size, 16))
                bb.put(padded)
            }
        } else {
            bb.put(ByteArray(16))
        }
        bb.putInt(0)
        return pssh
    }

    // --- VIDEO QUALITY / RESOLUTION MANAGEMENT ---

    fun getAvailableVideoQualities(player: ExoPlayer?): List<VideoTrackOption> {
        val list = mutableListOf<VideoTrackOption>()
        list.add(VideoTrackOption(label = "Auto", sublabel = "Adaptive (Auto Bitrate)", height = 0))

        if (player == null) {
            list.add(VideoTrackOption("1080p Full HD", "1920x1080 • Best quality", 1080))
            list.add(VideoTrackOption("720p HD", "1280x720 • Smooth HD stream", 720))
            list.add(VideoTrackOption("480p SD", "854x480 • Saves mobile data", 480))
            list.add(VideoTrackOption("360p Data Saver", "640x360 • Minimal data usage", 360))
            return list
        }

        val tracks = player.currentTracks
        val seenHeights = mutableSetOf<Int>()

        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_VIDEO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val h = format.height
                    if (h > 0 && !seenHeights.contains(h)) {
                        seenHeights.add(h)
                        val label = when {
                            h >= 1080 -> "1080p Full HD"
                            h >= 720 -> "720p HD"
                            h >= 480 -> "480p SD"
                            h >= 360 -> "360p Data Saver"
                            else -> "${h}p"
                        }
                        val bitrateText = if (format.bitrate > 0) "${format.bitrate / 1000} kbps" else ""
                        val resText = if (format.width > 0 && format.height > 0) "${format.width}x${format.height}" else ""
                        val sub = listOf(resText, bitrateText).filter { it.isNotBlank() }.joinToString(" • ")

                        list.add(
                            VideoTrackOption(
                                label = label,
                                sublabel = sub.ifBlank { "Resolution ${h}p" },
                                height = h,
                                bitrate = format.bitrate,
                                trackGroup = group,
                                trackIndex = i
                            )
                        )
                    }
                }
            }
        }

        val autoOption = list.first()
        val streamOptions = list.drop(1).sortedByDescending { it.height }

        if (streamOptions.isEmpty()) {
            return listOf(
                autoOption,
                VideoTrackOption("1080p Full HD", "1920x1080 • Best quality", 1080),
                VideoTrackOption("720p HD", "1280x720 • Smooth HD stream", 720),
                VideoTrackOption("480p SD", "854x480 • Saves mobile data", 480),
                VideoTrackOption("360p Data Saver", "640x360 • Minimal data usage", 360)
            )
        }

        return listOf(autoOption) + streamOptions
    }

    fun setVideoQuality(player: ExoPlayer?, option: VideoTrackOption) {
        if (player == null) return
        val builder = player.trackSelectionParameters.buildUpon()

        if (option.height <= 0 || option.label.startsWith("Auto", ignoreCase = true)) {
            builder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            builder.clearVideoSizeConstraints()
        } else {
            if (option.trackGroup != null && option.trackIndex >= 0) {
                builder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                builder.addOverride(
                    androidx.media3.common.TrackSelectionOverride(option.trackGroup.mediaTrackGroup, option.trackIndex)
                )
            } else {
                builder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                builder.setMaxVideoSize(Int.MAX_VALUE, option.height)
                builder.setMinVideoSize(0, option.height)
            }
        }
        player.trackSelectionParameters = builder.build()
    }

    // --- MULTI-LANGUAGE AUDIO TRACK MANAGEMENT ---

    fun getAvailableAudioLanguages(player: ExoPlayer?): List<AudioTrackOption> {
        val list = mutableListOf<AudioTrackOption>()
        if (player == null) return list

        val tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val isSelected = group.isTrackSelected(i)
                    val lang = format.language ?: "und"
                    val rawLabel = format.label?.trim() ?: ""
                    val isMeaningless = rawLabel.isBlank() ||
                            rawLabel.contains("undefined", ignoreCase = true) ||
                            rawLabel.contains("unknown", ignoreCase = true) ||
                            rawLabel.equals("null", ignoreCase = true)

                    val label = when {
                        !isMeaningless -> rawLabel
                        lang.equals("hi", true) || lang.equals("hin", true) -> "Hindi"
                        lang.equals("en", true) || lang.equals("eng", true) -> "English"
                        lang.equals("ur", true) || lang.equals("urd", true) -> "Urdu"
                        lang.equals("bn", true) || lang.equals("ben", true) -> "Bengali"
                        lang.equals("ta", true) || lang.equals("tam", true) -> "Tamil"
                        lang.equals("te", true) || lang.equals("tel", true) -> "Telugu"
                        lang.equals("mr", true) || lang.equals("mar", true) -> "Marathi"
                        lang.equals("pa", true) || lang.equals("pan", true) -> "Punjabi"
                        lang.equals("ar", true) || lang.equals("ara", true) -> "Arabic"
                        lang.equals("fa", true) || lang.equals("per", true) -> "Persian"
                        lang.equals("und", true) || isMeaningless -> if (list.isEmpty()) "Hindi / Main Audio" else "Audio Track ${list.size + 1}"
                        else -> java.util.Locale(lang).displayLanguage.ifBlank { "Audio Track ${list.size + 1}" }
                    }
                    list.add(
                        AudioTrackOption(
                            label = label,
                            language = lang,
                            trackGroup = group,
                            trackIndex = i,
                            isSelected = isSelected
                        )
                    )
                }
            }
        }
        return list
    }

    fun setAudioLanguage(player: ExoPlayer?, option: AudioTrackOption) {
        if (player == null) return
        val builder = player.trackSelectionParameters.buildUpon()
        if (option.trackGroup != null && option.trackIndex >= 0) {
            builder.clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            builder.addOverride(
                androidx.media3.common.TrackSelectionOverride(option.trackGroup.mediaTrackGroup, option.trackIndex)
            )
            if (option.language.isNotBlank() && option.language != "und") {
                builder.setPreferredAudioLanguage(option.language)
            }
        } else if (option.language.isNotBlank()) {
            builder.setPreferredAudioLanguage(option.language)
        }
        player.trackSelectionParameters = builder.build()
    }
}

data class VideoTrackOption(
    val label: String,
    val sublabel: String,
    val height: Int,
    val bitrate: Int = 0,
    val trackGroup: androidx.media3.common.Tracks.Group? = null,
    val trackIndex: Int = -1
)

data class AudioTrackOption(
    val label: String,
    val language: String,
    val trackGroup: androidx.media3.common.Tracks.Group? = null,
    val trackIndex: Int = -1,
    val isSelected: Boolean = false
)

@OptIn(UnstableApi::class)
class ClearKeyDrmSessionManager(
    private val delegate: DefaultDrmSessionManager,
    private val psshCommon: ByteArray,
    private val psshClearKey: ByteArray
) : DrmSessionManager {

    private fun modifyFormat(format: Format): Format {
        val original = format.drmInitData
        if (original != null) {
            // If the stream already carries valid ClearKey/Common scheme data with non-empty payload, preserve it
            var hasValidData = false
            for (i in 0 until original.schemeDataCount) {
                val sd = original.get(i)
                if ((sd.matches(C.CLEARKEY_UUID) || sd.matches(C.COMMON_PSSH_UUID)) && sd.data != null && sd.data!!.isNotEmpty()) {
                    hasValidData = true
                    break
                }
            }
            if (hasValidData) {
                return format
            }
        }

        val schemeCommon = DrmInitData.SchemeData(C.COMMON_PSSH_UUID, MimeTypes.VIDEO_MP4, psshCommon)
        val schemeClearKey = DrmInitData.SchemeData(C.CLEARKEY_UUID, MimeTypes.VIDEO_MP4, psshClearKey)

        val list = mutableListOf(schemeCommon, schemeClearKey)
        if (original != null) {
            for (i in 0 until original.schemeDataCount) {
                val sd = original.get(i)
                list.add(sd)
            }
        }
        val synthetic = DrmInitData(list)
        return format.buildUpon().setDrmInitData(synthetic).build()
    }

    override fun preacquireSession(
        eventDispatcher: DrmSessionEventListener.EventDispatcher?,
        format: Format
    ): DrmSessionManager.DrmSessionReference {
        return delegate.preacquireSession(eventDispatcher, modifyFormat(format))
    }

    override fun acquireSession(
        eventDispatcher: DrmSessionEventListener.EventDispatcher?,
        format: Format
    ): DrmSession? {
        return delegate.acquireSession(eventDispatcher, modifyFormat(format))
    }

    override fun getCryptoType(format: Format): Int {
        val modified = modifyFormat(format)
        val res = delegate.getCryptoType(modified)
        return if (res != C.CRYPTO_TYPE_UNSUPPORTED) res else C.CRYPTO_TYPE_FRAMEWORK
    }

    override fun setPlayer(playbackLooper: Looper, playerId: PlayerId) {
        delegate.setPlayer(playbackLooper, playerId)
    }

    override fun prepare() {
        delegate.prepare()
    }

    override fun release() {
        delegate.release()
    }
}
