package com.hdstream.live.player

import com.hdstream.live.model.DrmConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * High-Performance Stalker Middleware / Ministra Portal Client
 * Supports MAG250 STB handshake, profile activation, genre categorization,
 * live channel extraction (10,000+ channels), and on-demand stream URL creation.
 */
object StalkerManager {

    const val DEFAULT_USER_AGENT = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2712 Mobile Safari/533.3"
    const val DEFAULT_PORTAL_URL = "http://play.tatasky.xyz/stalker_portal/c/"
    const val DEFAULT_MAC = "00:1A:79:82:5F:01"
    const val DEFAULT_SERIAL = "8B910A07977CD"
    const val DEFAULT_DEVICE_ID = "FDDB952641AA2826CE9E6B6159D9D5242B41F93A69288C342C3508764A3E3621"

    private data class StalkerSession(
        val token: String,
        val timestamp: Long
    )

    private data class CachedChannelList(
        val channels: List<ParsedChannelItem>,
        val timestamp: Long
    )

    // Token Cache: portalUrl|mac -> Session
    private val sessionCache = ConcurrentHashMap<String, StalkerSession>()

    // Channel List Cache: portalUrl|mac -> CachedChannelList (Valid for 15 minutes)
    private val channelListCache = ConcurrentHashMap<String, CachedChannelList>()

    fun getCachedChannels(): List<ParsedChannelItem> {
        return channelListCache.values.firstOrNull()?.channels ?: emptyList()
    }

    // Live link cache: portalUrl|mac|cmd -> link (Valid for 15 seconds so dynamic tokens stay fresh)
    private val liveLinkCache = ConcurrentHashMap<String, Pair<String, Long>>()

    fun normalizeLoadPhpUrl(portalUrl: String): String {
        var p = portalUrl.trim().trimEnd('/')
        if (p.endsWith("/server/load.php", ignoreCase = true)) return p
        if (p.endsWith("/c", ignoreCase = true)) {
            p = p.substring(0, p.length - 2).trimEnd('/')
        }
        if (!p.contains("/stalker_portal", ignoreCase = true) && !p.contains("/server", ignoreCase = true)) {
            p = "$p/stalker_portal"
        }
        return "$p/server/load.php"
    }

    fun extractHost(urlStr: String): String {
        return try {
            URL(urlStr).host
        } catch (_: Exception) {
            ""
        }
    }

    fun buildStalkerHeaders(mac: String, token: String? = null, host: String = ""): Map<String, String> {
        val headers = mutableMapOf(
            "User-Agent" to DEFAULT_USER_AGENT,
            "X-User-Agent" to "Model: MAG250; Link: Ethernet",
            "Accept" to "*/*"
        )
        if (host.isNotBlank()) {
            headers["Host"] = host
        }
        val effectiveMac = if (mac.isNotBlank()) mac else DEFAULT_MAC
        val cookieVal = if (!token.isNullOrBlank()) {
            "mac=$effectiveMac; stb_lang=en; timezone=Europe/London; token=$token;"
        } else {
            "mac=$effectiveMac; stb_lang=en; timezone=Europe/London;"
        }
        headers["Cookie"] = cookieVal
        if (!token.isNullOrBlank()) {
            headers["Authorization"] = "Bearer $token"
        }
        return headers
    }

    /**
     * Executes Step A: Handshake + Step B: Profile activation to obtain a valid Bearer token.
     */
    suspend fun getOrAuthenticateToken(
        portalUrl: String,
        mac: String = DEFAULT_MAC,
        serial: String = DEFAULT_SERIAL,
        deviceId: String = DEFAULT_DEVICE_ID,
        forceRefresh: Boolean = false
    ): String? = withContext(Dispatchers.IO) {
        val effectiveMac = if (mac.isNotBlank()) mac.trim() else DEFAULT_MAC
        val effectiveSerial = if (serial.isNotBlank()) serial.trim() else DEFAULT_SERIAL
        val effectiveDeviceId = if (deviceId.isNotBlank()) deviceId.trim() else DEFAULT_DEVICE_ID
        val loadPhp = normalizeLoadPhpUrl(portalUrl)
        val host = extractHost(loadPhp)
        val cacheKey = "$loadPhp|$effectiveMac"

        if (!forceRefresh) {
            val cached = sessionCache[cacheKey]
            if (cached != null && (System.currentTimeMillis() - cached.timestamp < 2 * 60 * 60 * 1000L)) {
                return@withContext cached.token
            }
        }

        try {
            // 1. Handshake
            val handshakeUrl = "$loadPhp?type=stb&action=handshake&token=&mac=$effectiveMac"
            val hsHeaders = buildStalkerHeaders(effectiveMac, token = null, host = host)
            val hsResp = httpGet(handshakeUrl, hsHeaders) ?: return@withContext null

            val hsJson = JSONObject(hsResp)
            val jsObj = hsJson.optJSONObject("js") ?: return@withContext null
            val token = jsObj.optString("token")
            if (token.isBlank()) return@withContext null

            // 2. Profile Activation (Required auth_second_step=1)
            val profileUrl = "$loadPhp?type=stb&action=get_profile&stb_type=MAG250&sn=$effectiveSerial&device_id=$effectiveDeviceId&device_id2=$effectiveDeviceId&auth_second_step=1"
            val profHeaders = buildStalkerHeaders(effectiveMac, token = token, host = host)
            val profResp = httpGet(profileUrl, profHeaders)

            // Cache token
            sessionCache[cacheKey] = StalkerSession(token, System.currentTimeMillis())
            return@withContext token
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Fetches all TV genres from Stalker Portal.
     */
    private suspend fun fetchGenres(loadPhp: String, token: String, mac: String, host: String): Map<String, String> = withContext(Dispatchers.IO) {
        val map = mutableMapOf<String, String>()
        try {
            val url = "$loadPhp?type=itv&action=get_genres"
            val headers = buildStalkerHeaders(mac, token = token, host = host)
            val resp = httpGet(url, headers) ?: return@withContext emptyMap()
            if (resp.trim().startsWith("{")) {
                val json = JSONObject(resp)
                val js = json.optJSONArray("js")
                if (js != null) {
                    for (i in 0 until js.length()) {
                        val g = js.getJSONObject(i)
                        val id = g.optString("id")
                        val title = g.optString("title").ifBlank { g.optString("name") }
                        if (id.isNotBlank() && title.isNotBlank() && id != "*") {
                            map[id] = title
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        map
    }

    /**
     * Step B: Fetches complete channel list (10,000+ channels) with genres, logos, and cmd commands.
     */
    suspend fun fetchChannels(
        portalUrl: String,
        mac: String = DEFAULT_MAC,
        serial: String = DEFAULT_SERIAL,
        deviceId: String = DEFAULT_DEVICE_ID
    ): List<ParsedChannelItem> = withContext(Dispatchers.IO) {
        val effectiveMac = if (mac.isNotBlank()) mac.trim() else DEFAULT_MAC
        val effectiveSerial = if (serial.isNotBlank()) serial.trim() else DEFAULT_SERIAL
        val effectiveDeviceId = if (deviceId.isNotBlank()) deviceId.trim() else DEFAULT_DEVICE_ID
        val loadPhp = normalizeLoadPhpUrl(portalUrl)
        val host = extractHost(loadPhp)
        val cacheKey = "$loadPhp|$effectiveMac"

        val cached = channelListCache[cacheKey]
        if (cached != null && (System.currentTimeMillis() - cached.timestamp < 15 * 60 * 1000L)) {
            return@withContext cached.channels
        }

        var token = getOrAuthenticateToken(loadPhp, effectiveMac, effectiveSerial, effectiveDeviceId)
        if (token.isNullOrBlank()) {
            return@withContext emptyList()
        }

        val genres = fetchGenres(loadPhp, token, effectiveMac, host)

        val channelsUrl = "$loadPhp?type=itv&action=get_all_channels"
        var headers = buildStalkerHeaders(effectiveMac, token = token, host = host)
        var resp = httpGet(channelsUrl, headers)

        if (resp != null && (resp.contains("Authorization failed", ignoreCase = true) || !resp.trim().startsWith("{"))) {
            // Re-authenticate once and retry
            token = getOrAuthenticateToken(loadPhp, effectiveMac, effectiveSerial, effectiveDeviceId, forceRefresh = true)
            if (token != null) {
                headers = buildStalkerHeaders(effectiveMac, token = token, host = host)
                resp = httpGet(channelsUrl, headers)
            }
        }

        if (resp.isNullOrBlank() || !resp.trim().startsWith("{")) {
            return@withContext emptyList()
        }

        val portalBase = try {
            val u = URL(loadPhp)
            "${u.protocol}://${u.authority}"
        } catch (_: Exception) { "" }

        val result = mutableListOf<ParsedChannelItem>()
        try {
            val root = JSONObject(resp)
            val js = root.optJSONObject("js") ?: return@withContext emptyList()
            val dataArr = js.optJSONArray("data") ?: return@withContext emptyList()

            for (i in 0 until dataArr.length()) {
                val item = dataArr.getJSONObject(i)
                val name = item.optString("name").trim()
                val cmd = item.optString("cmd").trim()
                if (name.isBlank() || cmd.isBlank()) continue

                var logo = item.optString("logo").trim()
                if (logo.isNotBlank() && !logo.startsWith("http://") && !logo.startsWith("https://")) {
                    logo = if (logo.startsWith("/")) "$portalBase$logo" else "$portalBase/$logo"
                }

                val genreId = item.optString("tv_genre_id")
                val categoryName = genres[genreId] ?: "Stalker Live"

                if (M3uParser.isAdultContent(categoryName, name)) continue

                val channelHeaders = mapOf(
                    "User-Agent" to DEFAULT_USER_AGENT,
                    "Cookie" to "mac=$effectiveMac; stb_lang=en; timezone=Europe/London;"
                )

                result.add(
                    ParsedChannelItem(
                        title = name,
                        streamUrl = cmd,
                        streamType = "STALKER",
                        logo = logo,
                        category = categoryName,
                        quality = "1080p HD",
                        headers = channelHeaders,
                        drm = DrmConfig(),
                        portalUrl = portalUrl,
                        mac = effectiveMac,
                        cmd = cmd,
                        serial = effectiveSerial,
                        deviceId1 = effectiveDeviceId
                    )
                )
            }
        } catch (_: Exception) {}

        if (result.isNotEmpty()) {
            channelListCache[cacheKey] = CachedChannelList(result, System.currentTimeMillis())
        }

        result
    }

    /**
     * Step C: Calls `create_link` to generate the real playable live stream URL (M3U8 / MPEG-TS).
     */
    suspend fun createLiveLink(
        portalUrl: String,
        mac: String = DEFAULT_MAC,
        serial: String = DEFAULT_SERIAL,
        deviceId: String = DEFAULT_DEVICE_ID,
        cmd: String
    ): String? = withContext(Dispatchers.IO) {
        val cleanCmd = cmd.trim()
        if (cleanCmd.isBlank()) return@withContext null

        // If cmd is already a full direct playable HTTP/HTTPS link without Stalker prefix
        if ((cleanCmd.startsWith("http://", ignoreCase = true) || cleanCmd.startsWith("https://", ignoreCase = true)) &&
            (cleanCmd.contains(".m3u8", ignoreCase = true) || cleanCmd.contains(".mpd", ignoreCase = true) || cleanCmd.contains(".ts", ignoreCase = true)) &&
            !cleanCmd.contains("localhost", ignoreCase = true)
        ) {
            return@withContext cleanCmd
        }

        val effectiveMac = if (mac.isNotBlank()) mac.trim() else DEFAULT_MAC
        val effectiveSerial = if (serial.isNotBlank()) serial.trim() else DEFAULT_SERIAL
        val effectiveDeviceId = if (deviceId.isNotBlank()) deviceId.trim() else DEFAULT_DEVICE_ID
        val loadPhp = normalizeLoadPhpUrl(portalUrl)
        val host = extractHost(loadPhp)
        val linkCacheKey = "$loadPhp|$effectiveMac|$cleanCmd"

        val cachedLink = liveLinkCache[linkCacheKey]
        if (cachedLink != null && (System.currentTimeMillis() - cachedLink.second < 15 * 1000L)) {
            return@withContext cachedLink.first
        }

        var token = getOrAuthenticateToken(loadPhp, effectiveMac, effectiveSerial, effectiveDeviceId)
        if (token.isNullOrBlank()) return@withContext null

        suspend fun executeCreateLink(currentToken: String): String? {
            return try {
                val encodedCmd = URLEncoder.encode(cleanCmd, "UTF-8")
                val url = "$loadPhp?type=itv&action=create_link&cmd=$encodedCmd"
                val headers = buildStalkerHeaders(effectiveMac, token = currentToken, host = host)
                val resp = httpGet(url, headers) ?: return null

                if (resp.contains("Authorization failed", ignoreCase = true)) {
                    return null
                }

                if (resp.trim().startsWith("{")) {
                    val root = JSONObject(resp)
                    val js = root.optJSONObject("js") ?: return null
                    var rawStreamUrl = js.optString("cmd").trim()
                    if (rawStreamUrl.isNotBlank()) {
                        // Strip leading ffmpeg / ffrt / auto wrapper flags
                        rawStreamUrl = rawStreamUrl.replace(Regex("""^(ffrt|ffmpeg|auto)\s+""", RegexOption.IGNORE_CASE), "").trim()
                        rawStreamUrl = rawStreamUrl.replace("\\/", "/")
                        return rawStreamUrl
                    }
                }
                null
            } catch (_: Exception) {
                null
            }
        }

        var streamUrl = executeCreateLink(token)
        if (streamUrl.isNullOrBlank()) {
            // Re-authenticate and retry once
            token = getOrAuthenticateToken(loadPhp, effectiveMac, effectiveSerial, effectiveDeviceId, forceRefresh = true)
            if (token != null) {
                streamUrl = executeCreateLink(token)
            }
        }

        if (!streamUrl.isNullOrBlank()) {
            liveLinkCache[linkCacheKey] = Pair(streamUrl, System.currentTimeMillis())
        }

        streamUrl
    }

    private fun httpGet(urlStr: String, headers: Map<String, String>): String? {
        return try {
            val url = URL(urlStr)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.instanceFollowRedirects = true
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }
}

