package com.hdstream.live.player

import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class XtreamCredentials(
    val server: String,
    val username: String,
    val password: String
)

object XtreamCodesManager {
    private const val TAG = "XtreamCodesManager"

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    private data class CachedChannels(
        val channels: List<ParsedChannelItem>,
        val timestamp: Long
    )

    private val channelCache = ConcurrentHashMap<String, CachedChannels>()
    private const val CACHE_TTL_MS = 15 * 60 * 1000L // 15 minutes cache

    /**
     * Checks whether an input string represents an Xtream Codes configuration.
     * Supports raw JSON, query URLs (player_api.php, get.php), or credentials.
     */
    fun isXtream(input: String): Boolean {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return false
        if (trimmed.startsWith("{") && trimmed.contains("\"server\"") && trimmed.contains("\"username\"")) {
            return true
        }
        if (trimmed.contains("player_api.php", ignoreCase = true)) return true
        if (trimmed.contains("get.php", ignoreCase = true) && trimmed.contains("username=", ignoreCase = true)) return true
        if (parseCredentials(trimmed) != null) return true
        return false
    }

    /**
     * Extracts XtreamCredentials from arbitrary input:
     * 1. JSON string: {"server": "...", "username": "...", "password": "..."}
     * 2. URL string: http://domain.com/player_api.php?username=X&password=Y
     * 3. URL string: http://domain.com/get.php?username=X&password=Y...
     */
    fun parseCredentials(input: String): XtreamCredentials? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null

        // Format 1: JSON
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            try {
                val json = JSONObject(trimmed)
                val server = json.optString("server", "")
                    .ifBlank { json.optString("server_url", "") }
                    .ifBlank { json.optString("host", "") }
                    .ifBlank { json.optString("url", "") }
                    .trim()
                val username = json.optString("username", "")
                    .ifBlank { json.optString("user", "") }
                    .trim()
                val password = json.optString("password", "")
                    .ifBlank { json.optString("pass", "") }
                    .trim()

                if (server.isNotBlank() && username.isNotBlank() && password.isNotBlank()) {
                    return XtreamCredentials(cleanServerUrl(server), username, password)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to parse Xtream JSON: ${e.message}")
            }
        }

        // Format 2: URL containing username and password query params
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            try {
                val uri = Uri.parse(trimmed)
                val username = uri.getQueryParameter("username") ?: uri.getQueryParameter("user")
                val password = uri.getQueryParameter("password") ?: uri.getQueryParameter("pass")
                if (!username.isNullOrBlank() && !password.isNullOrBlank()) {
                    val server = "${uri.scheme}://${uri.authority}"
                    return XtreamCredentials(cleanServerUrl(server), username.trim(), password.trim())
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to parse Xtream URL: ${e.message}")
            }
        }

        return null
    }

    fun cleanServerUrl(url: String): String {
        var clean = url.trim()
        if (!clean.startsWith("http://", ignoreCase = true) && !clean.startsWith("https://", ignoreCase = true)) {
            clean = "http://$clean"
        }
        return clean.trimEnd('/')
    }

    fun clearCache() {
        channelCache.clear()
    }

    /**
     * Fetches live channels from an Xtream Codes server using player_api.php.
     * Caches in memory for instant navigation.
     */
    suspend fun fetchChannels(
        server: String,
        username: String,
        password: String,
        forceRefresh: Boolean = false
    ): List<ParsedChannelItem> = withContext(Dispatchers.IO) {
        val cleanServer = cleanServerUrl(server)
        val cleanUser = username.trim()
        val cleanPass = password.trim()

        if (cleanServer.isBlank() || cleanUser.isBlank() || cleanPass.isBlank()) {
            Log.e(TAG, "Invalid Xtream credentials: server='$cleanServer', user='$cleanUser'")
            return@withContext emptyList()
        }

        val cacheKey = "${cleanServer}_${cleanUser}_${cleanPass}"
        if (!forceRefresh) {
            val cached = channelCache[cacheKey]
            if (cached != null && (System.currentTimeMillis() - cached.timestamp < CACHE_TTL_MS)) {
                Log.d(TAG, "Returning ${cached.channels.size} cached Xtream channels for $cleanServer")
                return@withContext cached.channels
            }
        }

        Log.i(TAG, "Fetching Xtream channels from $cleanServer for user $cleanUser...")

        // Step 1: Fetch Live Categories to get human-readable category names
        val categoryMap = mutableMapOf<String, String>()
        try {
            val catUrl = "$cleanServer/player_api.php?username=$cleanUser&password=$cleanPass&action=get_live_categories"
            val req = Request.Builder()
                .url(catUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36")
                .header("Accept", "*/*")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (resp.isSuccessful) {
                val body = resp.body?.string()
                if (!body.isNullOrBlank() && body.trim().startsWith("[")) {
                    val arr = JSONArray(body)
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val catId = obj.optString("category_id", "").trim()
                        val catName = obj.optString("category_name", "").trim()
                        if (catId.isNotBlank() && catName.isNotBlank()) {
                            categoryMap[catId] = catName
                        }
                    }
                    Log.d(TAG, "Loaded ${categoryMap.size} Xtream categories")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch Xtream categories: ${e.message}")
        }

        // Step 2: Fetch Live Streams
        val results = mutableListOf<ParsedChannelItem>()
        var successApi = false
        try {
            val streamsUrl = "$cleanServer/player_api.php?username=$cleanUser&password=$cleanPass&action=get_live_streams"
            val req = Request.Builder()
                .url(streamsUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36")
                .header("Accept", "*/*")
                .build()
            val resp = httpClient.newCall(req).execute()
            if (resp.isSuccessful) {
                val body = resp.body?.string()
                if (!body.isNullOrBlank() && body.trim().startsWith("[")) {
                    val arr = JSONArray(body)
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val name = obj.optString("name", "").trim()
                        val streamId = obj.optString("stream_id", "").trim()
                        if (name.isBlank() || streamId.isBlank()) continue

                        val catId = obj.optString("category_id", "").trim()
                        val categoryName = categoryMap[catId]?.ifBlank { "Live Channels" } ?: "Live Channels"

                        // Hide adult content
                        if (M3uParser.isAdultContent(categoryName, name)) continue

                        val icon = obj.optString("stream_icon", "").trim()
                        // Use .m3u8 for HLS streaming with adaptive bitrate & ExoPlayer compatibility
                        val streamUrl = "$cleanServer/live/$cleanUser/$cleanPass/$streamId.m3u8"

                        results.add(
                            ParsedChannelItem(
                                title = name,
                                streamUrl = streamUrl,
                                streamType = "M3U8",
                                logo = icon,
                                category = categoryName,
                                quality = "1080p HD"
                            )
                        )
                    }
                    successApi = results.isNotEmpty()
                    Log.i(TAG, "Successfully parsed ${results.size} live channels from player_api.php")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch live streams via player_api.php: ${e.message}")
        }

        // Step 3: Fallback to get.php M3U playlist if player_api.php returned nothing
        if (!successApi) {
            try {
                val m3uUrl = "$cleanServer/get.php?username=$cleanUser&password=$cleanPass&type=m3u_plus&output=m3u8"
                Log.d(TAG, "Attempting fallback to get.php M3U: $m3uUrl")
                val req = Request.Builder()
                    .url(m3uUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36")
                    .build()
                val resp = httpClient.newCall(req).execute()
                if (resp.isSuccessful) {
                    val m3uBody = resp.body?.string() ?: ""
                    if (m3uBody.isNotBlank()) {
                        val parsed = M3uParser.parseM3u(m3uBody, defaultCategory = "Live Channels")
                        results.addAll(parsed.filter { !M3uParser.isAdultContent(it.category, it.title) })
                        Log.i(TAG, "Parsed ${results.size} channels via get.php M3U fallback")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Xtream fallback get.php failed: ${e.message}")
            }
        }

        if (results.isNotEmpty()) {
            channelCache[cacheKey] = CachedChannels(results, System.currentTimeMillis())
        }

        results
    }
}
