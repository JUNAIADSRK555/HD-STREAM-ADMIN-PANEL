# ==============================================================================
# HD STREAM - ProGuard & R8 Code Hardening & Anti-Decompilation Rules
# ==============================================================================

# Obfuscation & optimization directives
-repackageclasses ''
-allowaccessmodification
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Strip debug and verbose logs from release builds
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}

# ------------------------------------------------------------------------------
# Jetpack Compose
# ------------------------------------------------------------------------------
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
-keepattributes *Annotation*,InnerClasses,EnclosingMethod,Signature

# ------------------------------------------------------------------------------
# Kotlin Coroutines & Reflection
# ------------------------------------------------------------------------------
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**

# ------------------------------------------------------------------------------
# AndroidX Media3 / ExoPlayer Engine (HLS, DASH, DRM ClearKey, UI)
# ------------------------------------------------------------------------------
-keep class androidx.media3.** { *; }
-keep interface androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keep class androidx.media3.exoplayer.** { *; }
-keep class androidx.media3.exoplayer.hls.** { *; }
-keep class androidx.media3.exoplayer.dash.** { *; }
-keep class androidx.media3.exoplayer.drm.** { *; }
-keep class androidx.media3.ui.** { *; }

# ------------------------------------------------------------------------------
# Data Models & Gson Serialization (Keep fields from renaming)
# ------------------------------------------------------------------------------
-keepattributes Signature
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.hdstream.live.model.** { *; }
-keep class com.hdstream.live.player.ParsedChannelItem { *; }
-dontwarn com.google.gson.**

# ------------------------------------------------------------------------------
# OkHttp & Okio (Network Client)
# ------------------------------------------------------------------------------
-keepattributes EnclosingMethod
-keepclassmembers class okhttp3.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**

# ------------------------------------------------------------------------------
# Chrome Custom Tabs & Browser Support
# ------------------------------------------------------------------------------
-keep class androidx.browser.** { *; }
-dontwarn androidx.browser.**

# ------------------------------------------------------------------------------
# Google Play Services & Advertising ID
# ------------------------------------------------------------------------------
-keep class com.google.android.gms.ads.identifier.** { *; }
-keep interface com.google.android.gms.ads.identifier.** { *; }
-dontwarn com.google.android.gms.**

# ------------------------------------------------------------------------------
# Core Security, Anti-Tamper & Sniffer Detection Engine
# ------------------------------------------------------------------------------
-keep class com.hdstream.live.util.AdGateManager {
    public static ** isOwnerDevice(...);
    public static ** shouldShowAdGate(...);
    public static ** isAdUnlocked(...);
    public static ** unlockForHours(...);
}
-keep class com.hdstream.live.util.DeviceUtils {
    public static ** isGenuineTv(...);
    public static ** isTv(...);
    public static ** hasMobileHardware(...);
}
-keep class com.hdstream.live.util.SecurityUtils {
    public static ** detectSnifferApp(...);
    public static ** checkSecurityThreat(...);
}
