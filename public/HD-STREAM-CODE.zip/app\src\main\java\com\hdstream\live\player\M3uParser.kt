package com.hdstream.live.player

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hdstream.live.model.DrmConfig
import com.hdstream.live.model.LiveStreamEvent
import com.hdstream.live.model.StreamSource
import com.hdstream.live.model.TeamInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

data class ParsedChannelItem(
    val title: String,
    val streamUrl: String,
    val streamType: String = "M3U8",
    val logo: String = "",
    val category: String = "Live Sports",
    val quality: String = "1080p HD",
    val headers: Map<String, String> = emptyMap(),
    val drm: DrmConfig = DrmConfig(),
    val portalUrl: String = "",
    val mac: String = "",
    val cmd: String = "",
    val serial: String = "",
    val deviceId1: String = ""
)

object M3uParser {

    /**
     * Adult Content Filter: Strips out 18+, Adult, XXX, Porn, Erotic, and NSFW channels & categories.
     */
    fun isAdultContent(category: String, title: String): Boolean {
        val combined = "$category $title".lowercase().trim()
        if (combined.isEmpty()) return false
        if (combined.contains("18+") || combined.contains("+18") || combined.contains("xxx") || combined.contains("xx+")) {
            return true
        }
        val adultKeywords = listOf(
            "adult", "porn", "porno", "erotic", "erotica", "nsfw", "brazzers",
            "playboy", "hustler", "penthouse", "redlight", "red light", "stripper",
            "softcore", "hardcore", "nudity", "nude", "desibhabhi", "bhabhi",
            "camgirl", "livecam", "dorcel", "vivid red", "exxxotica", "for adults",
            "adults only", "mature 18", "hentai", "jav"
        )
        if (adultKeywords.any { combined.contains(it) }) return true
        if (Regex("""\b(sex|sexy|boobs|pussy)\b""", RegexOption.IGNORE_CASE).containsMatchIn(combined)) return true
        return false
    }

    // High-performance memory cache for parsed playlists (Eliminates repeated downloads for Jio TV & Google Drive)
    private val playlistCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, String>>()
    private const val CACHE_TTL_MS = 300_000L // 5 minutes fresh cache

    private fun extractGoogleDriveFileId(url: String): String? {
        val idRegex1 = Regex("[?&]id=([a-zA-Z0-9_-]+)")
        val match1 = idRegex1.find(url)
        if (match1 != null) return match1.groupValues[1]

        val idRegex2 = Regex("/file/d/([a-zA-Z0-9_-]+)")
        val match2 = idRegex2.find(url)
        if (match2 != null) return match2.groupValues[1]

        return null
    }

    private fun sanitizeUrl(urlString: String): String {
        val trimmed = urlString.trim()
        if (trimmed.contains("drive.google.com", ignoreCase = true)) {
            val fileId = extractGoogleDriveFileId(trimmed)
            if (!fileId.isNullOrBlank()) {
                return "https://drive.usercontent.google.com/download?id=$fileId&export=download"
            }
        }
        return trimmed
    }

    private val okHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    private fun fetchWithOkHttp(targetUrl: String): String? {
        return try {
            val request = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
                .header("Accept", "*/*")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()?.trim()
                    if (!body.isNullOrBlank() &&
                        !body.contains("Checking your browser", ignoreCase = true) &&
                        !body.contains("jschallenge", ignoreCase = true) &&
                        !body.contains("Bot Verification", ignoreCase = true) &&
                        !body.contains("lsrecaptcha", ignoreCase = true)) {
                        body
                    } else null
                } else null
            }
        } catch (e: Exception) {
            android.util.Log.w("M3uParser", "fetchWithOkHttp failed for $targetUrl: ${e.message}")
            null
        }
    }

    private fun fetchWithRedirects(initialUrl: String, timeoutMs: Int = 15000): String? {
        var curUrl = initialUrl
        var redirects = 0
        var cookies = ""
        while (redirects < 6) {
            try {
                val url = URL(curUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = timeoutMs
                conn.readTimeout = timeoutMs
                conn.instanceFollowRedirects = false // Handle manually to support cross-domain & 303 redirects
                conn.requestMethod = "GET"
                val ua = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                conn.setRequestProperty("User-Agent", ua)
                conn.setRequestProperty("Accept", "application/json, text/plain, */*")
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate")
                conn.setRequestProperty("Pragma", "no-cache")
                if (cookies.isNotBlank()) {
                    conn.setRequestProperty("Cookie", cookies)
                }

                val code = conn.responseCode
                val setCookie = conn.getHeaderField("Set-Cookie")
                if (!setCookie.isNullOrBlank()) {
                    cookies = setCookie.split(";").firstOrNull() ?: ""
                }

                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        curUrl = if (loc.startsWith("http://") || loc.startsWith("https://")) {
                            loc
                        } else {
                            URL(url, loc).toString()
                        }
                        redirects++
                        continue
                    }
                }

                if (code in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val text = reader.readText()
                    reader.close()
                    val trimmed = text.trim()
                    if (trimmed.isNotBlank() && 
                        !trimmed.contains("Checking your browser", ignoreCase = true) && 
                        !trimmed.contains("jschallenge", ignoreCase = true) &&
                        !trimmed.contains("Bot Verification", ignoreCase = true) &&
                        !trimmed.contains("lsrecaptcha", ignoreCase = true)) {
                        return text
                    }
                }
                return null
            } catch (_: Exception) {
                return null
            }
        }
        return null
    }

    suspend fun fetchFromUrl(urlString: String): String = withContext(Dispatchers.IO) {
        val cleanUrl = sanitizeUrl(urlString)

        val cached = playlistCache[cleanUrl]
        val now = System.currentTimeMillis()
        if (cached != null && (now - cached.first) < CACHE_TTL_MS) {
            return@withContext cached.second
        }

        // 1. Try high-performance OkHttp with automated redirects and transparent gzip decompression
        val okHttpResult = fetchWithOkHttp(cleanUrl)
        if (!okHttpResult.isNullOrBlank()) {
            playlistCache[cleanUrl] = Pair(System.currentTimeMillis(), okHttpResult)
            return@withContext okHttpResult
        }

        // 2. Fallback to manual HttpURLConnection redirect handler
        val fallbackContent = fetchWithRedirects(cleanUrl, timeoutMs = 15000)
        if (!fallbackContent.isNullOrBlank()) {
            playlistCache[cleanUrl] = Pair(System.currentTimeMillis(), fallbackContent)
            return@withContext fallbackContent
        }

        throw java.io.IOException("Failed to load playlist from $urlString")
    }

    fun unescapeHtml(input: String): String {
        if (!input.contains("&")) return input
        return input
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&nbsp;", " ")
    }

    fun cleanText(input: String): String {
        if (input.isBlank()) return ""
        val noTags = input.replace(Regex("<[^>]*>"), "")
        return unescapeHtml(noTags).trim()
    }

    fun isHtmlOrScriptLine(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return true
        if (trimmed.startsWith("<") || trimmed.endsWith(">") || trimmed.contains("</")) return true
        val lower = trimmed.lowercase()
        return lower.startsWith("<!doctype") ||
               lower.startsWith("<html") ||
               lower.startsWith("<head") ||
               lower.startsWith("<body") ||
               lower.startsWith("<script") ||
               lower.startsWith("<style") ||
               lower.startsWith("<meta") ||
               lower.startsWith("<link") ||
               lower.contains("disable-devtool") ||
               lower.contains("window.location") ||
               lower.contains("document.") ||
               lower.contains("function(") ||
               lower.startsWith("var ") ||
               lower.startsWith("const ") ||
               lower.startsWith("let ")
    }

    fun parseM3u(content: String, defaultCategory: String = "Live Sports"): List<ParsedChannelItem> {
        val items = mutableListOf<ParsedChannelItem>()
        if (content.isBlank()) return items

        val lines = content.lines()

        var currentTitle = ""
        var currentLogo = ""
        var currentCategory = defaultCategory
        val currentKodiProps = mutableMapOf<String, String>()
        val currentHeaders = mutableMapOf<String, String>()

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            // Safely skip any HTML markup or JavaScript injections before or inside M3U
            if (isHtmlOrScriptLine(line) && !line.startsWith("#")) {
                continue
            }

            if (line.contains("__hdnea__") || line.contains("hdntl")) {
                try {
                    ExoPlayerHelper.updateDynamicTokens(line)
                } catch (e: Exception) {
                    android.util.Log.w("M3uParser", "Failed to update dynamic tokens: ${e.message}")
                }
            }

            try {
                when {
                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        // Extract title after comma
                        val commaIndex = line.lastIndexOf(',')
                        val rawTitle = if (commaIndex != -1) line.substring(commaIndex + 1).trim() else "Live Stream"
                        currentTitle = cleanText(rawTitle).ifBlank { "Live Stream" }

                        // Extract tvg-logo
                        val logoMatch = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (logoMatch != null) {
                            val logoVal = cleanText(logoMatch.groupValues[1])
                            if (logoVal.startsWith("http://") || logoVal.startsWith("https://")) {
                                currentLogo = logoVal
                            }
                        }

                        // Extract group-title
                        val groupMatch = Regex("""group-title="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (groupMatch != null) {
                            val groupVal = cleanText(groupMatch.groupValues[1])
                            if (groupVal.isNotBlank() && !groupVal.startsWith("<") && !groupVal.equals("null", ignoreCase = true)) {
                                currentCategory = groupVal
                            }
                        }

                        // Extract headers in EXTINF
                        val uaMatch = Regex("""http-user-agent="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (uaMatch != null && uaMatch.groupValues[1].isNotBlank()) currentHeaders["User-Agent"] = uaMatch.groupValues[1].trim()

                        val refMatch = Regex("""http-referrer="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (refMatch != null && refMatch.groupValues[1].isNotBlank()) currentHeaders["Referer"] = refMatch.groupValues[1].trim()

                        val originMatch = Regex("""http-origin="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (originMatch != null && originMatch.groupValues[1].isNotBlank()) currentHeaders["Origin"] = originMatch.groupValues[1].trim()

                        val cookieMatch = Regex("""http-cookie="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (cookieMatch != null && cookieMatch.groupValues[1].isNotBlank()) currentHeaders["Cookie"] = cookieMatch.groupValues[1].trim()

                        val authMatch = Regex("""(?:http-auth|token)="([^"]*)"""", RegexOption.IGNORE_CASE).find(line)
                        if (authMatch != null && authMatch.groupValues[1].isNotBlank()) {
                            val token = authMatch.groupValues[1].trim()
                            currentHeaders["Authorization"] = if (token.startsWith("Bearer ", true) || token.startsWith("Basic ", true)) token else "Bearer $token"
                        }
                    }
                    line.startsWith("#EXTHTTP:", ignoreCase = true) -> {
                        val jsonStr = line.substring(9).trim()
                        try {
                            val obj = org.json.JSONObject(jsonStr)
                            val keys = obj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                val v = obj.optString(k, "").trim()
                                if (v.isNotBlank()) {
                                    currentHeaders[k] = v
                                    if (k.equals("cookie", ignoreCase = true)) currentHeaders["Cookie"] = v
                                    if (k.equals("user-agent", ignoreCase = true)) currentHeaders["User-Agent"] = v
                                    if (k.equals("referer", ignoreCase = true) || k.equals("referrer", ignoreCase = true)) currentHeaders["Referer"] = v
                                    if (k.equals("origin", ignoreCase = true)) currentHeaders["Origin"] = v
                                }
                            }
                        } catch (e: Exception) {
                            android.util.Log.w("M3uParser", "Malformed EXTHTTP line: ${e.message}")
                        }
                    }
                    line.startsWith("#KODIPROP:", ignoreCase = true) -> {
                        val prop = line.substring(10).trim()
                        val eqIdx = prop.indexOf('=')
                        if (eqIdx != -1) {
                            val k = prop.substring(0, eqIdx).trim().lowercase()
                            val v = prop.substring(eqIdx + 1).trim()
                            currentKodiProps[k] = v

                            if (k.contains("stream_headers") || k.contains("license_headers")) {
                                val pairs = v.split('&')
                                for (pair in pairs) {
                                    val sEq = pair.indexOf('=')
                                    if (sEq > 0) {
                                        val sk = pair.substring(0, sEq).trim()
                                        val sv = pair.substring(sEq + 1).trim()
                                        currentHeaders[sk] = sv
                                    }
                                }
                            }
                        }
                    }
                    line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                        val opt = line.substring(11).trim()
                        val eqIdx = opt.indexOf('=')
                        if (eqIdx != -1) {
                            val k = opt.substring(0, eqIdx).trim().lowercase()
                            val v = opt.substring(eqIdx + 1).trim()
                            if (k.contains("user-agent")) currentHeaders["User-Agent"] = v
                            if (k.contains("referrer") || k.contains("referer")) currentHeaders["Referer"] = v
                            if (k.contains("origin")) currentHeaders["Origin"] = v
                            if (k.contains("cookie")) currentHeaders["Cookie"] = v
                            if (k.contains("extra-headers")) {
                                val pairs = v.split(';')
                                for (pair in pairs) {
                                    val cIdx = pair.indexOf(':')
                                    if (cIdx > 0) {
                                        val ehK = pair.substring(0, cIdx).trim()
                                        val ehV = pair.substring(cIdx + 1).trim()
                                        currentHeaders[ehK] = ehV
                                    }
                                }
                            }
                            if (k.contains("auth") || k.contains("token")) {
                                currentHeaders["Authorization"] = if (v.startsWith("Bearer ", true) || v.startsWith("Basic ", true)) v else "Bearer $v"
                            }
                        }
                    }
                    !line.startsWith("#") && (line.startsWith("http://") || line.startsWith("https://") || line.startsWith("rtmp://") || line.startsWith("rtsp://")) -> {
                        // Extract pure stream URL without HTML/tag debris or trailing quotes
                        val streamUrl = line.split(Regex("""[\s<"'>]""")).firstOrNull { 
                            it.startsWith("http://") || it.startsWith("https://") || it.startsWith("rtmp://") || it.startsWith("rtsp://") 
                        }?.trim() ?: ""

                        if (streamUrl.isBlank() || streamUrl.contains("no-live-events.invalid", ignoreCase = true)) {
                            currentTitle = ""
                            currentLogo = ""
                            currentKodiProps.clear()
                            currentHeaders.clear()
                            continue
                        }

                        // DRM Detection from Kodi properties
                        var drm = DrmConfig()
                        val licType = currentKodiProps["inputstream.adaptive.license_type"]?.lowercase() ?: ""
                        val licKey = currentKodiProps["inputstream.adaptive.license_key"] ?: ""

                        if (licType.contains("widevine") || licType.contains("com.widevine.alpha")) {
                            val cleanLic = licKey.split("|").firstOrNull() ?: licKey
                            drm = DrmConfig(
                                enabled = true,
                                scheme = "widevine",
                                key = cleanLic,
                                licenseUrl = cleanLic
                            )
                        } else if (licType.contains("clearkey") || licType.contains("org.w3.clearkey") || licKey.isNotBlank()) {
                            val isUrl = licKey.startsWith("http://", ignoreCase = true) || licKey.startsWith("https://", ignoreCase = true)
                            drm = DrmConfig(
                                enabled = true,
                                scheme = "clearkey",
                                keyId = if (isUrl) "" else licKey,
                                key = licKey,
                                licenseUrl = if (isUrl) licKey else ""
                            )
                        }

                        // Parse inline piped parameters (|license_type=clearkey&license_key=...&user-agent=...)
                        val parsedPipe = ExoPlayerHelper.parsePipedUrl(streamUrl, currentHeaders, drm)
                        val finalCleanUrl = parsedPipe.cleanUrl
                        val finalHeaders = parsedPipe.headers
                        val finalDrm = parsedPipe.drm

                        val streamType = when {
                            currentKodiProps["inputstream.adaptive.manifest_type"]?.equals("dash", ignoreCase = true) == true -> "MPD"
                            finalCleanUrl.contains(".mpd", ignoreCase = true) || streamUrl.contains(".mpd", ignoreCase = true) -> "MPD"
                            finalCleanUrl.contains(".ts", ignoreCase = true) -> "TS"
                            else -> "M3U8"
                        }

                        val isSony = currentTitle.contains("sony", ignoreCase = true) || 
                                     currentCategory.contains("sony", ignoreCase = true) || 
                                     currentTitle.contains("set", ignoreCase = true) || 
                                     currentTitle.contains("sab", ignoreCase = true) || 
                                     currentTitle.contains("ten", ignoreCase = true) ||
                                     streamUrl.contains("slivcdn.com", ignoreCase = true)

                        val resolvedLogo = if (currentLogo.isNotBlank()) {
                            currentLogo
                        } else if (isSony) {
                            resolveSonyLogo(currentTitle)
                        } else {
                            currentLogo
                        }

                        if (!isAdultContent(currentCategory, currentTitle)) {
                            items.add(
                                ParsedChannelItem(
                                    title = currentTitle.ifBlank { "Channel ${items.size + 1}" },
                                    streamUrl = finalCleanUrl,
                                    streamType = streamType,
                                    logo = resolvedLogo,
                                    category = currentCategory.ifBlank { defaultCategory },
                                    quality = "1080p HD",
                                    headers = finalHeaders,
                                    drm = finalDrm
                                )
                            )
                        }

                        // Reset for next stream
                        currentTitle = ""
                        currentLogo = ""
                        currentCategory = defaultCategory
                        currentKodiProps.clear()
                        currentHeaders.clear()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("M3uParser", "Error parsing line: $line", e)
            }
        }
        return items
    }

    fun parseJson(content: String, defaultCategory: String = "Live Sports"): List<ParsedChannelItem> {
        val items = mutableListOf<ParsedChannelItem>()
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return items

        try {
            val allItemObjects = mutableListOf<Pair<String, org.json.JSONObject>>()

            if (trimmed.startsWith("[")) {
                val rootArray = org.json.JSONArray(trimmed)
                for (i in 0 until rootArray.length()) {
                    val obj = rootArray.optJSONObject(i)
                    if (obj != null) {
                        allItemObjects.add(Pair(defaultCategory, obj))
                    }
                }
            } else if (trimmed.startsWith("{")) {
                val root = org.json.JSONObject(trimmed)
                val keys = root.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val arr = root.optJSONArray(k)
                    if (arr != null) {
                        val catForThisArray = when (k.lowercase()) {
                            "matches", "data", "items", "channels", "streams", "list", "results" -> defaultCategory
                            "livematches", "live_matches", "live" -> "Live"
                            "upcomingmatches", "upcoming_matches", "upcoming" -> "Upcoming"
                            "finishedmatches", "finished_matches" -> "Finished"
                            else -> k
                        }
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i)
                            if (obj != null) {
                                allItemObjects.add(Pair(catForThisArray, obj))
                            }
                        }
                    } else {
                        val nestedObj = root.optJSONObject(k)
                        if (nestedObj != null && (nestedObj.has("streamUrl") || nestedObj.has("url") || nestedObj.has("channels") || nestedObj.has("streams"))) {
                            allItemObjects.add(Pair(k, nestedObj))
                        }
                    }
                }
            }

            for ((inheritedCat, itemObj) in allItemObjects) {
                val parentTitle = itemObj.optString("match_name",
                    itemObj.optString("heading", 
                    itemObj.optString("title", 
                    itemObj.optString("name", 
                    itemObj.optString("channelName", "Live Stream")))))

                val parentPoster = itemObj.optString("cover_image",
                    itemObj.optString("banner_logo",
                    itemObj.optString("poster", 
                    itemObj.optString("bannerUrl", 
                    itemObj.optString("banner",
                    itemObj.optString("logo", 
                    itemObj.optString("image", 
                    itemObj.optString("imageUrl", 
                    itemObj.optString("team1_logo", "")))))))))

                val parentCat = itemObj.optString("event_category",
                    itemObj.optString("categories", 
                    itemObj.optString("category", 
                    itemObj.optString("sport",
                    itemObj.optString("group", inheritedCat)))))

                // Extract all nested streams / servers / channels / links
                val nestedArr = itemObj.optJSONArray("channels")
                    ?: itemObj.optJSONArray("streams")
                    ?: itemObj.optJSONArray("servers")
                    ?: itemObj.optJSONArray("links")
                    ?: itemObj.optJSONArray("sources")
                    ?: itemObj.optJSONArray("episodes")

                if (nestedArr != null && nestedArr.length() > 0) {
                    for (j in 0 until nestedArr.length()) {
                        val subObj = nestedArr.optJSONObject(j) ?: continue
                        val subName = subObj.optString("name", 
                            subObj.optString("title", 
                            subObj.optString("language",
                            subObj.optString("server", 
                            subObj.optString("quality", "Server ${j + 1}")))))

                        val rawUrl = subObj.optString("playlist_url",
                            subObj.optString("streamUrl", 
                            subObj.optString("url", 
                            subObj.optString("stream_url",
                            subObj.optString("link", 
                            subObj.optString("src", 
                            subObj.optString("file", "")))))))

                        if (rawUrl.isBlank()) continue

                        val subLogo = subObj.optString("logo", 
                            subObj.optString("poster", 
                            subObj.optString("icon", parentPoster)))

                        val subCat = subObj.optString("category", 
                            subObj.optString("group", parentCat))

                        // Extract DRM (supports nested "drm" object, flat fields, or colon-separated drm_key)
                        val subDrmObj = subObj.optJSONObject("drm") ?: itemObj.optJSONObject("drm")
                        var kid = (subDrmObj?.optString("keyId", subDrmObj.optString("kid", "")) ?: "")
                            .ifBlank { subObj.optString("keyId", subObj.optString("kid", itemObj.optString("keyId", itemObj.optString("kid", "")))) }
                            .let { if (it.equals("null", ignoreCase = true)) "" else it.trim() }
                        var key = (subDrmObj?.optString("key", subDrmObj.optString("k", "")) ?: "")
                            .ifBlank { subObj.optString("key", subObj.optString("k", itemObj.optString("key", itemObj.optString("k", "")))) }
                            .let { if (it.equals("null", ignoreCase = true)) "" else it.trim() }
                        var licUrl = (subDrmObj?.optString("licenseUrl", subDrmObj.optString("license_url", "")) ?: "")
                            .ifBlank { subObj.optString("licenseUrl", subObj.optString("license_url", itemObj.optString("licenseUrl", itemObj.optString("license_url", "")))) }
                            .let { if (it.equals("null", ignoreCase = true)) "" else it.trim() }
                        val rawDrmKey = subObj.optString("drm_key", itemObj.optString("drm_key", "")).trim()
                        if (kid.isBlank() && key.isBlank() && rawDrmKey.isNotBlank()) {
                            if (rawDrmKey.contains(":")) {
                                val parts = rawDrmKey.split(":")
                                kid = parts.getOrNull(0)?.trim() ?: ""
                                key = parts.getOrNull(1)?.trim() ?: ""
                            } else if (rawDrmKey.startsWith("http://") || rawDrmKey.startsWith("https://")) {
                                licUrl = rawDrmKey
                            } else if (rawDrmKey.length == 32) {
                                key = rawDrmKey
                            }
                        }

                        val rawScheme = (subDrmObj?.optString("scheme", subDrmObj.optString("type", "")) ?: "")
                            .ifBlank { subObj.optString("scheme", subObj.optString("type", itemObj.optString("scheme", itemObj.optString("type", "")))) }
                        val scheme = if (rawScheme.isNotBlank()) {
                            if (rawScheme.contains("widevine", ignoreCase = true)) "widevine" else "clearkey"
                        } else if (licUrl.isNotBlank()) "widevine" else "clearkey"

                        val drm = if (kid.isNotBlank() || key.isNotBlank() || licUrl.isNotBlank()) {
                            DrmConfig(enabled = true, scheme = scheme, keyId = kid, key = key, licenseUrl = licUrl.ifBlank { null })
                        } else {
                            DrmConfig(enabled = false)
                        }

                        // Extract Headers
                        val headersMap = mutableMapOf<String, String>()
                        val cookie = subObj.optString("cookie", itemObj.optString("cookie", ""))
                        if (cookie.isNotBlank()) headersMap["Cookie"] = cookie
                        val userAgent = subObj.optString("userAgent", subObj.optString("user-agent", itemObj.optString("userAgent", itemObj.optString("user-agent", ""))))
                        if (userAgent.isNotBlank()) headersMap["User-Agent"] = userAgent
                        val referer = subObj.optString("referer", subObj.optString("referrer", itemObj.optString("referer", itemObj.optString("referrer", ""))))
                        if (referer.isNotBlank()) headersMap["Referer"] = referer
                        val origin = subObj.optString("origin", itemObj.optString("origin", ""))
                        if (origin.isNotBlank()) headersMap["Origin"] = origin
                        val headersObj = subObj.optJSONObject("headers") ?: itemObj.optJSONObject("headers")
                        if (headersObj != null) {
                            val it = headersObj.keys()
                            while (it.hasNext()) {
                                val hk = it.next()
                                headersMap[hk] = headersObj.optString(hk)
                            }
                        }

                        val parsedPipe = ExoPlayerHelper.parsePipedUrl(rawUrl, headersMap, drm)

                        val titleLabel = if (nestedArr.length() > 1 && !subName.equals(parentTitle, ignoreCase = true)) {
                            "$parentTitle • $subName"
                        } else {
                            parentTitle
                        }

                        val rawType = subObj.optString("type", subObj.optString("streamType", itemObj.optString("type", itemObj.optString("streamType", "")))).trim().uppercase()
                        val resolvedStreamType = if (rawType == "DASH" || rawType == "MPD") "MPD" else if (rawType == "HLS" || rawType == "M3U8") "M3U8" else ExoPlayerHelper.detectStreamType(parsedPipe.cleanUrl)

                        val cleanTitle = cleanText(titleLabel).ifBlank { "Live Stream" }
                        val cleanCat = cleanText(subCat).ifBlank { cleanText(parentCat).ifBlank { defaultCategory } }
                        val streamUrlClean = parsedPipe.cleanUrl.trim()

                        if (streamUrlClean.isNotBlank() && !isAdultContent(cleanCat, cleanTitle)) {
                            items.add(
                                ParsedChannelItem(
                                    title = cleanTitle,
                                    streamUrl = streamUrlClean,
                                    streamType = resolvedStreamType,
                                    logo = subLogo,
                                    category = cleanCat,
                                    quality = subObj.optString("quality", "1080p HD"),
                                    headers = parsedPipe.headers,
                                    drm = parsedPipe.drm
                                )
                            )
                        }
                    }
                } else {
                    // Flat item (supports standard URLs + Willow Cricket stream_url_alpha / stream_url_beta / stream_url)
                    val flatCandidates = mutableListOf<Pair<String, String>>()
                    val rawUrl = itemObj.optString("playlist_url",
                        itemObj.optString("streamUrl", 
                        itemObj.optString("url", 
                        itemObj.optString("stream", 
                        itemObj.optString("link", 
                        itemObj.optString("src", 
                        itemObj.optString("file", "")))))))
                    if (rawUrl.isNotBlank() && rawUrl.startsWith("http", ignoreCase = true)) {
                        flatCandidates.add(Pair(parentTitle, rawUrl))
                    }

                    val alpha = itemObj.optString("stream_url_alpha", "").trim()
                    if (alpha.isNotBlank() && alpha.startsWith("http", ignoreCase = true)) {
                        flatCandidates.add(Pair("$parentTitle • Server 1 (Alpha)", alpha))
                    }
                    val beta = itemObj.optString("stream_url_beta", "").trim()
                    if (beta.isNotBlank() && beta.startsWith("http", ignoreCase = true)) {
                        flatCandidates.add(Pair("$parentTitle • Server 2 (Beta)", beta))
                    }
                    val streamDirect = itemObj.optString("stream_url", "").trim()
                    if (streamDirect.isNotBlank() && streamDirect.startsWith("http", ignoreCase = true) && streamDirect != rawUrl) {
                        flatCandidates.add(Pair("$parentTitle • Server HD", streamDirect))
                    }
                    val matchUrl = itemObj.optString("match_url", "").trim()
                    if (matchUrl.isNotBlank() && matchUrl.startsWith("http", ignoreCase = true) && (matchUrl.contains(".m3u8") || matchUrl.contains(".mpd"))) {
                        flatCandidates.add(Pair("$parentTitle • Official Stream", matchUrl))
                    }

                    for ((chanTitle, candidateUrl) in flatCandidates) {
                        val drmObj = itemObj.optJSONObject("drm")
                        var kid = (drmObj?.optString("keyId", drmObj.optString("kid", "")) ?: "")
                            .ifBlank { itemObj.optString("keyId", itemObj.optString("kid", "")) }
                            .let { if (it.equals("null", ignoreCase = true)) "" else it.trim() }
                        var key = (drmObj?.optString("key", drmObj.optString("k", "")) ?: "")
                            .ifBlank { itemObj.optString("key", itemObj.optString("k", "")) }
                            .let { if (it.equals("null", ignoreCase = true)) "" else it.trim() }
                        var licUrl = (drmObj?.optString("licenseUrl", drmObj.optString("license_url", "")) ?: "")
                            .ifBlank { itemObj.optString("licenseUrl", itemObj.optString("license_url", "")) }
                            .let { if (it.equals("null", ignoreCase = true)) "" else it.trim() }
                        val rawDrmKey = itemObj.optString("drm_key", "").trim()
                        if (kid.isBlank() && key.isBlank() && rawDrmKey.isNotBlank()) {
                            if (rawDrmKey.contains(":")) {
                                val parts = rawDrmKey.split(":")
                                kid = parts.getOrNull(0)?.trim() ?: ""
                                key = parts.getOrNull(1)?.trim() ?: ""
                            } else if (rawDrmKey.startsWith("http://") || rawDrmKey.startsWith("https://")) {
                                licUrl = rawDrmKey
                            } else if (rawDrmKey.length == 32) {
                                key = rawDrmKey
                            }
                        }

                        val rawScheme = (drmObj?.optString("scheme", drmObj.optString("type", "")) ?: "")
                            .ifBlank { itemObj.optString("scheme", itemObj.optString("type", "")) }
                        val scheme = if (rawScheme.isNotBlank()) {
                            if (rawScheme.contains("widevine", ignoreCase = true)) "widevine" else "clearkey"
                        } else if (licUrl.isNotBlank()) "widevine" else "clearkey"

                        val drm = if (kid.isNotBlank() || key.isNotBlank() || licUrl.isNotBlank()) {
                            DrmConfig(enabled = true, scheme = scheme, keyId = kid, key = key, licenseUrl = licUrl.ifBlank { null })
                        } else {
                            DrmConfig(enabled = false)
                        }

                        val headersMap = mutableMapOf<String, String>()
                        val cookie = itemObj.optString("cookie", "")
                        if (cookie.isNotBlank()) headersMap["Cookie"] = cookie
                        val userAgent = itemObj.optString("userAgent", itemObj.optString("user-agent", ""))
                        if (userAgent.isNotBlank()) headersMap["User-Agent"] = userAgent
                        val referer = itemObj.optString("referer", itemObj.optString("referrer", ""))
                        if (referer.isNotBlank()) headersMap["Referer"] = referer
                        val origin = itemObj.optString("origin", "")
                        if (origin.isNotBlank()) headersMap["Origin"] = origin
                        val headersObj = itemObj.optJSONObject("headers")
                        if (headersObj != null) {
                            val it = headersObj.keys()
                            while (it.hasNext()) {
                                val hk = it.next()
                                headersMap[hk] = headersObj.optString(hk)
                            }
                        }

                        val parsedPipe = ExoPlayerHelper.parsePipedUrl(candidateUrl, headersMap, drm)

                        val rawType = itemObj.optString("type", itemObj.optString("streamType", "")).trim().uppercase()
                        val resolvedStreamType = if (rawType == "DASH" || rawType == "MPD") "MPD" else if (rawType == "HLS" || rawType == "M3U8") "M3U8" else ExoPlayerHelper.detectStreamType(parsedPipe.cleanUrl)

                        val cleanTitle = cleanText(chanTitle).ifBlank { "Live Stream" }
                        val cleanCat = cleanText(parentCat).ifBlank { defaultCategory }
                        val streamUrlClean = parsedPipe.cleanUrl.trim()

                        if (streamUrlClean.isNotBlank() && !isAdultContent(cleanCat, cleanTitle)) {
                            items.add(
                                ParsedChannelItem(
                                    title = cleanTitle,
                                    streamUrl = streamUrlClean,
                                    streamType = resolvedStreamType,
                                    logo = parentPoster,
                                    category = cleanCat,
                                    quality = itemObj.optString("quality", "1080p HD"),
                                    headers = parsedPipe.headers,
                                    drm = parsedPipe.drm
                                )
                            )
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        return items
    }

    fun toLiveStreamEvent(item: ParsedChannelItem): LiveStreamEvent {
        val eventId = "custom_event_" + System.currentTimeMillis() + "_" + (100..999).random()
        return LiveStreamEvent(
            id = eventId,
            title = item.title,
            category = item.category,
            status = "LIVE",
            format = "T20",
            bannerUrl = item.logo,
            description = "Custom stream • ${item.category}",
            isPinned = true,
            team1 = TeamInfo(name = item.title.split(" vs ").firstOrNull() ?: item.title, flag = "📺", score = ""),
            team2 = TeamInfo(name = item.title.split(" vs ").getOrElse(1) { "HD Stream" }, flag = "🔴", score = ""),
            totalStreams = 1,
            streams = listOf(
                StreamSource(
                    id = "str_" + System.currentTimeMillis(),
                    title = item.title,
                    streamType = item.streamType,
                    streamUrl = item.streamUrl,
                    quality = item.quality,
                    headers = item.headers,
                    drm = item.drm
                )
            )
        )
    }

    fun resolveSonyLogo(title: String): String {
        val t = title.lowercase()
        return when {
            t.contains("ten 1") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Sports_Ten_1.png"
            t.contains("ten 2") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Sports_Ten_2.png"
            t.contains("ten 3") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Sports_Ten_3.png"
            t.contains("ten 4") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Sports_Ten_4.png"
            t.contains("ten 5") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Sports_Ten_5.png"
            t.contains("six") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Six_HD.png"
            t.contains("max hd") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/SonyMAX.png"
            t.contains("max 2") || t.contains("max2") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/SonyMAX2.png"
            t.contains("max") -> "https://jiotvimages.cdn.jio.com/dare_images/images/Sony_Max_SD.png"
            t.contains("sab") -> "https://jiotvimages.cdn.jio.com/dare_images/images/Sony_SAB_HD.png"
            t.contains("pal") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/SonyPAL.png"
            t.contains("marathi") -> "https://jiotvimages.cdn.jio.com/dare_images/images/SonyMarathi.png"
            t.contains("aath") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/SonyAATH.png"
            t.contains("yay") -> "https://jiotvimages.cdn.jio.com/dare_images/images/Sony_Yay_Hindi.png"
            t.contains("wah") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/SonyWAH.png"
            t.contains("pix") -> "https://jiotvimages.cdn.jio.com/dare_images/images/SonyPIX.png"
            t.contains("bbc earth") || t.contains("earth") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/SonyBBCEarthHin.png"
            t.contains("set hd") || t.contains("set") -> "https://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_HD.png"
            else -> "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/logos/sonyliv.png"
        }
    }
}
