package com.hdstream.live.util

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build

object DeviceUtils {

    @Volatile
    private var cachedIsTv: Boolean? = null

    /**
     * Mobile Hardware Priority Check (Anti-Jugad / Anti-TV-Format):
     * Checks if device possesses physical mobile/touchscreen hardware:
     * - Touchscreen (FEATURE_TOUCHSCREEN = "android.hardware.touchscreen")
     * - Telephony/Cellular (FEATURE_TELEPHONY = "android.hardware.telephony")
     * If true, device is strictly MOBILE regardless of any TV UI mode tricks or emulated flags.
     */
    fun hasMobileHardware(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            val hasTouch = pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
            val hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)
            hasTouch || hasTelephony
        } catch (_: Exception) {
            true // default to mobile safety
        }
    }

    /**
     * Strict Genuine TV Check:
     * Device is ONLY recognized as a TV if:
     * 1. It does NOT possess mobile hardware (NO touchscreen).
     * 2. AND it matches genuine TV platform signals:
     *    - UiModeManager currentModeType == UI_MODE_TYPE_TELEVISION
     *    - Has system feature "android.software.leanback" or PackageManager.FEATURE_LEANBACK
     *    - Has system feature "android.hardware.type.television"
     *    - Has Fire TV hardware feature "amazon.hardware.fire_tv" or Amazon AFT model
     *
     * Genuine TV devices bypass all web ads / Adsterra links / 12-hour support gates
     * because TVs lack standard mobile browsers and Custom Tabs.
     */
    fun isGenuineTv(context: Context): Boolean {
        cachedIsTv?.let { return it }

        // 1. Mobile Hardware Priority: Touchscreen or phone hardware immediately marks it as MOBILE
        if (hasMobileHardware(context)) {
            cachedIsTv = false
            return false
        }

        // 2. Strict Genuine TV verification (Evaluated ONLY when device has NO touchscreen)
        val isTv = try {
            val pm = context.packageManager

            // Check UiModeManager for Configuration.UI_MODE_TYPE_TELEVISION
            val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
            val isUiTv = uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

            // Check Leanback
            val hasLeanback = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
                    pm.hasSystemFeature("android.software.leanback") ||
                    pm.hasSystemFeature("android.software.leanback_only")

            // Check TV hardware feature
            val hasTvHardware = pm.hasSystemFeature("android.hardware.type.television")

            // Check Fire TV hardware & identifiers
            val hasFireTv = pm.hasSystemFeature("amazon.hardware.fire_tv") ||
                    (Build.MANUFACTURER.contains("Amazon", ignoreCase = true) && Build.MODEL.contains("AFT", ignoreCase = true))

            // Dedicated set-top box chipsets (ONLY applicable when hasTouch is false)
            val tvChipsets = listOf("amlogic", "rockchip", "allwinner", "realtek", "mstar", "shield", "bravia", "chromecast")
            val combinedInfo = "${Build.HARDWARE} ${Build.DEVICE} ${Build.PRODUCT} ${Build.MODEL}".lowercase()
            val hasTvChipset = tvChipsets.any { combinedInfo.contains(it) }

            isUiTv || hasLeanback || hasTvHardware || hasFireTv || hasTvChipset
        } catch (_: Exception) {
            false
        }

        cachedIsTv = isTv
        return isTv
    }

    /**
     * Backward-compatible alias for UI components and player orientation.
     */
    fun isTv(context: Context): Boolean = isGenuineTv(context)
}
