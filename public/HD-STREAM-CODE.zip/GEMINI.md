# STRICT AGENT RULES FOR HD-STREAM-APP

1. **Single-Scope Edits Only (No Bulk Overwrites):**
   - When asked to fix a specific channel or a specific category (e.g., "JD TV 1"), ONLY inspect and modify entries matching that exact channel or category.
   - NEVER scan, re-index, delete, or overwrite other working channels in `tv_channels.json`, `data.json`, or `live_matches.json`.

2. **No Auto-Replacement via Python Scripts:**
   - NEVER run bulk Python scripts (`test_parse_m3u.py`, `test_match_all.py`, etc.) to test stream URLs from Windows and auto-replace existing channel links or keys. Desktop HTTP checks fail on mobile-specific headers/tokens and break working channels.

3. **Do Not Touch Player or DRM Kotlin Code:**
   - NEVER modify `ExoPlayerHelper.kt`, `SecurityUtils.kt`, or ClearKey DRM functions (`buildClearKeyJson`, `normalizeClearKeyResponse`) when fixing a channel link or playlist issue, unless explicitly instructed to edit Kotlin code.

4. **Dry-Run & Approval Before Saving:**
   - Before writing changes to any JSON file, list the exact channel names and fields you plan to modify, and wait for explicit user confirmation.

5. **Mandatory Git Backup First:**
   - Before making any edit, create a `git commit` backup of the current working state so changes can be reverted cleanly if needed.

