package com.hdstream.live.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hdstream.live.model.*
import com.hdstream.live.player.ExoPlayerHelper
import com.hdstream.live.player.M3uParser
import com.hdstream.live.player.ParsedChannelItem
import com.hdstream.live.util.AdGateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class StreamRepository(private val context: Context? = null) {

    private val okHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    var cloudApiBaseUrl: String = "https://hd-stream-backend.onrender.com"

    private val _feedState = MutableStateFlow<MobileFeedResponse?>(null)
    val feedState: StateFlow<MobileFeedResponse?> = _feedState.asStateFlow()

    private val _adConfigState = MutableStateFlow<AdConfig>(
        context?.let { AdGateManager.getCachedAdConfig(it) } ?: AdConfig()
    )
    val adConfigState: StateFlow<AdConfig> = _adConfigState.asStateFlow()

    fun updateAdConfigFromJson(jsonStr: String?) {
        if (jsonStr.isNullOrBlank()) return
        try {
            val trimmed = jsonStr.trim()
            var foundConfig: AdConfig? = null
            val defaultFallback = AdConfig()
            if (trimmed.startsWith("{")) {
                val obj = org.json.JSONObject(trimmed)
                if (obj.has("adConfig")) {
                    val adObj = obj.getJSONObject("adConfig")
                    foundConfig = AdConfig(
                        enabled = adObj.optBoolean("enabled", defaultFallback.enabled),
                        adUrl = adObj.optString("adUrl", defaultFallback.adUrl).trim().ifBlank { defaultFallback.adUrl },
                        waitSeconds = adObj.optInt("waitSeconds", defaultFallback.waitSeconds),
                        unlockHours = adObj.optInt("unlockHours", defaultFallback.unlockHours),
                        bannerImageUrl = adObj.optString("bannerImageUrl", "").trim(),
                        bannerClickUrl = adObj.optString("bannerClickUrl", "").trim()
                    )
                }
            } else if (trimmed.startsWith("[")) {
                val arr = org.json.JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    if (item.has("adConfig")) {
                        val adObj = item.getJSONObject("adConfig")
                        foundConfig = AdConfig(
                            enabled = adObj.optBoolean("enabled", defaultFallback.enabled),
                            adUrl = adObj.optString("adUrl", defaultFallback.adUrl).trim().ifBlank { defaultFallback.adUrl },
                            waitSeconds = adObj.optInt("waitSeconds", defaultFallback.waitSeconds),
                            unlockHours = adObj.optInt("unlockHours", defaultFallback.unlockHours),
                            bannerImageUrl = adObj.optString("bannerImageUrl", "").trim(),
                            bannerClickUrl = adObj.optString("bannerClickUrl", "").trim()
                        )
                        break
                    }
                }
            }
            if (foundConfig != null) {
                _adConfigState.value = foundConfig
                if (context != null) {
                    AdGateManager.saveCachedAdConfig(context, foundConfig)
                }
            }
        } catch (_: Exception) {}
    }

    private val gson = Gson()
    private val PREFS_NAME = "hd_stream_feed_cache"
    private val KEY_CACHED_FEED = "cached_feed_json"

    fun registerDeviceInstall(ctx: Context) {
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = ctx.getSharedPreferences("hd_stream_install", Context.MODE_PRIVATE)
                var deviceId = prefs.getString("unique_device_id", "") ?: ""
                if (deviceId.isBlank()) {
                    deviceId = java.util.UUID.randomUUID().toString().replace("-", "").take(16)
                    prefs.edit().putString("unique_device_id", deviceId).apply()
                }
                val model = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}".trim()
                val osVer = "Android ${android.os.Build.VERSION.RELEASE}"

                val jsonPayload = """{"deviceId":"$deviceId","deviceModel":"$model","osVersion":"$osVer"}"""
                val endpoints = listOf(
                    "${cloudApiBaseUrl.trimEnd('/')}/api/devices/register",
                    "https://hd-stream-backend.onrender.com/api/devices/register"
                ).distinct()

                for (ep in endpoints) {
                    try {
                        val url = java.net.URL(ep)
                        val conn = url.openConnection() as java.net.HttpURLConnection
                        conn.requestMethod = "POST"
                        conn.setRequestProperty("Content-Type", "application/json")
                        conn.connectTimeout = 3000
                        conn.readTimeout = 3000
                        conn.doOutput = true
                        conn.outputStream.use { os ->
                            os.write(jsonPayload.toByteArray(Charsets.UTF_8))
                        }
                        if (conn.responseCode in 200..299) break
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
        }
    }

    // Remote GitHub Raw & CDN Endpoints (Zero APK Update Architecture)
    private val githubLiveMatchesUrls = listOf(
        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/live_matches.json",
        "https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/data/live_matches.json"
    )

    private val githubCategoriesUrls = listOf(
        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/categories.json",
        "https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/data/categories.json"
    )

    init {
        // Fast instant boot from SharedPreferences local cache
        loadFromLocalCache()
        if (_feedState.value == null) {
            _feedState.value = getOfficialDefaultFeed()
        }
    }

    private fun loadFromLocalCache() {
        if (context == null) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(KEY_CACHED_FEED, null)
            if (!json.isNullOrBlank()) {
                val cached = gson.fromJson(json, MobileFeedResponse::class.java)
                if (cached != null) {
                    _feedState.value = cached
                    if (cached.adConfig.enabled) {
                        _adConfigState.value = cached.adConfig
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun saveToLocalCache(feed: MobileFeedResponse) {
        if (context == null) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = gson.toJson(feed)
            prefs.edit().putString(KEY_CACHED_FEED, json).apply()
            if (feed.adConfig.enabled) {
                AdGateManager.saveCachedAdConfig(context, feed.adConfig)
            }
        } catch (_: Exception) {}
    }

    private fun httpGet(urlStr: String, timeoutMs: Int = 4500): String? {
        var curUrl = urlStr
        var redirects = 0
        while (redirects < 5) {
            try {
                val url = URL(curUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = timeoutMs
                conn.readTimeout = timeoutMs
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; HDStream/3.2.2)")
                conn.setRequestProperty("Accept", "*/*")
                conn.setRequestProperty("Cache-Control", "no-cache")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        curUrl = loc
                        redirects++
                        continue
                    }
                }
                if (code in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val content = reader.readText()
                    reader.close()
                    return content
                }
                return null
            } catch (_: Exception) {
                return null
            }
        }
        return null
    }

    companion object {
        fun getTeamFlagUrl(teamName: String): String {
            val t = teamName.lowercase().trim()
            return when {
                t.contains("india") || t == "ind" -> "https://flagcdn.com/w160/in.png"
                t.contains("new zealand") || t.contains("zealand") || t == "nz" -> "https://flagcdn.com/w160/nz.png"
                t.contains("australia") || t == "aus" -> "https://flagcdn.com/w160/au.png"
                t.contains("england") || t == "eng" -> "https://flagcdn.com/w160/gb-eng.png"
                t.contains("pakistan") || t == "pak" -> "https://flagcdn.com/w160/pk.png"
                t.contains("south africa") || t == "sa" -> "https://flagcdn.com/w160/za.png"
                t.contains("bangladesh") || t == "ban" || t == "bd" -> "https://flagcdn.com/w160/bd.png"
                t.contains("sri lanka") || t == "sl" || t == "lk" -> "https://flagcdn.com/w160/lk.png"
                t.contains("afghanistan") || t == "afg" -> "https://flagcdn.com/w160/af.png"
                t.contains("nepal") || t == "nep" || t == "npl" -> "https://flagcdn.com/w160/np.png"
                t.contains("west indies") || t == "wi" -> "https://flagcdn.com/w160/jm.png"
                t.contains("zimbabwe") || t == "zim" -> "https://flagcdn.com/w160/zw.png"
                t.contains("ireland") || t == "ire" -> "https://flagcdn.com/w160/ie.png"
                t.contains("scotland") || t == "sco" -> "https://flagcdn.com/w160/gb-sct.png"
                t.contains("netherlands") || t == "ned" -> "https://flagcdn.com/w160/nl.png"
                t.contains("usa") || t.contains("united states") -> "https://flagcdn.com/w160/us.png"
                t.contains("canada") || t == "can" -> "https://flagcdn.com/w160/ca.png"
                else -> ""
            }
        }
    }

    fun isCricketMatch(category: String, title: String, league: String): Boolean {
        val cat = category.trim().lowercase()
        val fullText = "$cat ${title.lowercase()} ${league.lowercase()}"
        if (cat == "cricket") return true
        val cricketKeywords = listOf(
            "cricket", "t20", "odi", "test match", "test series", "ipl",
            "bbl", "psl", "cpl", "lpl", "npl", "bpl", "abu dhabi",
            "world test championship", "u19", "big bash", "ranji",
            "bcci", "icc", "stump", "wicket", "overs", "bangladesh",
            "west indies", "pakistan", "sri lanka", "zimbabwe", "afghanistan"
        )
        return cricketKeywords.any { fullText.contains(it) }
    }

    private fun mapSportsDataMatch(m: org.json.JSONObject, index: Int): LiveStreamEvent? {
        val info = m.optJSONObject("eventInfo")
        val title = (m.optString("event_name", "").ifBlank {
            if (info != null) "${info.optString("teamA")} vs ${info.optString("teamB")}" else "Sports Match ${index + 1}"
        }).trim()
        val status = m.optString("status", "LIVE").uppercase()
        val category = m.optString("Category", "Football").trim()
        val tournament = (info?.optString("eventName") ?: category).trim()
        val team1Name = (info?.optString("teamA") ?: title.split(Regex(" vs ", RegexOption.IGNORE_CASE)).getOrNull(0) ?: "Team 1").trim()
        val team2Name = (info?.optString("teamB") ?: title.split(Regex(" vs ", RegexOption.IGNORE_CASE)).getOrNull(1) ?: "Team 2").trim()

        val streamsArr = m.optJSONArray("streams") ?: org.json.JSONArray()
        val streams = mutableListOf<StreamSource>()
        for (sIdx in 0 until streamsArr.length()) {
            val s = streamsArr.getJSONObject(sIdx)
            val url = (s.optString("stream_url", s.optString("streamUrl", s.optString("url", "")))).trim()
            if (url.isNotBlank() && url.startsWith("http")) {
                // Filter out known dead/offline IP servers
                val isDeadHost = url.contains("chatgpt.hereisman.net", ignoreCase = true) ||
                        url.contains("193.47.62.", ignoreCase = true) ||
                        url.contains("fromthyheart.site", ignoreCase = true) ||
                        url.contains("demonpvp.fun", ignoreCase = true)
                if (isDeadHost) continue

                val isMpd = url.contains(".mpd")
                val streamType = if (isMpd) "MPD" else "M3U8"
                val referer = s.optString("referer", s.optString("referrer", "")).trim()
                val kid = s.optString("kid", s.optString("key_id", "")).trim()
                val key = s.optString("key", "").trim()
                val hasDrm = kid.isNotBlank() && key.isNotBlank()
                val drm = if (hasDrm) {
                    DrmConfig(
                        enabled = true,
                        scheme = "clearkey",
                        keyId = kid,
                        key = key
                    )
                } else DrmConfig(enabled = false)

                val ua = s.optString("user_agent", "").trim().ifBlank {
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
                }
                val headers = mutableMapOf("User-Agent" to ua)
                if (referer.isNotBlank()) {
                    headers["Referer"] = referer
                    try {
                        val uri = java.net.URI(referer)
                        headers["Origin"] = "${uri.scheme}://${uri.host}"
                    } catch (_: Exception) {}
                }
                streams.add(
                    StreamSource(
                        id = "sports_${index}_$sIdx",
                        title = s.optString("channel_name", "Server ${sIdx + 1} HD"),
                        streamType = streamType,
                        streamUrl = url,
                        quality = "1080p HD",
                        headers = headers,
                        drm = drm
                    )
                )
            }
        }
        if (streams.isEmpty()) return null

        // Prioritize working streams (ClearKey DRM & verified high-speed CDNs first)
        streams.sortByDescending { stream ->
            var score = 0
            if (stream.drm.enabled) score += 60
            if (stream.streamUrl.contains("aiv-cdn.net") || stream.streamUrl.contains("pv-cdn.net")) score += 40
            if (stream.streamUrl.contains("slivcdn.com") || stream.streamUrl.contains("akamaized.net")) score += 30
            if (stream.streamType == "MPD") score += 20
            score
        }

        val flagA = info?.optString("teamAFlag") ?: "⚽"
        val flagB = info?.optString("teamBFlag") ?: "⚽"
        return LiveStreamEvent(
            id = "sports_${index}_${title.hashCode()}",
            title = title,
            category = category,
            status = status,
            format = tournament,
            startTime = info?.optString("startTime") ?: "LIVE NOW",
            bannerUrl = info?.optString("event_logo") ?: "",
            description = "$tournament: $title",
            isPinned = (status == "LIVE"),
            team1 = TeamInfo(name = team1Name, shortName = team1Name.take(4).uppercase().trim(), flag = flagA, logo = flagA),
            team2 = TeamInfo(name = team2Name, shortName = team2Name.take(4).uppercase().trim(), flag = flagB, logo = flagB),
            totalStreams = streams.size,
            streams = streams
        )
    }

    data class ParsedLiveFeedData(
        val liveEvents: List<LiveStreamEvent> = emptyList(),
        val upcomingEvents: List<LiveStreamEvent> = emptyList(),
        val finishedEvents: List<LiveStreamEvent> = emptyList(),
        val announcement: String? = null,
        val announcementEnabled: Boolean? = null
    )

    fun parseUniversalLiveFeed(rawJson: String?): ParsedLiveFeedData {
        if (rawJson.isNullOrBlank()) return ParsedLiveFeedData()
        val trimmed = rawJson.trim()
        try {
            if (trimmed.startsWith("[")) {
                // Root JSON Array (Format 2: Live Event Array)
                val jsonArr = org.json.JSONArray(trimmed)
                val liveList = mutableListOf<LiveStreamEvent>()
                val upList = mutableListOf<LiveStreamEvent>()
                val finList = mutableListOf<LiveStreamEvent>()

                for (i in 0 until jsonArr.length()) {
                    val obj = jsonArr.optJSONObject(i) ?: continue
                    val matchItem = try {
                        gson.fromJson(obj.toString(), GDriveMatchItem::class.java)
                    } catch (_: Exception) { null } ?: continue

                    val rawStatus = (matchItem.status ?: "LIVE").trim().uppercase()
                    val event = mapMatchItem(matchItem, rawStatus, i)
                    when {
                        rawStatus.contains("UPCOMING") || rawStatus.contains("FUTURE") -> upList.add(event.copy(status = "UPCOMING"))
                        rawStatus.contains("FINISH") || rawStatus.contains("ENDED") || rawStatus.contains("COMPLETE") -> finList.add(event.copy(status = "FINISHED"))
                        else -> liveList.add(event.copy(status = "LIVE"))
                    }
                }
                return ParsedLiveFeedData(
                    liveEvents = liveList,
                    upcomingEvents = upList,
                    finishedEvents = finList
                )
            } else if (trimmed.startsWith("{")) {
                // Root JSON Object (Format 1: Willow Cricket, GDrive live_matches, matches object, etc.)
                val rootObj = org.json.JSONObject(trimmed)
                val announcement = rootObj.optString("announcement", "").ifBlank { null }
                val announcementEnabled = when {
                    rootObj.has("announcement_enabled") -> rootObj.optBoolean("announcement_enabled")
                    rootObj.has("announcementEnabled") -> rootObj.optBoolean("announcementEnabled")
                    else -> null
                }

                // Check if it has separate status arrays
                val hasSplitArrays = rootObj.has("live_matches") || rootObj.has("liveMatches") ||
                        rootObj.has("upcoming_matches") || rootObj.has("upcomingMatches") ||
                        rootObj.has("finished_matches") || rootObj.has("finishedMatches")

                if (hasSplitArrays) {
                    val feedResp = try { gson.fromJson(trimmed, GDriveLiveFeedResponse::class.java) } catch (_: Exception) { null }
                    val liveList = feedResp?.liveMatches?.mapIndexed { idx, it -> mapMatchItem(it, "LIVE", idx) } ?: emptyList()
                    val upList = feedResp?.upcomingMatches?.mapIndexed { idx, it -> mapMatchItem(it, "UPCOMING", idx) } ?: emptyList()
                    val finList = feedResp?.finishedMatches?.mapIndexed { idx, it -> mapMatchItem(it, "FINISHED", idx) } ?: emptyList()
                    return ParsedLiveFeedData(
                        liveEvents = liveList,
                        upcomingEvents = upList,
                        finishedEvents = finList,
                        announcement = announcement,
                        announcementEnabled = announcementEnabled
                    )
                }

                // Check for unified array: "Matches" (Willow!), "matches", "data", "items", "events", "results", etc.
                val matchesArr = rootObj.optJSONArray("Matches")
                    ?: rootObj.optJSONArray("matches")
                    ?: rootObj.optJSONArray("data")
                    ?: rootObj.optJSONArray("items")
                    ?: rootObj.optJSONArray("events")
                    ?: rootObj.optJSONArray("results")
                    ?: rootObj.optJSONArray("live_events")
                    ?: rootObj.optJSONArray("liveEvents")

                val liveList = mutableListOf<LiveStreamEvent>()
                val upList = mutableListOf<LiveStreamEvent>()
                val finList = mutableListOf<LiveStreamEvent>()

                if (matchesArr != null) {
                    for (i in 0 until matchesArr.length()) {
                        val obj = matchesArr.optJSONObject(i) ?: continue
                        val matchItem = try {
                            gson.fromJson(obj.toString(), GDriveMatchItem::class.java)
                        } catch (_: Exception) { null } ?: continue

                        val rawStatus = (matchItem.status ?: "LIVE").trim().uppercase()
                        val event = mapMatchItem(matchItem, rawStatus, i)
                        when {
                            rawStatus.contains("UPCOMING") || rawStatus.contains("FUTURE") -> upList.add(event.copy(status = "UPCOMING"))
                            rawStatus.contains("FINISH") || rawStatus.contains("ENDED") || rawStatus.contains("COMPLETE") -> finList.add(event.copy(status = "FINISHED"))
                            else -> liveList.add(event.copy(status = "LIVE"))
                        }
                    }
                }

                return ParsedLiveFeedData(
                    liveEvents = liveList,
                    upcomingEvents = upList,
                    finishedEvents = finList,
                    announcement = announcement,
                    announcementEnabled = announcementEnabled
                )
            }
        } catch (e: Exception) {
            android.util.Log.e("StreamRepository", "Failed to parse live feed: ${e.message}", e)
        }
        return ParsedLiveFeedData()
    }

    private fun mapMatchItem(m: GDriveMatchItem, defaultStatus: String, index: Int): LiveStreamEvent {
        val title = (m.matchName ?: m.title ?: m.synopsis ?: "Live Match ${index + 1}").trim()
        val rawStatus = (m.status ?: defaultStatus).trim().uppercase()
        val status = when {
            rawStatus.contains("UPCOMING") || rawStatus.contains("FUTURE") -> "UPCOMING"
            rawStatus.contains("FINISH") || rawStatus.contains("ENDED") || rawStatus.contains("COMPLETE") -> "FINISHED"
            else -> "LIVE"
        }
        var team1Name = m.teamAObj?.name ?: m.team1Obj?.name ?: m.team1Name ?: ""
        var team2Name = m.teamBObj?.name ?: m.team2Obj?.name ?: m.team2Name ?: ""
        if (team1Name.isBlank() && team2Name.isBlank()) {
            if (title.contains(" vs ", ignoreCase = true)) {
                val parts = title.split(Regex(" vs ", RegexOption.IGNORE_CASE))
                team1Name = parts.getOrNull(0)?.trim() ?: "Team 1"
                team2Name = parts.getOrNull(1)?.trim() ?: "Team 2"
            } else if (title.contains(" - ")) {
                val parts = title.split(" - ")
                team1Name = parts.getOrNull(0)?.trim() ?: "Team 1"
                team2Name = parts.getOrNull(1)?.trim() ?: "Team 2"
            } else {
                team1Name = title
                team2Name = "Opponent"
            }
        }
        if (team1Name.isBlank()) team1Name = "Team 1"
        if (team2Name.isBlank()) team2Name = "Team 2"

        // Collect all stream candidates (supports nested arrays and Willow flat stream fields)
        val rawStreamCandidates = (m.streams ?: m.channels ?: m.servers ?: m.links ?: emptyList()).toMutableList()

        if (!m.streamUrlAlpha.isNullOrBlank() && m.streamUrlAlpha.startsWith("http", ignoreCase = true)) {
            rawStreamCandidates.add(GDriveStreamItem(title = "Server 1 (Alpha) HD", url = m.streamUrlAlpha, drmKey = m.drmKey))
        }
        if (!m.streamUrlBeta.isNullOrBlank() && m.streamUrlBeta.startsWith("http", ignoreCase = true)) {
            rawStreamCandidates.add(GDriveStreamItem(title = "Server 2 (Beta) HD", url = m.streamUrlBeta, drmKey = m.drmKey))
        }
        if (!m.streamUrl.isNullOrBlank() && m.streamUrl.startsWith("http", ignoreCase = true)) {
            rawStreamCandidates.add(GDriveStreamItem(title = "Server HD", url = m.streamUrl, drmKey = m.drmKey))
        }
        if (!m.matchUrl.isNullOrBlank() && m.matchUrl.startsWith("http", ignoreCase = true) && (m.matchUrl.contains(".m3u8") || m.matchUrl.contains(".mpd"))) {
            rawStreamCandidates.add(GDriveStreamItem(title = "Official Stream HD", url = m.matchUrl, drmKey = m.drmKey))
        }

        val streams = rawStreamCandidates.mapIndexedNotNull { sIdx, s ->
            val rawUrl = (s.url ?: s.streamUrlSnake ?: s.streamUrlCamel ?: s.link ?: "").trim()
            if (!rawUrl.startsWith("http")) return@mapIndexedNotNull null

            val rawType = (s.type ?: s.streamType ?: "").trim().uppercase()
            val isMpd = rawType == "DASH" || rawType == "MPD" || rawUrl.contains(".mpd", ignoreCase = true)
            val isHls = rawType == "HLS" || rawType == "M3U8" || rawUrl.contains(".m3u8", ignoreCase = true)
            val streamType = if (isMpd) "MPD" else if (isHls) "M3U8" else ExoPlayerHelper.detectStreamType(rawUrl)

            // DRM Resolution (ClearKey or Widevine)
            var drmConfig = s.drm ?: DrmConfig()
            if (!drmConfig.enabled) {
                val rawDrmKey = (s.drmKey ?: m.drmKey ?: "").trim()
                val kid = (s.kid ?: s.keyId ?: "").trim()
                val key = (s.key ?: "").trim()

                if (kid.isNotBlank() && key.isNotBlank()) {
                    drmConfig = DrmConfig(enabled = true, scheme = "clearkey", keyId = kid, key = key)
                } else if (rawDrmKey.isNotBlank()) {
                    if (rawDrmKey.contains(":")) {
                        val parts = rawDrmKey.split(":")
                        val pKid = parts.getOrNull(0)?.trim() ?: ""
                        val pKey = parts.getOrNull(1)?.trim() ?: ""
                        drmConfig = DrmConfig(enabled = true, scheme = "clearkey", keyId = pKid, key = pKey)
                    } else if (rawDrmKey.startsWith("http://", ignoreCase = true) || rawDrmKey.startsWith("https://", ignoreCase = true)) {
                        val isWidevine = rawType.contains("WIDEVINE") || rawDrmKey.contains("widevine")
                        drmConfig = DrmConfig(enabled = true, scheme = if (isWidevine) "widevine" else "clearkey", licenseUrl = rawDrmKey)
                    } else if (rawDrmKey.length == 32) {
                        drmConfig = DrmConfig(enabled = true, scheme = "clearkey", key = rawDrmKey)
                    }
                }
            }

            // Headers
            val headersMap = mutableMapOf<String, String>()
            val ua = (s.userAgent ?: s.headers?.get("User-Agent") ?: "").trim().ifBlank {
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
            }
            headersMap["User-Agent"] = ua
            val ref = (s.referer ?: s.headers?.get("Referer") ?: "").trim()
            if (ref.isNotBlank()) {
                headersMap["Referer"] = ref
                try {
                    val uri = java.net.URI(ref)
                    headersMap["Origin"] = "${uri.scheme}://${uri.host}"
                } catch (_: Exception) {}
            }
            val origin = (s.origin ?: s.headers?.get("Origin") ?: "").trim()
            if (origin.isNotBlank()) headersMap["Origin"] = origin
            val cookie = (s.cookie ?: s.headers?.get("Cookie") ?: "").trim()
            if (cookie.isNotBlank()) headersMap["Cookie"] = cookie
            s.headers?.forEach { (k, v) -> if (v.isNotBlank() && !headersMap.containsKey(k)) headersMap[k] = v }

            val parsedPipe = ExoPlayerHelper.parsePipedUrl(rawUrl, headersMap, drmConfig)

            StreamSource(
                id = "stream_${index}_$sIdx",
                title = s.title ?: s.name ?: s.channelName ?: s.server ?: "Server ${sIdx + 1} HD",
                streamType = streamType,
                streamUrl = parsedPipe.cleanUrl,
                quality = s.quality ?: "1080p HD",
                headers = parsedPipe.headers,
                drm = parsedPipe.drm
            )
        }

        val flag1 = getTeamFlagUrl(team1Name)
        val flag2 = getTeamFlagUrl(team2Name)
        var t1Logo = if (flag1.isNotBlank()) flag1 else (m.teamAObj?.logo ?: m.team1Obj?.logo ?: m.teamAObj?.flag ?: m.team1Obj?.flag ?: m.team1Logo ?: "")
        var t2Logo = if (flag2.isNotBlank()) flag2 else (m.teamBObj?.logo ?: m.team2Obj?.logo ?: m.teamBObj?.flag ?: m.team2Obj?.flag ?: m.team2Logo ?: "")

        if (t1Logo.isBlank() || t1Logo.contains("wikimedia", ignoreCase = true)) {
            if (flag1.isNotBlank()) t1Logo = flag1
        }
        if (t2Logo.isBlank() || t2Logo.contains("wikimedia", ignoreCase = true)) {
            if (flag2.isNotBlank()) t2Logo = flag2
        }

        val t1Score = m.teamAObj?.score ?: m.team1Obj?.score ?: ""
        val t2Score = m.teamBObj?.score ?: m.team2Obj?.score ?: ""

        val matchTime = if (!m.time.isNullOrBlank() && !m.date.isNullOrBlank()) {
            "${m.time} • ${m.date}"
        } else {
            m.time ?: m.date ?: "LIVE NOW"
        }

        val matchBanner = (m.coverImage ?: m.bannerLogo ?: m.banner ?: m.bannerUrlSnake ?: m.bannerUrlCamel ?: m.image ?: m.poster ?: "").trim()

        return LiveStreamEvent(
            id = "event_${index}_${Math.abs(title.hashCode())}",
            title = title,
            category = m.category ?: m.sport ?: "Live Cricket",
            status = status,
            startTime = matchTime,
            bannerUrl = matchBanner,
            description = m.synopsis ?: m.result ?: "",
            team1 = TeamInfo(name = team1Name, shortName = team1Name.take(4).uppercase(), logo = t1Logo, score = t1Score),
            team2 = TeamInfo(name = team2Name, shortName = team2Name.take(4).uppercase(), logo = t2Logo, score = t2Score),
            totalStreams = streams.size,
            streams = streams
        )
    }

    suspend fun fetchFromCloudBackend(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        val endpoints = listOf(
            "${cloudApiBaseUrl.trimEnd('/')}/api/feed/mobile",
            "https://hd-stream-backend.onrender.com/api/feed/mobile"
        ).distinct()

        for (endpoint in endpoints) {
            try {
                val json = httpGet(endpoint, timeoutMs = 4000)
                if (!json.isNullOrBlank()) {
                    val response = gson.fromJson(json, MobileFeedResponse::class.java)
                    if (response != null && (response.liveEvents.isNotEmpty() || response.categories.isNotEmpty())) {
                        return@withContext response
                    }
                }
            } catch (_: Exception) {}
        }
        null
    }

    suspend fun getFeed(): MobileFeedResponse = withContext(Dispatchers.IO) {
        // Step 1: Ensure initial memory state has local cache so UI is never blocked
        if (_feedState.value == null) {
            loadFromLocalCache()
        }

        // Step 2: Priority 1 -> Google Drive Direct Fetch (User Primary Live Event & Category Source)
        val driveFeed = fetchDirectFromGoogleDrive()
        if (driveFeed != null && (driveFeed.liveEvents.isNotEmpty() || driveFeed.categories.isNotEmpty())) {
            saveToLocalCache(driveFeed)
            _feedState.value = driveFeed
            return@withContext driveFeed
        }

        // Step 3: Priority 2 -> Admin Backend Cloud API (Real-time live sync for Admin Panel & JSON imports)
        val cloudFeed = fetchFromCloudBackend()
        if (cloudFeed != null && (cloudFeed.liveEvents.isNotEmpty() || cloudFeed.categories.isNotEmpty())) {
            saveToLocalCache(cloudFeed)
            _feedState.value = cloudFeed
            return@withContext cloudFeed
        }

        // Step 4: Priority 3 -> GitHub Raw / CDN Direct Fetch (Backup dynamic updates)
        val githubFeed = fetchFromGitHubRaw()
        if (githubFeed != null) {
            saveToLocalCache(githubFeed)
            _feedState.value = githubFeed
            return@withContext githubFeed
        }

        // Step 5: Priority 4 -> Return local cached state if available
        _feedState.value?.let { return@withContext it }

        // Step 6: Priority 5 -> Bundled default fallback
        val fallback = getOfficialDefaultFeed()
        _feedState.value = fallback
        fallback
    }

    suspend fun fetchFromGitHubRaw(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch Live Matches from GitHub
            var liveJson: String? = null
            for (url in githubLiveMatchesUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    liveJson = res
                    break
                }
            }

            if (liveJson.isNullOrBlank()) return@withContext null

            val parsedLiveFeed = parseUniversalLiveFeed(liveJson)

            // 2. Fetch Categories from GitHub
            var catJson: String? = null
            for (url in githubCategoriesUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    catJson = res
                    break
                }
            }

            val parsedCategories: List<FeedCategory>? = if (!catJson.isNullOrBlank()) {
                if (!catJson.isNullOrBlank()) {
                updateAdConfigFromJson(catJson)
            }

            val catType = object : TypeToken<List<FeedCategory>>() {}.type
                try { gson.fromJson(catJson, catType) } catch (_: Exception) { null }
            } else null

            val cleanCategories = parsedCategories?.filter { c ->
                !c.slug.equals("cinex-movies", ignoreCase = true) &&
                !c.name.equals("CINEX MOVIES", ignoreCase = true)
            }?.mapIndexed { idx, c ->
                val name = c.displayName
                c.copy(
                    id = if (c.id.isNotBlank()) c.id else "gcat_${idx + 1}",
                    name = name,
                    slug = if (c.slug.isNotBlank()) c.slug else name.lowercase().replace(Regex("[^a-z0-9]+"), "-"),
                    m3uLink = c.m3uLink.trim()
                )
            } ?: emptyList()

            val liveList = parsedLiveFeed.liveEvents
            val upList = parsedLiveFeed.upcomingEvents
            val finList = parsedLiveFeed.finishedEvents

            val official = getOfficialDefaultFeed()
            val announcementText = if (!parsedLiveFeed.announcement.isNullOrBlank()) parsedLiveFeed.announcement else official.appConfig.announcement
            val announcementEnabled = parsedLiveFeed.announcementEnabled ?: official.appConfig.announcementEnabled

            MobileFeedResponse(
                status = "success",
                timestamp = System.currentTimeMillis(),
                appConfig = official.appConfig.copy(
                    announcement = announcementText,
                    announcementEnabled = announcementEnabled
                ),
                categories = cleanCategories,
                liveEvents = liveList,
                upcomingEvents = upList,
                recentEvents = finList,
                vodSection = official.vodSection
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun fetchDirectFromGoogleDrive(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch Categories from Google Drive (Primary User Source)
            val driveCatUrls = listOf(
                "https://drive.google.com/uc?export=download&id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO",
                "https://docs.google.com/uc?export=download&id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO",
                "https://drive.usercontent.google.com/download?id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO&export=download"
            )
            var catJson: String? = null
            for (url in driveCatUrls) {
                try {
                    val req = Request.Builder()
                        .url(url)
                        .cacheControl(CacheControl.FORCE_NETWORK)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")
                        .header("Accept", "*/*")
                        .build()
                    val resp = okHttpClient.newCall(req).execute()
                    if (resp.isSuccessful) {
                        val body = resp.body?.string()
                        if (!body.isNullOrBlank()) {
                            catJson = body
                            break
                        }
                    }
                } catch (_: Exception) {}
                val res = if (catJson.isNullOrBlank()) httpGet(url) else null
                if (!res.isNullOrBlank()) {
                    catJson = res
                    break
                }
            }

            if (!catJson.isNullOrBlank()) {
                updateAdConfigFromJson(catJson)
            }

            val catType = object : TypeToken<List<FeedCategory>>() {}.type
            val parsedCategories: List<FeedCategory>? = if (!catJson.isNullOrBlank()) {
                try { gson.fromJson(catJson, catType) } catch (_: Exception) { null }
            } else null

            val cleanCategories = parsedCategories?.filter { c ->
                !c.slug.equals("cinex-movies", ignoreCase = true) &&
                !c.name.equals("CINEX MOVIES", ignoreCase = true)
            }?.mapIndexed { idx, c ->
                val name = c.displayName
                c.copy(
                    id = if (c.id.isNotBlank()) c.id else "gcat_${idx + 1}",
                    name = name,
                    slug = if (c.slug.isNotBlank()) c.slug else name.lowercase().replace(Regex("[^a-z0-9]+"), "-"),
                    m3uLink = c.m3uLink.trim()
                )
            } ?: emptyList()

            // 2. Fetch Live Events from Google Drive (Primary User Source for Cricket)
            val driveLiveUrls = listOf(
                "https://drive.google.com/uc?export=download&id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu",
                "https://docs.google.com/uc?export=download&id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu",
                "https://drive.usercontent.google.com/download?id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu&export=download"
            )
            var liveJson: String? = null
            for (url in driveLiveUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    liveJson = res
                    break
                }
            }
            if (!liveJson.isNullOrBlank()) {
                updateAdConfigFromJson(liveJson)
            }

            // 3. Fetch Non-Cricket Sports (Football, American football, Basketball, etc.) from Sports_data.json
            val sportsDataUrl = "https://raw.githubusercontent.com/sm-monirulislam/Upcoming-and-Live-Sports-Data/main/Sports_data.json"
            val sportsJson = httpGet(sportsDataUrl)
            val nonCricketMatches = mutableListOf<LiveStreamEvent>()
            if (!sportsJson.isNullOrBlank()) {
                try {
                    val root = org.json.JSONObject(sportsJson)
                    val arr = root.optJSONArray("matches") ?: org.json.JSONArray()
                    for (i in 0 until arr.length()) {
                        val mObj = arr.getJSONObject(i)
                        val cat = mObj.optString("Category", mObj.optString("sport", "Football"))
                        val t = mObj.optString("event_name", "")
                        val league = mObj.optJSONObject("eventInfo")?.optString("eventName", "") ?: ""
                        // 🛑 Strict Cricket Filter: Only keep non-cricket sports
                        if (!isCricketMatch(cat, t, league)) {
                            val parsedEvent = mapSportsDataMatch(mObj, i)
                            if (parsedEvent != null) {
                                nonCricketMatches.add(parsedEvent)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            val parsedDriveFeed = parseUniversalLiveFeed(liveJson)
            val cricketLiveList = parsedDriveFeed.liveEvents
            val cricketUpList = parsedDriveFeed.upcomingEvents
            val cricketFinList = parsedDriveFeed.finishedEvents

            // Combine Cricket (Drive) + Non-Cricket sports (Sports_data.json)
            val liveList = cricketLiveList + nonCricketMatches.filter { it.status.equals("LIVE", ignoreCase = true) }
            val upList = cricketUpList + nonCricketMatches.filter { it.status.equals("UPCOMING", ignoreCase = true) }
            val finList = cricketFinList + nonCricketMatches.filter { it.status.equals("FINISHED", ignoreCase = true) || it.status.equals("ENDED", ignoreCase = true) }

            if (cleanCategories.isEmpty() && liveList.isEmpty() && upList.isEmpty()) {
                return@withContext null
            }

            val official = getOfficialDefaultFeed()
            MobileFeedResponse(
                status = "success",
                timestamp = System.currentTimeMillis(),
                appConfig = official.appConfig,
                adConfig = _adConfigState.value,
                categories = cleanCategories,
                liveEvents = if (liveList.isNotEmpty()) liveList else official.liveEvents,
                upcomingEvents = upList,
                recentEvents = finList,
                vodSection = official.vodSection
            )
        } catch (_: Exception) {
            null
        }
    }

    fun addCustomLiveEvent(event: LiveStreamEvent) {
        val current = _feedState.value ?: getOfficialDefaultFeed()
        val updatedEvents = listOf(event) + current.liveEvents.filter { it.id != event.id }
        _feedState.value = current.copy(liveEvents = updatedEvents)
        saveToLocalCache(_feedState.value!!)
    }

    fun addCustomLiveEvents(events: List<LiveStreamEvent>) {
        if (events.isEmpty()) return
        val current = _feedState.value ?: getOfficialDefaultFeed()
        val existingIds = events.map { it.id }.toSet()
        val updatedEvents = events + current.liveEvents.filter { !existingIds.contains(it.id) }
        _feedState.value = current.copy(liveEvents = updatedEvents)
        saveToLocalCache(_feedState.value!!)
    }

    suspend fun getMoviesFeed(context: android.content.Context? = null): List<CinexMovieItem> = withContext(Dispatchers.IO) {
        // 1. Try GitHub Raw data.json
        val ghMoviesJson = httpGet("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/cinex_movies.json")
        if (!ghMoviesJson.isNullOrBlank()) {
            try {
                val parsed = gson.fromJson(ghMoviesJson, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) return@withContext parsed.matches
            } catch (_: Exception) {}
        }

        // 2. Try cloud Vercel backend
        try {
            val endpoint = if (cloudApiBaseUrl.endsWith("/")) "${cloudApiBaseUrl}api/movies/data.json" else "$cloudApiBaseUrl/api/movies/data.json"
            val json = httpGet(endpoint)
            if (!json.isNullOrBlank()) {
                val parsed = gson.fromJson(json, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) return@withContext parsed.matches
            }
        } catch (_: Exception) {}

        // 3. Resilient fallback to bundled assets/cinex_movies.json (160+ Titles instant boot!)
        if (context != null) {
            try {
                val inputStream = context.assets.open("cinex_movies.json")
                val reader = BufferedReader(InputStreamReader(inputStream))
                val json = reader.readText()
                reader.close()
                val parsed = gson.fromJson(json, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) {
                    return@withContext parsed.matches
                }
            } catch (_: Exception) {}
        }

        emptyList()
    }

    suspend fun getTvChannelsFeed(context: android.content.Context? = null): List<ParsedChannelItem> = withContext(Dispatchers.IO) {
        emptyList()
    }

    fun getOfficialDefaultFeed(): MobileFeedResponse {
        val liveList = emptyList<LiveStreamEvent>()
        val upcomingList = emptyList<LiveStreamEvent>()
        val categoriesList = emptyList<FeedCategory>()

        val vodList = emptyList<VodShow>()

        return MobileFeedResponse(
            status = "success",
            timestamp = System.currentTimeMillis(),
            appConfig = AppConfig(
                appName = "HD STREAM",
                announcement = "🔴 HD STREAM is LIVE! ⚡ 24/7 Live Sports & Channels!",
                announcementEnabled = false,
                appVersion = "3.4.17",
                minVersion = "1.0.0",
                apkDownloadUrl = "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/HD-STREAM.apk",
                telegramLink = "https://t.me/livetvofficialapp"
            ),
            categories = categoriesList,
            liveEvents = liveList,
            upcomingEvents = upcomingList,
            recentEvents = emptyList(),
            vodSection = vodList
        )
    }
}
