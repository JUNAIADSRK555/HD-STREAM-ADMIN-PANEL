package com.hdstream.live.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hdstream.live.model.*
import com.hdstream.live.player.M3uParser
import com.hdstream.live.player.ParsedChannelItem
import com.hdstream.live.util.AdGateManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class StreamRepository(private val context: Context? = null) {

    private val okHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    var cloudApiBaseUrl: String = "https://stream-admin-backend.vercel.app"

    private val _feedState = MutableStateFlow<MobileFeedResponse?>(null)
    val feedState: StateFlow<MobileFeedResponse?> = _feedState.asStateFlow()

    private val _adConfigState = MutableStateFlow<AdConfig>(
        context?.let { AdGateManager.getCachedAdConfig(it) } ?: AdConfig()
    )
    val adConfigState: StateFlow<AdConfig> = _adConfigState.asStateFlow()

    fun updateAdConfigFromJson(jsonStr: String?) {
        if (jsonStr.isNullOrBlank()) return
        try {
            val trimmed = jsonStr.trim()
            var foundConfig: AdConfig? = null
            val defaultFallback = AdConfig()
            if (trimmed.startsWith("{")) {
                val obj = org.json.JSONObject(trimmed)
                if (obj.has("adConfig")) {
                    val adObj = obj.getJSONObject("adConfig")
                    foundConfig = AdConfig(
                        enabled = adObj.optBoolean("enabled", defaultFallback.enabled),
                        adUrl = adObj.optString("adUrl", defaultFallback.adUrl).trim().ifBlank { defaultFallback.adUrl },
                        waitSeconds = adObj.optInt("waitSeconds", defaultFallback.waitSeconds),
                        unlockHours = adObj.optInt("unlockHours", defaultFallback.unlockHours),
                        bannerImageUrl = adObj.optString("bannerImageUrl", "").trim(),
                        bannerClickUrl = adObj.optString("bannerClickUrl", "").trim()
                    )
                }
            } else if (trimmed.startsWith("[")) {
                val arr = org.json.JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    if (item.has("adConfig")) {
                        val adObj = item.getJSONObject("adConfig")
                        foundConfig = AdConfig(
                            enabled = adObj.optBoolean("enabled", defaultFallback.enabled),
                            adUrl = adObj.optString("adUrl", defaultFallback.adUrl).trim().ifBlank { defaultFallback.adUrl },
                            waitSeconds = adObj.optInt("waitSeconds", defaultFallback.waitSeconds),
                            unlockHours = adObj.optInt("unlockHours", defaultFallback.unlockHours),
                            bannerImageUrl = adObj.optString("bannerImageUrl", "").trim(),
                            bannerClickUrl = adObj.optString("bannerClickUrl", "").trim()
                        )
                        break
                    }
                }
            }
            if (foundConfig != null) {
                _adConfigState.value = foundConfig
                if (context != null) {
                    AdGateManager.saveCachedAdConfig(context, foundConfig)
                }
            }
        } catch (_: Exception) {}
    }

    private val gson = Gson()
    private val PREFS_NAME = "hd_stream_feed_cache"
    private val KEY_CACHED_FEED = "cached_feed_json"

    // Remote GitHub Raw & CDN Endpoints (Zero APK Update Architecture)
    private val githubLiveMatchesUrls = listOf(
        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/live_matches.json",
        "https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/data/live_matches.json"
    )

    private val githubCategoriesUrls = listOf(
        "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/categories.json",
        "https://cdn.jsdelivr.net/gh/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL@main/data/categories.json"
    )

    init {
        // Fast instant boot from SharedPreferences local cache
        loadFromLocalCache()
        if (_feedState.value == null) {
            _feedState.value = getOfficialDefaultFeed()
        }
    }

    private fun loadFromLocalCache() {
        if (context == null) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(KEY_CACHED_FEED, null)
            if (!json.isNullOrBlank()) {
                val cached = gson.fromJson(json, MobileFeedResponse::class.java)
                if (cached != null) {
                    _feedState.value = cached
                    if (cached.adConfig.enabled) {
                        _adConfigState.value = cached.adConfig
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun saveToLocalCache(feed: MobileFeedResponse) {
        if (context == null) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = gson.toJson(feed)
            prefs.edit().putString(KEY_CACHED_FEED, json).apply()
            if (feed.adConfig.enabled) {
                AdGateManager.saveCachedAdConfig(context, feed.adConfig)
            }
        } catch (_: Exception) {}
    }

    private fun httpGet(urlStr: String, timeoutMs: Int = 4500): String? {
        var curUrl = urlStr
        var redirects = 0
        while (redirects < 5) {
            try {
                val url = URL(curUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = timeoutMs
                conn.readTimeout = timeoutMs
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; HDStream/3.2.2)")
                conn.setRequestProperty("Accept", "*/*")
                conn.setRequestProperty("Cache-Control", "no-cache")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        curUrl = loc
                        redirects++
                        continue
                    }
                }
                if (code in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val content = reader.readText()
                    reader.close()
                    return content
                }
                return null
            } catch (_: Exception) {
                return null
            }
        }
        return null
    }

    companion object {
        fun getTeamFlagUrl(teamName: String): String {
            val t = teamName.lowercase().trim()
            return when {
                t.contains("india") || t == "ind" -> "https://flagcdn.com/w160/in.png"
                t.contains("new zealand") || t.contains("zealand") || t == "nz" -> "https://flagcdn.com/w160/nz.png"
                t.contains("australia") || t == "aus" -> "https://flagcdn.com/w160/au.png"
                t.contains("england") || t == "eng" -> "https://flagcdn.com/w160/gb-eng.png"
                t.contains("pakistan") || t == "pak" -> "https://flagcdn.com/w160/pk.png"
                t.contains("south africa") || t == "sa" -> "https://flagcdn.com/w160/za.png"
                t.contains("bangladesh") || t == "ban" || t == "bd" -> "https://flagcdn.com/w160/bd.png"
                t.contains("sri lanka") || t == "sl" || t == "lk" -> "https://flagcdn.com/w160/lk.png"
                t.contains("afghanistan") || t == "afg" -> "https://flagcdn.com/w160/af.png"
                t.contains("nepal") || t == "nep" || t == "npl" -> "https://flagcdn.com/w160/np.png"
                t.contains("west indies") || t == "wi" -> "https://flagcdn.com/w160/jm.png"
                t.contains("zimbabwe") || t == "zim" -> "https://flagcdn.com/w160/zw.png"
                t.contains("ireland") || t == "ire" -> "https://flagcdn.com/w160/ie.png"
                t.contains("scotland") || t == "sco" -> "https://flagcdn.com/w160/gb-sct.png"
                t.contains("netherlands") || t == "ned" -> "https://flagcdn.com/w160/nl.png"
                t.contains("usa") || t.contains("united states") -> "https://flagcdn.com/w160/us.png"
                t.contains("canada") || t == "can" -> "https://flagcdn.com/w160/ca.png"
                else -> ""
            }
        }
    }

    fun isCricketMatch(category: String, title: String, league: String): Boolean {
        val cat = category.trim().lowercase()
        val fullText = "$cat ${title.lowercase()} ${league.lowercase()}"
        if (cat == "cricket") return true
        val cricketKeywords = listOf(
            "cricket", "t20", "odi", "test match", "test series", "ipl",
            "bbl", "psl", "cpl", "lpl", "npl", "bpl", "abu dhabi",
            "world test championship", "u19", "big bash", "ranji",
            "bcci", "icc", "stump", "wicket", "overs", "bangladesh",
            "west indies", "pakistan", "sri lanka", "zimbabwe", "afghanistan"
        )
        return cricketKeywords.any { fullText.contains(it) }
    }

    private fun mapSportsDataMatch(m: org.json.JSONObject, index: Int): LiveStreamEvent? {
        val info = m.optJSONObject("eventInfo")
        val title = (m.optString("event_name", "").ifBlank {
            if (info != null) "${info.optString("teamA")} vs ${info.optString("teamB")}" else "Sports Match ${index + 1}"
        }).trim()
        val status = m.optString("status", "LIVE").uppercase()
        val category = m.optString("Category", "Football").trim()
        val tournament = (info?.optString("eventName") ?: category).trim()
        val team1Name = (info?.optString("teamA") ?: title.split(Regex(" vs ", RegexOption.IGNORE_CASE)).getOrNull(0) ?: "Team 1").trim()
        val team2Name = (info?.optString("teamB") ?: title.split(Regex(" vs ", RegexOption.IGNORE_CASE)).getOrNull(1) ?: "Team 2").trim()

        val streamsArr = m.optJSONArray("streams") ?: org.json.JSONArray()
        val streams = mutableListOf<StreamSource>()
        for (sIdx in 0 until streamsArr.length()) {
            val s = streamsArr.getJSONObject(sIdx)
            val url = (s.optString("stream_url", s.optString("streamUrl", s.optString("url", "")))).trim()
            if (url.isNotBlank() && url.startsWith("http")) {
                // Filter out known dead/offline IP servers
                val isDeadHost = url.contains("chatgpt.hereisman.net", ignoreCase = true) ||
                        url.contains("193.47.62.", ignoreCase = true) ||
                        url.contains("fromthyheart.site", ignoreCase = true) ||
                        url.contains("demonpvp.fun", ignoreCase = true)
                if (isDeadHost) continue

                val isMpd = url.contains(".mpd")
                val streamType = if (isMpd) "MPD" else "M3U8"
                val referer = s.optString("referer", s.optString("referrer", "")).trim()
                val kid = s.optString("kid", s.optString("key_id", "")).trim()
                val key = s.optString("key", "").trim()
                val hasDrm = kid.isNotBlank() && key.isNotBlank()
                val drm = if (hasDrm) {
                    DrmConfig(
                        enabled = true,
                        scheme = "clearkey",
                        keyId = kid,
                        key = key
                    )
                } else DrmConfig(enabled = false)

                val ua = s.optString("user_agent", "").trim().ifBlank {
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
                }
                val headers = mutableMapOf("User-Agent" to ua)
                if (referer.isNotBlank()) {
                    headers["Referer"] = referer
                    try {
                        val uri = java.net.URI(referer)
                        headers["Origin"] = "${uri.scheme}://${uri.host}"
                    } catch (_: Exception) {}
                }
                streams.add(
                    StreamSource(
                        id = "sports_${index}_$sIdx",
                        title = s.optString("channel_name", "Server ${sIdx + 1} HD"),
                        streamType = streamType,
                        streamUrl = url,
                        quality = "1080p HD",
                        headers = headers,
                        drm = drm
                    )
                )
            }
        }
        if (streams.isEmpty()) return null

        // Prioritize working streams (ClearKey DRM & verified high-speed CDNs first)
        streams.sortByDescending { stream ->
            var score = 0
            if (stream.drm.enabled) score += 60
            if (stream.streamUrl.contains("aiv-cdn.net") || stream.streamUrl.contains("pv-cdn.net")) score += 40
            if (stream.streamUrl.contains("slivcdn.com") || stream.streamUrl.contains("akamaized.net")) score += 30
            if (stream.streamType == "MPD") score += 20
            score
        }

        val flagA = info?.optString("teamAFlag") ?: "⚽"
        val flagB = info?.optString("teamBFlag") ?: "⚽"
        return LiveStreamEvent(
            id = "sports_${index}_${title.hashCode()}",
            title = title,
            category = category,
            status = status,
            format = tournament,
            startTime = info?.optString("startTime") ?: "LIVE NOW",
            bannerUrl = info?.optString("event_logo") ?: "",
            description = "$tournament: $title",
            isPinned = (status == "LIVE"),
            team1 = TeamInfo(name = team1Name, shortName = team1Name.take(4).uppercase().trim(), flag = flagA, logo = flagA),
            team2 = TeamInfo(name = team2Name, shortName = team2Name.take(4).uppercase().trim(), flag = flagB, logo = flagB),
            totalStreams = streams.size,
            streams = streams
        )
    }

    private fun mapMatchItem(m: GDriveMatchItem, defaultStatus: String, index: Int): LiveStreamEvent {
        val title = (m.matchName ?: m.title ?: "Live Match ${index + 1}").trim()
        val status = (m.status ?: defaultStatus).uppercase()
        var team1Name = m.team1Obj?.name ?: m.teamAObj?.name ?: m.team1Name ?: ""
        var team2Name = m.team2Obj?.name ?: m.teamBObj?.name ?: m.team2Name ?: ""
        if (team1Name.isBlank() && team2Name.isBlank()) {
            if (title.contains(" vs ", ignoreCase = true)) {
                val parts = title.split(Regex(" vs ", RegexOption.IGNORE_CASE))
                team1Name = parts.getOrNull(0)?.trim() ?: "Team 1"
                team2Name = parts.getOrNull(1)?.trim() ?: "Team 2"
            } else if (title.contains(" - ")) {
                val parts = title.split(" - ")
                team1Name = parts.getOrNull(0)?.trim() ?: "Team 1"
                team2Name = parts.getOrNull(1)?.trim() ?: "Team 2"
            } else {
                team1Name = title
                team2Name = "Opponent"
            }
        }
        if (team1Name.isBlank()) team1Name = "Team 1"
        if (team2Name.isBlank()) team2Name = "Team 2"

        val streams = (m.streams ?: emptyList()).mapIndexedNotNull { sIdx, s ->
            val rawUrl = (s.url ?: "").trim()
            if (!rawUrl.startsWith("http")) return@mapIndexedNotNull null
            val isMpd = (s.type ?: "").equals("mpd", ignoreCase = true) || rawUrl.contains(".mpd")
            val isHls = (s.type ?: "").equals("hls", ignoreCase = true) || rawUrl.contains(".m3u8")
            val streamType = if (isMpd) "MPD" else if (isHls) "M3U8" else "DIRECT"
            StreamSource(
                id = "stream_${index}_$sIdx",
                title = s.title ?: "Server ${sIdx + 1} HD",
                streamType = streamType,
                streamUrl = rawUrl,
                quality = "1080p HD",
                headers = mapOf("User-Agent" to "ExoPlayer-Media3/1.4.0")
            )
        }

        val flag1 = getTeamFlagUrl(team1Name)
        val flag2 = getTeamFlagUrl(team2Name)
        var t1Logo = if (flag1.isNotBlank()) flag1 else (m.team1Obj?.logo ?: m.teamAObj?.logo ?: m.team1Obj?.flag ?: m.teamAObj?.flag ?: m.team1Logo ?: "")
        var t2Logo = if (flag2.isNotBlank()) flag2 else (m.team2Obj?.logo ?: m.teamBObj?.logo ?: m.team2Obj?.flag ?: m.teamBObj?.flag ?: m.team2Logo ?: "")

        if (t1Logo.isBlank() || t1Logo.contains("wikimedia", ignoreCase = true)) {
            if (flag1.isNotBlank()) t1Logo = flag1
        }
        if (t2Logo.isBlank() || t2Logo.contains("wikimedia", ignoreCase = true)) {
            if (flag2.isNotBlank()) t2Logo = flag2
        }

        val t1Score = m.team1Obj?.score ?: m.teamAObj?.score ?: ""
        val t2Score = m.team2Obj?.score ?: m.teamBObj?.score ?: ""

        val matchTime = if (!m.time.isNullOrBlank() && !m.date.isNullOrBlank()) {
            "${m.time} • ${m.date}"
        } else {
            m.time ?: m.date ?: "LIVE NOW"
        }

        val matchBanner = (m.banner ?: m.bannerUrlSnake ?: m.bannerUrlCamel ?: m.image ?: "").trim()

        return LiveStreamEvent(
            id = "event_${index}_${Math.abs(title.hashCode())}",
            title = title,
            category = m.category ?: "Live Cricket",
            status = status,
            startTime = matchTime,
            bannerUrl = matchBanner,
            description = m.result ?: "",
            team1 = TeamInfo(name = team1Name, shortName = team1Name.take(4).uppercase(), logo = t1Logo, score = t1Score),
            team2 = TeamInfo(name = team2Name, shortName = team2Name.take(4).uppercase(), logo = t2Logo, score = t2Score),
            totalStreams = streams.size,
            streams = streams
        )
    }

    suspend fun fetchFromCloudBackend(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        val endpoints = listOf(
            "${cloudApiBaseUrl.trimEnd('/')}/api/feed/mobile",
            "https://stream-admin-backend.vercel.app/api/feed/mobile"
        ).distinct()

        for (endpoint in endpoints) {
            try {
                val json = httpGet(endpoint, timeoutMs = 4000)
                if (!json.isNullOrBlank()) {
                    val response = gson.fromJson(json, MobileFeedResponse::class.java)
                    if (response != null && (response.liveEvents.isNotEmpty() || response.categories.isNotEmpty())) {
                        return@withContext response
                    }
                }
            } catch (_: Exception) {}
        }
        null
    }

    suspend fun getFeed(): MobileFeedResponse = withContext(Dispatchers.IO) {
        // Step 1: Ensure initial memory state has local cache so UI is never blocked
        if (_feedState.value == null) {
            loadFromLocalCache()
        }

        // Step 2: Priority 1 -> Google Drive Direct Fetch (User Primary Live Event & Category Source)
        val driveFeed = fetchDirectFromGoogleDrive()
        if (driveFeed != null && (driveFeed.liveEvents.isNotEmpty() || driveFeed.categories.isNotEmpty())) {
            saveToLocalCache(driveFeed)
            _feedState.value = driveFeed
            return@withContext driveFeed
        }

        // Step 3: Priority 2 -> Admin Backend Cloud API (Real-time live sync for Admin Panel & JSON imports)
        val cloudFeed = fetchFromCloudBackend()
        if (cloudFeed != null && (cloudFeed.liveEvents.isNotEmpty() || cloudFeed.categories.isNotEmpty())) {
            saveToLocalCache(cloudFeed)
            _feedState.value = cloudFeed
            return@withContext cloudFeed
        }

        // Step 4: Priority 3 -> GitHub Raw / CDN Direct Fetch (Backup dynamic updates)
        val githubFeed = fetchFromGitHubRaw()
        if (githubFeed != null) {
            saveToLocalCache(githubFeed)
            _feedState.value = githubFeed
            return@withContext githubFeed
        }

        // Step 5: Priority 4 -> Return local cached state if available
        _feedState.value?.let { return@withContext it }

        // Step 6: Priority 5 -> Bundled default fallback
        val fallback = getOfficialDefaultFeed()
        _feedState.value = fallback
        fallback
    }

    suspend fun fetchFromGitHubRaw(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch Live Matches from GitHub
            var liveJson: String? = null
            for (url in githubLiveMatchesUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    liveJson = res
                    break
                }
            }

            if (liveJson.isNullOrBlank()) return@withContext null

            val liveResponse = try {
                gson.fromJson(liveJson, GDriveLiveFeedResponse::class.java)
            } catch (_: Exception) { null } ?: return@withContext null

            // 2. Fetch Categories from GitHub
            var catJson: String? = null
            for (url in githubCategoriesUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    catJson = res
                    break
                }
            }

            val parsedCategories: List<FeedCategory>? = if (!catJson.isNullOrBlank()) {
                if (!catJson.isNullOrBlank()) {
                updateAdConfigFromJson(catJson)
            }

            val catType = object : TypeToken<List<FeedCategory>>() {}.type
                try { gson.fromJson(catJson, catType) } catch (_: Exception) { null }
            } else null

            val cleanCategories = parsedCategories?.filter { c ->
                !c.slug.equals("cinex-movies", ignoreCase = true) &&
                !c.name.equals("CINEX MOVIES", ignoreCase = true)
            }?.mapIndexed { idx, c ->
                val name = c.displayName
                c.copy(
                    id = if (c.id.isNotBlank()) c.id else "gcat_${idx + 1}",
                    name = name,
                    slug = if (c.slug.isNotBlank()) c.slug else name.lowercase().replace(Regex("[^a-z0-9]+"), "-"),
                    m3uLink = c.m3uLink.trim()
                )
            } ?: emptyList()

            val liveList = liveResponse.liveMatches?.mapIndexed { idx, it -> mapMatchItem(it, "LIVE", idx) } ?: emptyList()
            val upList = liveResponse.upcomingMatches?.mapIndexed { idx, it -> mapMatchItem(it, "UPCOMING", idx) } ?: emptyList()
            val finList = liveResponse.finishedMatches?.mapIndexed { idx, it -> mapMatchItem(it, "FINISHED", idx) } ?: emptyList()

            val official = getOfficialDefaultFeed()
            val announcementText = if (!liveResponse.announcement.isNullOrBlank()) liveResponse.announcement else official.appConfig.announcement
            val announcementEnabled = liveResponse.announcementEnabled ?: official.appConfig.announcementEnabled

            MobileFeedResponse(
                status = "success",
                timestamp = System.currentTimeMillis(),
                appConfig = official.appConfig.copy(
                    announcement = announcementText,
                    announcementEnabled = announcementEnabled
                ),
                categories = cleanCategories,
                liveEvents = liveList,
                upcomingEvents = upList,
                recentEvents = finList,
                vodSection = official.vodSection
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun fetchDirectFromGoogleDrive(): MobileFeedResponse? = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch Categories from Google Drive (Primary User Source)
            val driveCatUrls = listOf(
                "https://drive.google.com/uc?export=download&id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO",
                "https://docs.google.com/uc?export=download&id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO",
                "https://drive.usercontent.google.com/download?id=1KxcfPpIjkeRaHWyrN53otPBci5s6FMMO&export=download"
            )
            var catJson: String? = null
            for (url in driveCatUrls) {
                try {
                    val req = Request.Builder()
                        .url(url)
                        .cacheControl(CacheControl.FORCE_NETWORK)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")
                        .header("Accept", "*/*")
                        .build()
                    val resp = okHttpClient.newCall(req).execute()
                    if (resp.isSuccessful) {
                        val body = resp.body?.string()
                        if (!body.isNullOrBlank()) {
                            catJson = body
                            break
                        }
                    }
                } catch (_: Exception) {}
                val res = if (catJson.isNullOrBlank()) httpGet(url) else null
                if (!res.isNullOrBlank()) {
                    catJson = res
                    break
                }
            }

            if (!catJson.isNullOrBlank()) {
                updateAdConfigFromJson(catJson)
            }

            val catType = object : TypeToken<List<FeedCategory>>() {}.type
            val parsedCategories: List<FeedCategory>? = if (!catJson.isNullOrBlank()) {
                try { gson.fromJson(catJson, catType) } catch (_: Exception) { null }
            } else null

            val cleanCategories = parsedCategories?.filter { c ->
                !c.slug.equals("cinex-movies", ignoreCase = true) &&
                !c.name.equals("CINEX MOVIES", ignoreCase = true)
            }?.mapIndexed { idx, c ->
                val name = c.displayName
                c.copy(
                    id = if (c.id.isNotBlank()) c.id else "gcat_${idx + 1}",
                    name = name,
                    slug = if (c.slug.isNotBlank()) c.slug else name.lowercase().replace(Regex("[^a-z0-9]+"), "-"),
                    m3uLink = c.m3uLink.trim()
                )
            } ?: emptyList()

            // 2. Fetch Live Events from Google Drive (Primary User Source for Cricket)
            val driveLiveUrls = listOf(
                "https://drive.google.com/uc?export=download&id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu",
                "https://docs.google.com/uc?export=download&id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu",
                "https://drive.usercontent.google.com/download?id=1f2YiLF71pHEPlmodEtLQ-NfT3opWRreu&export=download"
            )
            var liveJson: String? = null
            for (url in driveLiveUrls) {
                val res = httpGet(url)
                if (!res.isNullOrBlank()) {
                    liveJson = res
                    break
                }
            }
            if (!liveJson.isNullOrBlank()) {
                updateAdConfigFromJson(liveJson)
            }

            // 3. Fetch Non-Cricket Sports (Football, American football, Basketball, etc.) from Sports_data.json
            val sportsDataUrl = "https://raw.githubusercontent.com/sm-monirulislam/Upcoming-and-Live-Sports-Data/main/Sports_data.json"
            val sportsJson = httpGet(sportsDataUrl)
            val nonCricketMatches = mutableListOf<LiveStreamEvent>()
            if (!sportsJson.isNullOrBlank()) {
                try {
                    val root = org.json.JSONObject(sportsJson)
                    val arr = root.optJSONArray("matches") ?: org.json.JSONArray()
                    for (i in 0 until arr.length()) {
                        val mObj = arr.getJSONObject(i)
                        val cat = mObj.optString("Category", mObj.optString("sport", "Football"))
                        val t = mObj.optString("event_name", "")
                        val league = mObj.optJSONObject("eventInfo")?.optString("eventName", "") ?: ""
                        // 🛑 Strict Cricket Filter: Only keep non-cricket sports
                        if (!isCricketMatch(cat, t, league)) {
                            val parsedEvent = mapSportsDataMatch(mObj, i)
                            if (parsedEvent != null) {
                                nonCricketMatches.add(parsedEvent)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            val driveLiveResponse = if (!liveJson.isNullOrBlank()) {
                try { gson.fromJson(liveJson, GDriveLiveFeedResponse::class.java) } catch (_: Exception) { null }
            } else null

            val allMatches = driveLiveResponse?.liveMatches ?: emptyList()
            val cricketLiveList = allMatches
                .filter { (it.status ?: "LIVE").equals("LIVE", ignoreCase = true) }
                .mapIndexed { idx, it -> mapMatchItem(it, "LIVE", idx) }
            val cricketUpList = (driveLiveResponse?.upcomingMatches ?: emptyList())
                .plus(allMatches.filter { (it.status ?: "").equals("UPCOMING", ignoreCase = true) })
                .mapIndexed { idx, it -> mapMatchItem(it, "UPCOMING", idx) }
            val cricketFinList = (driveLiveResponse?.finishedMatches ?: emptyList())
                .plus(allMatches.filter { (it.status ?: "").equals("FINISHED", ignoreCase = true) || (it.status ?: "").equals("ENDED", ignoreCase = true) })
                .mapIndexed { idx, it -> mapMatchItem(it, "FINISHED", idx) }

            // Combine Cricket (Drive) + Non-Cricket sports (Sports_data.json)
            val liveList = cricketLiveList + nonCricketMatches.filter { it.status.equals("LIVE", ignoreCase = true) }
            val upList = cricketUpList + nonCricketMatches.filter { it.status.equals("UPCOMING", ignoreCase = true) }
            val finList = cricketFinList + nonCricketMatches.filter { it.status.equals("FINISHED", ignoreCase = true) || it.status.equals("ENDED", ignoreCase = true) }

            if (cleanCategories.isEmpty() && liveList.isEmpty() && upList.isEmpty()) {
                return@withContext null
            }

            val official = getOfficialDefaultFeed()
            MobileFeedResponse(
                status = "success",
                timestamp = System.currentTimeMillis(),
                appConfig = official.appConfig,
                adConfig = _adConfigState.value,
                categories = cleanCategories,
                liveEvents = if (liveList.isNotEmpty()) liveList else official.liveEvents,
                upcomingEvents = upList,
                recentEvents = finList,
                vodSection = official.vodSection
            )
        } catch (_: Exception) {
            null
        }
    }

    fun addCustomLiveEvent(event: LiveStreamEvent) {
        val current = _feedState.value ?: getOfficialDefaultFeed()
        val updatedEvents = listOf(event) + current.liveEvents.filter { it.id != event.id }
        _feedState.value = current.copy(liveEvents = updatedEvents)
        saveToLocalCache(_feedState.value!!)
    }

    fun addCustomLiveEvents(events: List<LiveStreamEvent>) {
        if (events.isEmpty()) return
        val current = _feedState.value ?: getOfficialDefaultFeed()
        val existingIds = events.map { it.id }.toSet()
        val updatedEvents = events + current.liveEvents.filter { !existingIds.contains(it.id) }
        _feedState.value = current.copy(liveEvents = updatedEvents)
        saveToLocalCache(_feedState.value!!)
    }

    suspend fun getMoviesFeed(context: android.content.Context? = null): List<CinexMovieItem> = withContext(Dispatchers.IO) {
        // 1. Try GitHub Raw data.json
        val ghMoviesJson = httpGet("https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/data/cinex_movies.json")
        if (!ghMoviesJson.isNullOrBlank()) {
            try {
                val parsed = gson.fromJson(ghMoviesJson, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) return@withContext parsed.matches
            } catch (_: Exception) {}
        }

        // 2. Try cloud Vercel backend
        try {
            val endpoint = if (cloudApiBaseUrl.endsWith("/")) "${cloudApiBaseUrl}api/movies/data.json" else "$cloudApiBaseUrl/api/movies/data.json"
            val json = httpGet(endpoint)
            if (!json.isNullOrBlank()) {
                val parsed = gson.fromJson(json, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) return@withContext parsed.matches
            }
        } catch (_: Exception) {}

        // 3. Resilient fallback to bundled assets/cinex_movies.json (160+ Titles instant boot!)
        if (context != null) {
            try {
                val inputStream = context.assets.open("cinex_movies.json")
                val reader = BufferedReader(InputStreamReader(inputStream))
                val json = reader.readText()
                reader.close()
                val parsed = gson.fromJson(json, CinexMoviesResponse::class.java)
                if (parsed.matches.isNotEmpty()) {
                    return@withContext parsed.matches
                }
            } catch (_: Exception) {}
        }

        emptyList()
    }

    suspend fun getTvChannelsFeed(context: android.content.Context? = null): List<ParsedChannelItem> = withContext(Dispatchers.IO) {
        emptyList()
    }

    fun getOfficialDefaultFeed(): MobileFeedResponse {
        val liveList = emptyList<LiveStreamEvent>()
        val upcomingList = emptyList<LiveStreamEvent>()
        val categoriesList = emptyList<FeedCategory>()

        val vodList = emptyList<VodShow>()

        return MobileFeedResponse(
            status = "success",
            timestamp = System.currentTimeMillis(),
            appConfig = AppConfig(
                appName = "HD STREAM",
                announcement = "🔴 HD STREAM is LIVE! ⚡ 24/7 Live Sports & Channels!",
                announcementEnabled = false,
                appVersion = "3.4.17",
                minVersion = "1.0.0",
                apkDownloadUrl = "https://raw.githubusercontent.com/JUNAIADSRK555/HD-STREAM-ADMIN-PANEL/main/public/HD-STREAM.apk",
                telegramLink = "https://t.me/livetvofficialapp"
            ),
            categories = categoriesList,
            liveEvents = liveList,
            upcomingEvents = upcomingList,
            recentEvents = emptyList(),
            vodSection = vodList
        )
    }
}
