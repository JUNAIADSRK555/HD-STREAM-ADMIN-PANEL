package com.hdstream.live.model

import com.google.gson.annotations.SerializedName

data class MobileFeedResponse(
    @SerializedName("status") val status: String = "",
    @SerializedName("timestamp") val timestamp: Long = 0L,
    @SerializedName("appConfig") val appConfig: AppConfig = AppConfig(),
    @SerializedName("adConfig") val adConfig: AdConfig = AdConfig(),
    @SerializedName("categories") val categories: List<FeedCategory> = emptyList(),
    @SerializedName("liveEvents") val liveEvents: List<LiveStreamEvent> = emptyList(),
    @SerializedName("upcomingEvents") val upcomingEvents: List<LiveStreamEvent> = emptyList(),
    @SerializedName("recentEvents") val recentEvents: List<LiveStreamEvent> = emptyList(),
    @SerializedName("vodSection") val vodSection: List<VodShow> = emptyList()
)

data class AdConfig(
    @SerializedName("enabled") val enabled: Boolean = false,
    @SerializedName("adUrl") val adUrl: String = "https://asiafilm.org/4/58e150d20e75a70528210dd524d5384a",
    @SerializedName("waitSeconds") val waitSeconds: Int = 15,
    @SerializedName("unlockHours") val unlockHours: Int = 12,
    @SerializedName("bannerImageUrl") val bannerImageUrl: String = "",
    @SerializedName("bannerClickUrl") val bannerClickUrl: String = ""
)

data class AppConfig(
    @SerializedName("appName") val appName: String = "HD STREAM",
    @SerializedName("announcement") val announcement: String = "🔴 Welcome to HD STREAM! Watch Cricket & Entertainment in 1080p 60FPS.",
    @SerializedName("announcementEnabled") val announcementEnabled: Boolean = true,
    @SerializedName("notificationTitle") val notificationTitle: String = "HD STREAM Live Alert",
    @SerializedName("notificationMessage") val notificationMessage: String = "",
    @SerializedName("notificationId") val notificationId: String = "",
    @SerializedName("notificationTime") val notificationTime: String = "",
    @SerializedName("notificationActionUrl") val notificationActionUrl: String = "",
    @SerializedName("appVersion") val appVersion: String = "2.0.0",
    @SerializedName("minVersion") val minVersion: String = "2.0.0",
    @SerializedName("apkDownloadUrl") val apkDownloadUrl: String = "",
    @SerializedName("maintenanceMode") val maintenanceMode: Boolean = false,
    @SerializedName("telegramLink") val telegramLink: String = "https://t.me/livetvofficialapp",
    @SerializedName("sponsorBannerUrl") val sponsorBannerUrl: String = "",
    @SerializedName("sponsorRedirectUrl") val sponsorRedirectUrl: String = "",
    @SerializedName("adsterraEnabled") val adsterraEnabled: Boolean = false,
    @SerializedName("adsterraZoneId") val adsterraZoneId: String = "",
    @SerializedName("adsterraPublisherId") val adsterraPublisherId: String = "",
    @SerializedName("channelChangeAdFrequency") val channelChangeAdFrequency: Int = 999
)

data class FeedCategory(
    @SerializedName("id") val id: String = "",
    @SerializedName("name") val name: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("slug") val slug: String = "",
    @SerializedName("icon") val icon: String = "",
    @SerializedName("imageUrl") val imageUrl: String = "",
    @SerializedName("m3uLink") val m3uLink: String = "",
    @SerializedName("type") val type: String = "",
    @SerializedName("server") val server: String = "",
    @SerializedName("username") val username: String = "",
    @SerializedName("password") val password: String = "",
    @SerializedName("server_url") val serverUrl: String = "",
    @SerializedName("host") val host: String = "",
    @SerializedName("portal_url") val portalUrl: String = "",
    @SerializedName("mac") val mac: String = "",
    @SerializedName("serial") val serial: String = "",
    @SerializedName("device_id_1") val deviceId1: String = "",
    @SerializedName("device_id_2") val deviceId2: String = "",
    @SerializedName("signature") val signature: String = ""
) {
    val displayName: String get() = if (name.isNotBlank()) name else if (title.isNotBlank()) title else "Category"

    val isXtream: Boolean get() {
        if (type.equals("xtream", ignoreCase = true) ||
            type.equals("xtream_codes", ignoreCase = true) ||
            type.equals("xc", ignoreCase = true)) return true
        if (effectiveServer.isNotBlank() && effectiveUsername.isNotBlank() && effectivePassword.isNotBlank()) return true
        if (com.hdstream.live.player.XtreamCodesManager.isXtream(m3uLink)) return true
        return false
    }

    val effectiveServer: String get() {
        if (server.isNotBlank()) return server.trim()
        if (serverUrl.isNotBlank()) return serverUrl.trim()
        if (host.isNotBlank()) return host.trim()
        val creds = com.hdstream.live.player.XtreamCodesManager.parseCredentials(m3uLink)
        return creds?.server ?: ""
    }

    val effectiveUsername: String get() {
        if (username.isNotBlank()) return username.trim()
        val creds = com.hdstream.live.player.XtreamCodesManager.parseCredentials(m3uLink)
        return creds?.username ?: ""
    }

    val effectivePassword: String get() {
        if (password.isNotBlank()) return password.trim()
        val creds = com.hdstream.live.player.XtreamCodesManager.parseCredentials(m3uLink)
        return creds?.password ?: ""
    }

    val isStalker: Boolean get() = !isXtream && (type.equals("stalker", ignoreCase = true) ||
            portalUrl.isNotBlank() ||
            name.contains("stalker", ignoreCase = true) ||
            slug.contains("stalker", ignoreCase = true) ||
            m3uLink.contains("stalker_portal", ignoreCase = true) ||
            m3uLink.contains("/c/", ignoreCase = true) ||
            m3uLink.endsWith("/c", ignoreCase = true) ||
            m3uLink.contains("load.php", ignoreCase = true))
}

data class LiveStreamEvent(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("category") val category: String = "Live Cricket",
    @SerializedName("status") val status: String = "LIVE", // LIVE, UPCOMING, FINISHED
    @SerializedName("format") val format: String = "T20",
    @SerializedName("startTime") val startTime: String = "",
    @SerializedName("bannerUrl") val bannerUrl: String = "",
    @SerializedName("description") val description: String = "",
    @SerializedName("isPinned") val isPinned: Boolean = false,
    @SerializedName("team1") val team1: TeamInfo = TeamInfo(),
    @SerializedName("team2") val team2: TeamInfo = TeamInfo(),
    @SerializedName("totalStreams") val totalStreams: Int = 0,
    @SerializedName("streams") val streams: List<StreamSource> = emptyList()
)

data class TeamInfo(
    @SerializedName("name") val name: String = "",
    @SerializedName("shortName") val shortName: String = "",
    @SerializedName("flag") val flag: String = "",
    @SerializedName("logo") val logo: String = "",
    @SerializedName("score") val score: String = ""
)

data class StreamSource(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("streamType") val streamType: String = "M3U8", // M3U8, MPD, DIRECT, EMBED, JSON, STALKER
    @SerializedName("streamUrl") val streamUrl: String = "",
    @SerializedName("jsonChannelUrl") val jsonChannelUrl: String = "",
    @SerializedName("jsonTokenUrl") val jsonTokenUrl: String = "",
    @SerializedName("jsonToken") val jsonToken: String = "",
    @SerializedName("quality") val quality: String = "1080p HD",
    @SerializedName("headers") val headers: Map<String, String> = emptyMap(),
    @SerializedName("drm") val drm: DrmConfig = DrmConfig(),
    val channelIndex: Int = -1,
    @SerializedName("type") val type: String = "",
    @SerializedName("portal_url") val portalUrl: String = "",
    @SerializedName("mac") val mac: String = "",
    @SerializedName("serial") val serial: String = "",
    @SerializedName("device_id_1") val deviceId1: String = "",
    @SerializedName("cmd") val cmd: String = ""
)

data class DrmConfig(
    @SerializedName("enabled") val enabled: Boolean = false,
    @SerializedName("scheme") val scheme: String = "clearkey",
    @SerializedName("keyId") val keyId: String = "",
    @SerializedName("key") val key: String = "",
    @SerializedName("licenseUrl") val licenseUrl: String? = null
)

data class VodShow(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("category") val category: String = "",
    @SerializedName("posterUrl") val posterUrl: String = "",
    @SerializedName("bannerUrl") val bannerUrl: String = "",
    @SerializedName("description") val description: String = "",
    @SerializedName("rating") val rating: String = "8.5",
    @SerializedName("releaseYear") val releaseYear: String = "2026",
    @SerializedName("totalEpisodes") val totalEpisodes: Int = 0,
    @SerializedName("episodes") val episodes: List<VodEpisode> = emptyList()
)

data class VodEpisode(
    @SerializedName("id") val id: String = "",
    @SerializedName("episodeNumber") val episodeNumber: Int = 1,
    @SerializedName("title") val title: String = "",
    @SerializedName("duration") val duration: String = "",
    @SerializedName("thumbnail") val thumbnail: String = "",
    @SerializedName("streamType") val streamType: String = "M3U8",
    @SerializedName("streamUrl") val streamUrl: String = "",
    @SerializedName("headers") val headers: Map<String, String> = emptyMap(),
    @SerializedName("drm") val drm: DrmConfig = DrmConfig()
)

data class FeaturedChannelItem(
    val name: String,
    val category: String,
    val emoji: String,
    val streamUrl: String
)

data class SportsCategoryItem(
    val name: String,
    val emoji: String,
    val count: Int,
    val isAll: Boolean = false,
    val label: String = "",
    val isLiveNow: Boolean = true
)

data class StatusPillItem(
    val key: String,
    val label: String
)

data class CinexMoviesResponse(
    @SerializedName("matches") val matches: List<CinexMovieItem> = emptyList()
)

data class CinexMovieItem(
    @SerializedName("id") val id: String = "",
    @SerializedName("title") val title: String = "",
    @SerializedName("poster") val poster: String = "",
    @SerializedName("categories") val categories: String = "",
    @SerializedName("heading") val heading: String = "",
    @SerializedName("metadata") val metadata: CinexMovieMetadata = CinexMovieMetadata(),
    @SerializedName("trailer") val trailer: CinexMovieTrailer = CinexMovieTrailer(),
    @SerializedName("channels") val channels: List<CinexMovieChannel> = emptyList()
)

data class CinexMovieMetadata(
    @SerializedName("imdbRating") val imdbRating: String = "",
    @SerializedName("genre") val genre: List<String> = emptyList(),
    @SerializedName("stars") val stars: List<String> = emptyList(),
    @SerializedName("director") val director: String = "",
    @SerializedName("language") val language: String = "",
    @SerializedName("quality") val quality: String = "HD"
)

data class CinexMovieTrailer(
    @SerializedName("embedUrl") val embedUrl: String = "",
    @SerializedName("title") val title: String = ""
)

data class CinexMovieChannel(
    @SerializedName("id") val id: String = "",
    @SerializedName("name") val name: String = "Watch Stream",
    @SerializedName("streamType") val streamType: String = "hls",
    @SerializedName("streamUrl") val streamUrl: String = ""
)

// Google Drive & GitHub Dynamic Models
data class GDriveLiveFeedResponse(
    @SerializedName("announcement") val announcement: String? = null,
    @SerializedName("announcement_enabled") val announcementEnabledSnake: Boolean? = null,
    @SerializedName("announcementEnabled") val announcementEnabledCamel: Boolean? = null,
    @SerializedName("Matches") val matchesUpper: List<GDriveMatchItem>? = null,
    @SerializedName("matches") val matchesLower: List<GDriveMatchItem>? = null,
    @SerializedName("data") val dataList: List<GDriveMatchItem>? = null,
    @SerializedName("items") val itemsList: List<GDriveMatchItem>? = null,
    @SerializedName("events") val eventsList: List<GDriveMatchItem>? = null,
    @SerializedName("live_matches") val liveMatchesSnake: List<GDriveMatchItem>? = null,
    @SerializedName("liveMatches") val liveMatchesCamel: List<GDriveMatchItem>? = null,
    @SerializedName("upcoming_matches") val upcomingMatchesSnake: List<GDriveMatchItem>? = null,
    @SerializedName("upcomingMatches") val upcomingMatchesCamel: List<GDriveMatchItem>? = null,
    @SerializedName("finished_matches") val finishedMatchesSnake: List<GDriveMatchItem>? = null,
    @SerializedName("finishedMatches") val finishedMatchesCamel: List<GDriveMatchItem>? = null
) {
    val liveMatches: List<GDriveMatchItem>? get() = liveMatchesSnake ?: liveMatchesCamel
    val upcomingMatches: List<GDriveMatchItem>? get() = upcomingMatchesSnake ?: upcomingMatchesCamel
    val finishedMatches: List<GDriveMatchItem>? get() = finishedMatchesSnake ?: finishedMatchesCamel
    val announcementEnabled: Boolean? get() = announcementEnabledSnake ?: announcementEnabledCamel
    val generalMatches: List<GDriveMatchItem>? get() = matchesUpper ?: matchesLower ?: dataList ?: itemsList ?: eventsList
}

data class GDriveTeamInfo(
    @SerializedName("name") val name: String? = null,
    @SerializedName("logo") val logo: String? = null,
    @SerializedName("flag") val flag: String? = null,
    @SerializedName("score") val score: String? = null
)

data class GDriveMatchItem(
    @SerializedName("id") val id: String? = null,
    @SerializedName("match_id") val matchId: String? = null,
    @SerializedName("match_name") val matchName: String? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("synopsis") val synopsis: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("time") val time: String? = null,
    @SerializedName("date") val date: String? = null,
    @SerializedName("result") val result: String? = null,
    @SerializedName("category") val category: String? = null,
    @SerializedName("sport") val sport: String? = null,
    @SerializedName("team1_name") val team1Name: String? = null,
    @SerializedName("team1_logo") val team1Logo: String? = null,
    @SerializedName("team1") val team1Obj: GDriveTeamInfo? = null,
    @SerializedName("team_a") val teamAObj: GDriveTeamInfo? = null,
    @SerializedName("team2_name") val team2Name: String? = null,
    @SerializedName("team2_logo") val team2Logo: String? = null,
    @SerializedName("team2") val team2Obj: GDriveTeamInfo? = null,
    @SerializedName("team_b") val teamBObj: GDriveTeamInfo? = null,
    @SerializedName("banner") val banner: String? = null,
    @SerializedName("banner_url") val bannerUrlSnake: String? = null,
    @SerializedName("bannerUrl") val bannerUrlCamel: String? = null,
    @SerializedName("banner_logo") val bannerLogo: String? = null,
    @SerializedName("cover_image") val coverImage: String? = null,
    @SerializedName("image") val image: String? = null,
    @SerializedName("poster") val poster: String? = null,
    @SerializedName("match_url") val matchUrl: String? = null,
    @SerializedName("stream_url_alpha") val streamUrlAlpha: String? = null,
    @SerializedName("stream_url_beta") val streamUrlBeta: String? = null,
    @SerializedName("stream_url") val streamUrl: String? = null,
    @SerializedName("drm_key") val drmKey: String? = null,
    @SerializedName("is_free") val isFree: Boolean? = null,
    @SerializedName("streams") val streams: List<GDriveStreamItem>? = null,
    @SerializedName("channels") val channels: List<GDriveStreamItem>? = null,
    @SerializedName("servers") val servers: List<GDriveStreamItem>? = null,
    @SerializedName("links") val links: List<GDriveStreamItem>? = null
)

data class GDriveStreamItem(
    @SerializedName("id") val id: String? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("channel_name") val channelName: String? = null,
    @SerializedName("server") val server: String? = null,
    @SerializedName("url") val url: String? = null,
    @SerializedName("stream_url") val streamUrlSnake: String? = null,
    @SerializedName("streamUrl") val streamUrlCamel: String? = null,
    @SerializedName("link") val link: String? = null,
    @SerializedName("type") val type: String? = null,
    @SerializedName("streamType") val streamType: String? = null,
    @SerializedName("quality") val quality: String? = null,
    @SerializedName("drm_key") val drmKey: String? = null,
    @SerializedName("key_id") val keyId: String? = null,
    @SerializedName("kid") val kid: String? = null,
    @SerializedName("key") val key: String? = null,
    @SerializedName("headers") val headers: Map<String, String>? = null,
    @SerializedName("user_agent") val userAgent: String? = null,
    @SerializedName("referer") val referer: String? = null,
    @SerializedName("cookie") val cookie: String? = null,
    @SerializedName("origin") val origin: String? = null,
    @SerializedName("drm") val drm: DrmConfig? = null
)
