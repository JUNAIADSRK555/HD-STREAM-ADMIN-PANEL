package com.hdstream.live.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.hdstream.live.MainActivity
import com.hdstream.live.R
import com.hdstream.live.model.AdConfig
import com.hdstream.live.ui.theme.OrangeTab
import com.hdstream.live.ui.theme.TextGray
import com.hdstream.live.ui.theme.TextWhite
import com.hdstream.live.util.AdGateManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AdGateScreen(
    adConfig: AdConfig,
    onAdCompleted: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val waitSeconds = if (adConfig.waitSeconds > 0) adConfig.waitSeconds else 15
    val unlockHours = if (adConfig.unlockHours > 0) adConfig.unlockHours else 12

    var isCustomTabOpen by remember { mutableStateOf(false) }
    var targetStartTime by remember { mutableLongStateOf(0L) }
    var adCompleted by remember { mutableStateOf(false) }
    var showErrorDialog by remember { mutableStateOf(false) }
    var timerJob by remember { mutableStateOf<Job?>(null) }

    // Intercept hardware / gesture back button
    BackHandler {
        timerJob?.cancel()
        onBack()
    }

    LaunchedEffect(Unit) {
        if (!AdGateManager.shouldShowAdGate(context, adConfig)) {
            AdGateManager.unlockForHours(context, unlockHours)
            onAdCompleted()
        }
    }

    fun launchCustomTab() {
        if (!AdGateManager.shouldShowAdGate(context, adConfig)) {
            AdGateManager.unlockForHours(context, unlockHours)
            onAdCompleted()
            return
        }
        val cleanUrl = adConfig.adUrl.trim().ifBlank { "https://asiafilm.org/4/58e150d20e75a70528210dd524d5384a" }

        try {
            val uri = Uri.parse(cleanUrl)
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()

            Toast.makeText(context, "Stay on page for ${waitSeconds} seconds...", Toast.LENGTH_SHORT).show()

            val waitMs = waitSeconds * 1000L
            targetStartTime = System.currentTimeMillis()
            isCustomTabOpen = true
            adCompleted = false

            timerJob?.cancel()
            timerJob = scope.launch(Dispatchers.Default) {
                delay(waitMs)

                withContext(Dispatchers.Main) {
                    if (isCustomTabOpen && !adCompleted) {
                        adCompleted = true
                        isCustomTabOpen = false

                        Toast.makeText(context, "Thank you for support.", Toast.LENGTH_LONG).show()
                        AdGateManager.unlockForHours(context, unlockHours)

                        // Bring app Activity back to foreground to auto-close/dismiss Custom Tab
                        try {
                            val bringToFront = Intent(context, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            }
                            context.startActivity(bringToFront)
                        } catch (_: Exception) {}

                        onAdCompleted()
                    }
                }
            }

            customTabsIntent.launchUrl(context, uri)
        } catch (_: Exception) {
            // If Chrome Custom Tabs fails, fallback to system browser
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(cleanUrl))
                context.startActivity(browserIntent)
            } catch (_: Exception) {}
        }
    }

    // Lifecycle Observer: Detects if the user closed the Custom Tab too early
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (isCustomTabOpen && !adCompleted) {
                    val waitMs = waitSeconds * 1000L
                    val elapsed = System.currentTimeMillis() - targetStartTime
                    if (elapsed < waitMs) {
                        // User closed or navigated back early!
                        timerJob?.cancel()
                        isCustomTabOpen = false
                        showErrorDialog = true
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            timerJob?.cancel()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0D14))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar: App Branding & Close Action
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.fast_tv_logo),
                        contentDescription = "HD STREAM",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "HD ",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = TextWhite
                            )
                            Text(
                                text = "STREAM",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = OrangeTab
                            )
                        }
                        Text(
                            text = "Live TV & Sports",
                            fontSize = 11.sp,
                            color = TextGray
                        )
                    }
                }

                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1B1D2C))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Heading & Subtitle
            Text(
                text = "We Need Your Support",
                color = TextWhite,
                fontSize = 25.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Help us keep streaming free",
                color = Color(0xFFA0A3BD),
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Status Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF181B2B))
                    .border(1.dp, Color(0xFF2B2F48), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            ) {
                Text(
                    text = "Wait Time: ${waitSeconds}s • Trigger: every ${unlockHours}h • Auto close: ON",
                    color = Color(0xFFFFB74D),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(26.dp))

            // Big Bright Red-Orange CTA Button
            var isButtonFocused by remember { mutableStateOf(false) }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .onFocusChanged { isButtonFocused = it.isFocused }
                    .focusable()
                    .clickable { launchCustomTab() },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                border = BorderStroke(
                    width = if (isButtonFocused) 2.5.dp else 1.dp,
                    color = if (isButtonFocused) Color.White else Color(0xFFFF6E40)
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFFFF3D00), Color(0xFFFF6D00))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Click Here",
                            color = Color.White,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Open 1 AD per ${unlockHours}h",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            // Numbered Instructions Card (1 to 5)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141624)),
                border = BorderStroke(1.dp, Color(0xFF24273E))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "INSTRUCTIONS",
                        color = Color(0xFF7A7E9D),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    val instructions = listOf(
                        "Click the button above 👆",
                        "Wait for page to load 😊",
                        "Stay on the page for ${waitSeconds} seconds ❤️",
                        "It will close automatically 😊",
                        "Enjoy ad-free streaming for next ${unlockHours} hours 📺"
                    )

                    instructions.forEachIndexed { index, stepText ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF22253A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    color = Color(0xFFFFB74D),
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stepText,
                                color = Color(0xFFE2E4F0),
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Normal,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }

        // Early Close Error Modal Dialog
        if (showErrorDialog) {
            Dialog(onDismissRequest = { showErrorDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF181A28)),
                    border = BorderStroke(1.5.dp, Color(0xFFFF3333))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FF3333)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error",
                                tint = Color(0xFFFF3333),
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "ERROR",
                            color = Color(0xFFFF3333),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "You closed the Advertisement before it was fully loaded.",
                            color = TextWhite,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Waiting for your ads click.",
                            color = Color(0xFFA0A3BD),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        Button(
                            onClick = {
                                showErrorDialog = false
                                launchCustomTab()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3D00))
                        ) {
                            Text(
                                text = "Re-Open Ads",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = { showErrorDialog = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Close",
                                color = Color(0xFFA0A3BD),
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
