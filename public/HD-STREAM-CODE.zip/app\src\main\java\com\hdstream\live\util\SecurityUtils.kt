package com.hdstream.live.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.Debug
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

object SecurityUtils {

    // Known packet capture and traffic sniffer packages
    private val SNIFFER_PACKAGES = listOf(
        // Reqable (Official Google Play & Sideloaded variants)
        "com.reqable.android",
        "com.reqable.android.debug",
        "com.reqable.app",
        "com.reqable.client",
        "com.reqable",
        // HttpCanary
        "com.guoshi.httpcanary",
        "com.guoshi.httpcanary.premium",
        // SSL Capture & Network Packet Capture
        "app.greyshirts.sslcapture",
        "com.minhui.networkcapture",
        "com.emanuelef.remote_capture",
        // HTTP Toolkit & Proxyman
        "tech.httptoolkit.android",
        "tech.httptoolkit.android.v1",
        "com.proxyman.android",
        // Charles, Fiddler & mitmproxy
        "com.charles.lpoqasert",
        "com.telerik.fiddler",
        "org.mitmproxy.mitmproxy",
        // Virtual Hosts & WebScarab
        "com.github.xfalcon.vhosts",
        "org.sandrop.webscarab"
    )

    // Known hacking, cracking, and memory editing packages
    private val HACKING_PACKAGES = listOf(
        // Lucky Patcher
        "com.chelpus.luckypatcher",
        "com.dimonvideo.luckypatcher",
        "com.forpda.lp",
        "ru.chelpus.luckypatcher",
        // Cheat Engine / GameGuardian / Memory editors
        "catch_.me_.if_.you_.can_",
        "org.cheatengine.cegui",
        "cc.madkite.freedom",
        "com.cih.game_cih",
        // Hooking & Cloner tools
        "de.robv.android.xposed.installer",
        "org.lsposed.manager",
        "org.meowcat.edxposed.manager",
        "com.topjohnwu.magisk",
        "io.github.vvb2060.magisk",
        "io.github.vvb2060.magisk.alpha",
        "com.applisto.appcloner",
        "com.applisto.appcloner.premium",
        "me.weishu.exp"
    )

    // Suspicious su / root binary paths
    private val SU_BINARY_PATHS = listOf(
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/data/local/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/system/usr/we-need-root/su",
        "/system/xbin/daemonsu"
    )

    /**
     * Dedicated detection for Reqable and traffic sniffer / packet capture apps.
     * Returns the name of the detected tool (e.g. "Reqable", "HttpCanary"), or null if clean.
     */
    fun detectSnifferApp(context: Context): String? {
        val pm = context.packageManager

        // 1. Direct package check for known traffic sniffer IDs (Reqable prioritized)
        for (pkg in SNIFFER_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return when {
                    pkg.contains("reqable", ignoreCase = true) -> "Reqable"
                    pkg.contains("httpcanary", ignoreCase = true) -> "HttpCanary"
                    pkg.contains("sslcapture", ignoreCase = true) -> "Packet Capture"
                    pkg.contains("httptoolkit", ignoreCase = true) -> "HTTP Toolkit"
                    pkg.contains("proxyman", ignoreCase = true) -> "Proxyman"
                    else -> "Reqable"
                }
            } catch (_: PackageManager.NameNotFoundException) {
            } catch (_: Exception) {}
        }

        // 2. Scan installed application list for sniffer signatures or label matches
        try {
            val installed = pm.getInstalledPackages(0)
            for (info in installed) {
                val pkgName = info.packageName.lowercase()
                if (pkgName.contains("reqable")) return "Reqable"
                if (pkgName.contains("httpcanary")) return "HttpCanary"
                if (pkgName.contains("sslcapture")) return "Packet Capture"
                if (pkgName.contains("httptoolkit")) return "HTTP Toolkit"

                // Check human-readable application label
                try {
                    val appLabel = pm.getApplicationLabel(info.applicationInfo).toString().lowercase()
                    if (appLabel.contains("reqable")) return "Reqable"
                    if (appLabel.contains("httpcanary")) return "HttpCanary"
                    if (appLabel.contains("packet capture")) return "Packet Capture"
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}

        // 3. Check for active HTTP / HTTPS system proxy (used by Reqable/Charles to intercept streams)
        try {
            val httpProxy = System.getProperty("http.proxyHost")
            val httpsProxy = System.getProperty("https.proxyHost")
            if (!httpProxy.isNullOrBlank() || !httpsProxy.isNullOrBlank()) {
                return "Reqable"
            }
        } catch (_: Exception) {}

        // 4. Check for Reqable's default local proxy port (9000) listening on localhost
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress("127.0.0.1", 9000), 100)
                return "Reqable"
            }
        } catch (_: Exception) {}

        return null
    }

    /**
     * Comprehensive security threat check (Sniffers, Hacking tools, Root, Debugger, Frida).
     * Returns a human-readable threat reason if detected, or null if clean.
     */
    fun checkSecurityThreat(context: Context): String? {
        // Priority 1: Check packet sniffers / Reqable first
        val sniffer = detectSnifferApp(context)
        if (sniffer != null) {
            return "Traffic sniffer detected: ($sniffer)"
        }

        val pm = context.packageManager

        // Priority 2: Check known dangerous hacking & cracking packages
        for (pkg in HACKING_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return "Suspicious/Hacking tool installed: $pkg"
            } catch (_: PackageManager.NameNotFoundException) {
            } catch (_: Exception) {}
        }

        // Priority 3: Scan installed application list for substring matches of hacking signatures
        try {
            val installed = pm.getInstalledPackages(0)
            val signatures = listOf("luckypatcher", "cheatengine", "gameguardian", "rootcloak", "appcloner")
            for (info in installed) {
                val name = info.packageName.lowercase()
                if (signatures.any { name.contains(it) }) {
                    return "Security risk tool detected: ${info.packageName}"
                }
            }
        } catch (_: Exception) {}

        // Priority 4: Check for root / SU binaries
        for (suPath in SU_BINARY_PATHS) {
            try {
                val file = File(suPath)
                if (file.exists() && file.canExecute()) {
                    return "Device rooted / SU binary detected at $suPath"
                }
            } catch (_: Exception) {}
        }

        // Priority 5: Check for active debugger attached (Anti-Debug)
        try {
            if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
                return "Unauthorized active debugger attached to process"
            }
        } catch (_: Exception) {}

        // Priority 6: Check for active Frida server on default port (27042)
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress("127.0.0.1", 27042), 150)
                return "Active Frida instrumentation server detected on port 27042"
            }
        } catch (_: Exception) {}

        // Priority 7: Check memory mappings for Frida/Xposed hooks
        try {
            val mapsFile = File("/proc/self/maps")
            if (mapsFile.exists()) {
                val content = mapsFile.readText()
                if (content.contains("frida-gadget", ignoreCase = true) ||
                    content.contains("libfrida", ignoreCase = true) ||
                    content.contains("libxposed", ignoreCase = true) ||
                    content.contains("xposed.bridge", ignoreCase = true)
                ) {
                    return "Active dynamic hooking library injected into app process"
                }
            }
        } catch (_: Exception) {}

        // Priority 8: Check for XposedBridge class via reflection
        try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            return "Xposed framework runtime active"
        } catch (_: ClassNotFoundException) {
        } catch (_: Exception) {}

        return null
    }
}
