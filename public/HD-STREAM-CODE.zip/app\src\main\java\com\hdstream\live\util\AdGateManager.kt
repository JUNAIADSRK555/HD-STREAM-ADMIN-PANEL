package com.hdstream.live.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.os.Parcel
import android.provider.Settings
import com.google.gson.Gson
import com.hdstream.live.model.AdConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object AdGateManager {
    private const val PREFS_NAME = "hd_ad_gate_prefs"
    private const val KEY_UNLOCKED_UNTIL = "ad_unlocked_until_timestamp"
    private const val KEY_CACHED_AD_CONFIG = "cached_ad_config_json"
    private const val KEY_DEVICE_AD_ID = "device_advertising_id"

    /**
     * Owner / Developer Identifiers for Ad-Bypass:
     * - Target Google Advertising ID (GAID): b6201d2c-896b-4315-a320-89324b00dfd0
     * - Target Android ID (ANDROID_ID): 25ae2ffdf6c18a90
     */
    const val OWNER_GOOGLE_AD_ID = "b6201d2c-896b-4315-a320-89324b00dfd0"
    const val OWNER_ANDROID_ID = "25ae2ffdf6c18a90"

    private val gson = Gson()

    @Volatile
    private var inMemoryAdId: String? = null

    @Volatile
    private var isOwnerCached: Boolean? = null

    /**
     * Reads Settings.Secure.ANDROID_ID safely.
     */
    fun getAndroidId(context: Context): String? {
        return try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)?.trim()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Reads Google Advertising ID via SharedPreferences cache, Settings.Secure, or Reflection.
     */
    fun readDeviceAdvertisingId(context: Context): String? {
        if (!inMemoryAdId.isNullOrBlank()) return inMemoryAdId

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_DEVICE_AD_ID, null)
        if (!saved.isNullOrBlank()) {
            inMemoryAdId = saved
            return saved
        }

        // 1. Direct Settings.Secure check
        val secureKeys = listOf("advertising_id", "google_advertising_id", "gaid", "advertising_id_client")
        for (key in secureKeys) {
            try {
                val value = Settings.Secure.getString(context.contentResolver, key)?.trim()
                if (!value.isNullOrBlank()) {
                    inMemoryAdId = value
                    prefs.edit().putString(KEY_DEVICE_AD_ID, value).apply()
                    return value
                }
            } catch (_: Exception) {}
        }

        // 2. Play Services AdvertisingIdClient via reflection (if present)
        try {
            val clientClass = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient")
            val getInfoMethod = clientClass.getMethod("getAdvertisingIdInfo", Context::class.java)
            val infoObj = getInfoMethod.invoke(null, context)
            if (infoObj != null) {
                val getIdMethod = infoObj.javaClass.getMethod("getId")
                val id = (getIdMethod.invoke(infoObj) as? String)?.trim()
                if (!id.isNullOrBlank()) {
                    inMemoryAdId = id
                    prefs.edit().putString(KEY_DEVICE_AD_ID, id).apply()
                    return id
                }
            }
        } catch (_: Exception) {}

        return null
    }

    /**
     * Asynchronously query Google Play Services Advertising ID Service (IPC)
     * on Dispatchers.IO to guarantee detection across all Android versions.
     */
    fun refreshAdvertisingIdAsync(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val gmsId = queryGmsAdvertisingId(context)?.trim()
                if (!gmsId.isNullOrBlank()) {
                    inMemoryAdId = gmsId
                    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    prefs.edit().putString(KEY_DEVICE_AD_ID, gmsId).apply()
                    if (gmsId.equals(OWNER_GOOGLE_AD_ID, ignoreCase = true) ||
                        gmsId.equals(OWNER_ANDROID_ID, ignoreCase = true)) {
                        isOwnerCached = true
                    }
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * Direct Binder IPC to Google Play Services IAdvertisingIdService
     */
    private fun queryGmsAdvertisingId(context: Context): String? {
        class AdvertisingConnection : ServiceConnection {
            private val retrieved = AtomicBoolean(false)
            private val queue = LinkedBlockingQueue<IBinder>(1)
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                try { if (service != null) queue.put(service) } catch (_: Exception) {}
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
            fun getBinder(): IBinder? {
                check(!retrieved.getAndSet(true)) { "Cannot get binder multiple times" }
                return queue.poll(2, TimeUnit.SECONDS)
            }
        }

        val connection = AdvertisingConnection()
        val intent = Intent("com.google.android.gms.ads.identifier.service.START").apply {
            setPackage("com.google.android.gms")
        }

        return try {
            if (context.bindService(intent, connection, Context.BIND_AUTO_CREATE)) {
                try {
                    val binder = connection.getBinder()
                    if (binder != null) {
                        val data = Parcel.obtain()
                        val reply = Parcel.obtain()
                        try {
                            data.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService")
                            binder.transact(1, data, reply, 0)
                            reply.readException()
                            reply.readString()
                        } finally {
                            reply.recycle()
                            data.recycle()
                        }
                    } else null
                } finally {
                    try { context.unbindService(connection) } catch (_: Exception) {}
                }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Robust check to determine if the current device is the owner/developer device:
     * - Matches Settings.Secure.ANDROID_ID against OWNER_ANDROID_ID (25ae2ffdf6c18a90)
     * - Matches Google Advertising ID against OWNER_GOOGLE_AD_ID (b6201d2c-896b-4315-a320-89324b00dfd0)
     * - Returns true to bypass ad screens and avoid invalid traffic
     */
    fun isOwnerDevice(context: Context): Boolean {
        if (isOwnerCached == true) return true

        // 1. Check Settings.Secure.ANDROID_ID
        val androidId = getAndroidId(context)
        if (!androidId.isNullOrBlank()) {
            if (androidId.equals(OWNER_ANDROID_ID, ignoreCase = true) ||
                androidId.equals(OWNER_GOOGLE_AD_ID, ignoreCase = true)) {
                isOwnerCached = true
                return true
            }
        }

        // 2. Check in-memory / cached advertising ID
        val currentAdId = readDeviceAdvertisingId(context)
        if (!currentAdId.isNullOrBlank()) {
            if (currentAdId.equals(OWNER_GOOGLE_AD_ID, ignoreCase = true) ||
                currentAdId.equals(OWNER_ANDROID_ID, ignoreCase = true)) {
                isOwnerCached = true
                return true
            }
        }

        // 3. Direct Settings.Secure keys
        val secureKeys = listOf("advertising_id", "google_advertising_id", "gaid")
        for (key in secureKeys) {
            try {
                val secVal = Settings.Secure.getString(context.contentResolver, key)?.trim()
                if (!secVal.isNullOrBlank()) {
                    if (secVal.equals(OWNER_GOOGLE_AD_ID, ignoreCase = true) ||
                        secVal.equals(OWNER_ANDROID_ID, ignoreCase = true)) {
                        isOwnerCached = true
                        return true
                    }
                }
            } catch (_: Exception) {}
        }

        // Pre-fetch GAID asynchronously in case IPC has not completed yet
        refreshAdvertisingIdAsync(context)

        return false
    }

    /**
     * Centralized ad-gate decision enforcement:
     * - Returns FALSE if Genuine TV (TV has no web browser / custom tabs)
     * - Returns FALSE if Owner device (bypasses ads for testing)
     * - Returns FALSE if adConfig is disabled or adUrl is empty
     * - Returns FALSE if user is within the active 12-hour unlock window
     * - Returns TRUE ONLY for customer mobile devices needing to view the 12-hour ad
     */
    fun shouldShowAdGate(context: Context, adConfig: AdConfig): Boolean {
        // 100% Ad-Free, Instant direct channel playback for ALL devices (Mobile + TV)
        return false
    }

    fun getUnlockedUntil(context: Context): Long {
        if (DeviceUtils.isGenuineTv(context) || isOwnerDevice(context)) {
            return Long.MAX_VALUE
        }
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.getLong(KEY_UNLOCKED_UNTIL, 0L)
        } catch (_: Exception) {
            0L
        }
    }

    fun isAdUnlocked(context: Context): Boolean {
        if (DeviceUtils.isGenuineTv(context) || isOwnerDevice(context)) {
            return true
        }
        return System.currentTimeMillis() < getUnlockedUntil(context)
    }

    fun setUnlockedUntil(context: Context, timestampMs: Long) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putLong(KEY_UNLOCKED_UNTIL, timestampMs).apply()
        } catch (_: Exception) {}
    }

    fun unlockForHours(context: Context, hours: Int) {
        val effectiveHours = if (hours > 0) hours else 12
        val unlockUntil = System.currentTimeMillis() + (effectiveHours.toLong() * 3600_000L)
        setUnlockedUntil(context, unlockUntil)
    }

    fun getCachedAdConfig(context: Context): AdConfig {
        return try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(KEY_CACHED_AD_CONFIG, null)
            if (!json.isNullOrBlank()) {
                val parsed = gson.fromJson(json, AdConfig::class.java)
                if (parsed != null && parsed.adUrl.isNotBlank()) {
                    parsed
                } else {
                    AdConfig()
                }
            } else {
                AdConfig()
            }
        } catch (_: Exception) {
            AdConfig()
        }
    }

    fun saveCachedAdConfig(context: Context, config: AdConfig) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = gson.toJson(config)
            prefs.edit().putString(KEY_CACHED_AD_CONFIG, json).apply()
        } catch (_: Exception) {}
    }
}
