package com.hdstream.live.ai

import com.hdstream.live.model.FeedCategory
import com.hdstream.live.model.LiveStreamEvent
import com.hdstream.live.model.MobileFeedResponse
import com.hdstream.live.player.M3uParser
import com.hdstream.live.player.ParsedChannelItem
import java.util.UUID

/**
 * Data model for messages in the HD STREAM AI Assistant chat.
 */
data class AiChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "user" or "ai"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val suggestedChannels: List<ParsedChannelItem> = emptyList(),
    val suggestedEvents: List<LiveStreamEvent> = emptyList(),
    val actionHint: String = ""
)

/**
 * High-Performance Dynamic AI Assistant for HD STREAM.
 * 100% Dynamic - ZERO hardcoded channels or matches.
 * Reads runtime live categories, channel lists (10,500+), live events, and app configuration.
 */
object AiAssistantManager {

    /**
     * Checks if a user's spoken or typed voice query is an AI conversational question.
     */
    fun isAiIntent(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.length < 3) return false
        val questionWords = listOf(
            "kahan", "kaise", "kyun", "kab", "kaun", "kitne", "hai kya", "batao",
            "how", "where", "why", "when", "which", "what", "who", "tell me",
            "help", "madad", "problem", "error", "buffering", "not working", "chal nahi",
            "kaise kare", "bataiye", "guide", "info", "kya hai"
        )
        return questionWords.any { q.contains(it) }
    }

    /**
     * Generates a rich, dynamic AI response based on real-time app feed and loaded channels.
     */
    fun processQuery(
        query: String,
        categoryName: String = "",
        currentChannels: List<ParsedChannelItem> = emptyList(),
        feedData: MobileFeedResponse? = null
    ): AiChatMessage {
        val q = query.trim()
        val qLower = q.lowercase()

        // 1. DYNAMIC MATCHES / LIVE CRICKET / SPORTS EVENTS INTENT
        val isMatchQuery = qLower.contains("match") || qLower.contains("cricket") || 
                           qLower.contains("live event") || qLower.contains("score") || 
                           qLower.contains("khel") || qLower.contains("football") ||
                           qLower.contains("tournament") || qLower.contains("kab hai")

        if (isMatchQuery) {
            val liveEvents = feedData?.liveEvents ?: emptyList()
            val upcomingEvents = feedData?.upcomingEvents ?: emptyList()

            if (liveEvents.isNotEmpty()) {
                val liveListSummary = liveEvents.take(5).joinToString("\n") { ev ->
                    val teams = if (ev.team1.name.isNotBlank() && ev.team2.name.isNotBlank()) {
                        "${ev.team1.name} vs ${ev.team2.name}"
                    } else ev.title
                    val sName = ev.streams.firstOrNull()?.title?.ifBlank { "Live Stream" } ?: "Live Stream"
                    "🔴 *${teams}* (${ev.status}) - $sName"
                }
                return AiChatMessage(
                    sender = "ai",
                    text = "Abhi filhal ${liveEvents.size} match LIVE chal rahe hain:\n\n$liveListSummary\n\nAap niche se seedhe click karke match watch kar sakte hain:",
                    suggestedEvents = liveEvents.take(5),
                    actionHint = "WATCH_MATCH"
                )
            } else if (upcomingEvents.isNotEmpty()) {
                val upListSummary = upcomingEvents.take(5).joinToString("\n") { ev ->
                    val teams = if (ev.team1.name.isNotBlank() && ev.team2.name.isNotBlank()) {
                        "${ev.team1.name} vs ${ev.team2.name}"
                    } else ev.title
                    "📅 *${teams}* - ${ev.startTime.ifBlank { "Upcoming" }}"
                }
                return AiChatMessage(
                    sender = "ai",
                    text = "Abhi koi match LIVE nahi hai, lekin ye aane wale matches scheduled hain:\n\n$upListSummary",
                    suggestedEvents = upcomingEvents.take(5),
                    actionHint = "UPCOMING_MATCH"
                )
            } else {
                return AiChatMessage(
                    sender = "ai",
                    text = "Currently live events feed update ho rahi hai. Jaise hi koi naya cricket ya sports match schedule hoga, wo automatically Live Events screen par aa jayega!"
                )
            }
        }

        // 2. DYNAMIC CHANNEL SEARCH INTENT (e.g. Sony Sab, Star Sports, Zee, Aaj Tak, News, Movies)
        // Clean query from filler words like "kahan hai", "channel", "dikhao", "lagao"
        val cleanChannelQuery = qLower
            .replace("kahan hai", "")
            .replace("dikhao", "")
            .replace("lagao", "")
            .replace("play karo", "")
            .replace("play", "")
            .replace("hai kya", "")
            .replace("chahiye", "")
            .replace("search", "")
            .replace("channel", "")
            .replace("tv", "")
            .trim()

        if (cleanChannelQuery.length >= 2 && currentChannels.isNotEmpty()) {
            val matchedChannels = currentChannels.filter { ch ->
                val titleLow = ch.title.lowercase()
                val catLow = ch.category.lowercase()
                (titleLow.contains(cleanChannelQuery) || catLow.contains(cleanChannelQuery)) &&
                !M3uParser.isAdultContent(ch.category, ch.title)
            }.take(8)

            if (matchedChannels.isNotEmpty()) {
                val chanNames = matchedChannels.take(4).joinToString(", ") { it.title }
                val catInfo = if (categoryName.isNotBlank()) " in $categoryName" else ""
                return AiChatMessage(
                    sender = "ai",
                    text = "Haan! Mujhe '$q' ke liye ${matchedChannels.size} channels mil gaye hain ($chanNames...):\n\nNiche se aap seedhe kisi bhi channel par click karke instant play kar sakte hain:",
                    suggestedChannels = matchedChannels,
                    actionHint = "PLAY_CHANNEL"
                )
            }
        }

        // 3. HOW TO ADD PLAYLIST / M3U / JSON INTENT
        if (qLower.contains("playlist") || qLower.contains("m3u") || qLower.contains("json") || qLower.contains("add") || qLower.contains("link")) {
            return AiChatMessage(
                sender = "ai",
                text = "📌 *App me Playlist ya Channel Link kaise add karein:*\n\n" +
                        "1. App ke top-bar par '+' (Add Stream) icon par click karein.\n" +
                        "2. Apna M3U link, JSON link ya Stalker Portal URL paste karein.\n" +
                        "3. '⚡ Fetch & Parse' button dabayein.\n" +
                        "4. Channels load hote hi '+ Add All to App Feed' par click karein aur aaram se enjoy karein!"
            )
        }

        // 4. STREAM BUFFERING / BLACK SCREEN / PLAYBACK ISSUE INTENT
        if (qLower.contains("buffering") || qLower.contains("chal nahi") || qLower.contains("error") || qLower.contains("play nahi") || qLower.contains("black screen") || qLower.contains("slow")) {
            return AiChatMessage(
                sender = "ai",
                text = "⚡ *Agar stream play na ho ya buffering ho to ye karein:*\n\n" +
                        "1. Top-right me Refresh (⟳) icon dabayein taaki fresh live token generate ho sake.\n" +
                        "2. Apna internet connection check karein (Live HD streams ke liye 5-10 Mbps zaroori hai).\n" +
                        "3. Agar match me multiple servers hain (Server 1 / Server 2), to doosra server choose karein.\n" +
                        "4. Stalker portal channels ke dynamic links automatically refresh hote hain."
            )
        }

        // 5. STALKER PORTAL / TATA SKY INQUIRY INTENT
        if (qLower.contains("stalker") || qLower.contains("portal") || qLower.contains("tatasky") || qLower.contains("tata sky") || qLower.contains("mac")) {
            val totalCount = currentChannels.size
            val countInfo = if (totalCount > 0) "Is category me total $totalCount channels loaded hain." else "Isme 10,500+ live channels available hain."
            return AiChatMessage(
                sender = "ai",
                text = "📡 *Tata Sky Stalker Portal Integration Active Hai!*\n\n" +
                        "• Portal URL: http://play.tatasky.xyz/stalker_portal/c/\n" +
                        "• MAC: 00:1A:79:82:5F:01\n" +
                        "• $countInfo\n" +
                        "• Kisi bhi channel par click karne par app direct live playable .m3u8 stream generate karke play karta hai."
            )
        }

        // 6. TOTAL CHANNELS / CATEGORIES COUNT INTENT
        if (qLower.contains("kitne") || qLower.contains("count") || qLower.contains("total") || qLower.contains("how many")) {
            val catCount = feedData?.categories?.size ?: 0
            val channelCount = currentChannels.size
            return AiChatMessage(
                sender = "ai",
                text = "📊 *HD STREAM Live Stats:*\n\n" +
                        "• Current Category ($categoryName): $channelCount channels\n" +
                        "• Total Categories in App: $catCount categories\n" +
                        "• Live Matches Feed: ${feedData?.liveEvents?.size ?: 0} Live matches"
            )
        }

        // 7. GENERAL / DYNAMIC ASSISTANCE FALLBACK (Zero hardcoded, uses live state)
        val activeCats = feedData?.categories?.take(6)?.joinToString(", ") { it.displayName } ?: "Live TV, Sports"
        return AiChatMessage(
            sender = "ai",
            text = "Mai HD STREAM AI Assistant hoon. Mai aapko kisi bhi channel, live match ya category ke baare me bata sakta hoon.\n\n" +
                    "Aap mujhse puch sakte hain:\n" +
                    "• 'Sony Sab' ya 'Star Sports' (channels dhundne ke liye)\n" +
                    "• 'Live cricket match' (aaj ke matches janne ke liye)\n" +
                    "• 'Playlist kaise add karein'\n" +
                    "• 'Stream play problem fix'\n\n" +
                    "Available categories: $activeCats."
        )
    }
}
