package com.hdstream.live

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.hdstream.live.model.StreamSource
import com.hdstream.live.player.ExoPlayerHelper
import com.hdstream.live.player.ParsedChannelItem
import com.hdstream.live.ui.screens.AdGateScreen
import com.hdstream.live.ui.screens.HomeScreen
import com.hdstream.live.ui.screens.PlayerScreen
import com.hdstream.live.ui.theme.HDStreamTheme
import com.hdstream.live.util.AdGateManager
import com.hdstream.live.util.DeviceUtils
import com.hdstream.live.util.SecurityUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {

    companion object {
        // High-priority TV Remote key listener for active PlayerScreen
        var playerKeyEventListener: ((KeyEvent) -> Boolean)? = null
    }

    private val activeThreatState = MutableStateFlow<String?>(null)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Give active Video Player full priority over TV remote D-Pad, OK, and media keys
        val listener = playerKeyEventListener
        if (listener != null && listener(event)) {
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android TV / Fire TV Stick / Mi Box Environment Detection
        if (DeviceUtils.isTv(this)) {
            try {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } catch (_: Exception) {}
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Keep Screen On during playback
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val app = application as HDStreamApp
        val streamRepository = app.streamRepository

        // Firebase Analytics Event
        try {
            val isFirstLaunch = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .getBoolean("is_first_launch", true)
            if (isFirstLaunch) {
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("is_first_launch", false)
                    .apply()
                val installBundle = Bundle().apply {
                    putString("app_version", "3.4.38")
                    putString("device_model", Build.MODEL)
                }
                app.firebaseAnalytics?.logEvent("apk_install_success", installBundle)
            }
            val activeBundle = Bundle().apply {
                putString("device_model", Build.MODEL)
                putString("os_version", "Android ${Build.VERSION.RELEASE}")
            }
            app.firebaseAnalytics?.logEvent("active_device_ping", activeBundle)
        } catch (_: Exception) {}

        // Pre-fetch Google Advertising ID for owner device bypass
        AdGateManager.refreshAdvertisingIdAsync(this)

        // Sniffer & Security check at launch
        val initialSniffer = SecurityUtils.detectSnifferApp(this)
        activeThreatState.value = initialSniffer ?: SecurityUtils.checkSecurityThreat(this)

        setContent {
            HDStreamTheme {
                val activeThreat by activeThreatState.collectAsState()
                val context = LocalContext.current
                val lifecycleOwner = LocalLifecycleOwner.current

                // Check security threat on every resume (catches user launching Reqable in background)
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            val snifferOnResume = SecurityUtils.detectSnifferApp(context)
                            val threatOnResume = snifferOnResume ?: SecurityUtils.checkSecurityThreat(context)
                            activeThreatState.value = threatOnResume
                            if (threatOnResume != null) {
                                ExoPlayerHelper.pauseActivePlayer()
                            }
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
                }

                var pendingStreamSource by remember { mutableStateOf<StreamSource?>(null) }
                var pendingCategoryChannels by remember { mutableStateOf<List<ParsedChannelItem>>(emptyList()) }
                var showAdGate by remember { mutableStateOf(false) }

                var activeStreamSource by remember { mutableStateOf<StreamSource?>(null) }
                var activeCategoryChannels by remember { mutableStateOf<List<ParsedChannelItem>>(emptyList()) }

                val adConfig by streamRepository.adConfigState.collectAsState()

                fun handlePlayRequest(source: StreamSource, channels: List<ParsedChannelItem>) {
                    try {
                        ExoPlayerHelper.releaseActivePlayer()
                        activeStreamSource = source
                        activeCategoryChannels = channels
                    } catch (_: Exception) {}
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(
                        streamRepository = streamRepository,
                        isPlayerOpen = activeStreamSource != null,
                        onPlayStreamSource = { streamSource, channels ->
                            handlePlayRequest(streamSource, channels)
                        }
                    )

                    if (showAdGate) {
                        AdGateScreen(
                            adConfig = adConfig,
                            onAdCompleted = {
                                showAdGate = false
                                val s = pendingStreamSource
                                val chs = pendingCategoryChannels
                                pendingStreamSource = null
                                pendingCategoryChannels = emptyList()
                                if (s != null) {
                                    ExoPlayerHelper.releaseActivePlayer()
                                    activeStreamSource = s
                                    activeCategoryChannels = chs
                                }
                            },
                            onBack = {
                                showAdGate = false
                                pendingStreamSource = null
                                pendingCategoryChannels = emptyList()
                            }
                        )
                    }

                    if (activeStreamSource != null) {
                        PlayerScreen(
                            streamSource = activeStreamSource!!,
                            categoryChannels = activeCategoryChannels,
                            onSelectChannel = { newSource ->
                                try {
                                    ExoPlayerHelper.releaseActivePlayer()
                                    activeStreamSource = newSource
                                } catch (_: Exception) {}
                            },
                            streamRepository = streamRepository,
                            onNavigateBack = {
                                ExoPlayerHelper.releaseActivePlayer()
                                activeStreamSource = null
                            }
                        )
                    }

                    // Non-Dismissible Blocking Dialog if Reqable or Sniffer is Detected
                    activeThreat?.let { threat ->
                        val detectedAppName = when {
                            threat.contains("Reqable", ignoreCase = true) -> "Reqable"
                            threat.contains("HttpCanary", ignoreCase = true) -> "HttpCanary"
                            threat.contains("Packet Capture", ignoreCase = true) -> "Packet Capture"
                            threat.contains("HTTP Toolkit", ignoreCase = true) -> "HTTP Toolkit"
                            threat.contains("Proxyman", ignoreCase = true) -> "Proxyman"
                            else -> "Reqable"
                        }

                        SnifferBlockDialog(
                            detectedAppName = detectedAppName,
                            onExit = {
                                activeThreatState.value = null
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Immediate sniffer check on activity resume
        val sniffer = SecurityUtils.detectSnifferApp(this)
        val threat = sniffer ?: SecurityUtils.checkSecurityThreat(this)
        activeThreatState.value = threat
        if (threat != null) {
            ExoPlayerHelper.pauseActivePlayer()
        }

        if (DeviceUtils.isTv(this)) {
            try {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } catch (_: Exception) {}
        }
    }

    override fun onPause() {
        super.onPause()
        ExoPlayerHelper.pauseActivePlayer()
    }

    override fun onStop() {
        super.onStop()
        ExoPlayerHelper.pauseActivePlayer()
        ExoPlayerHelper.releaseActivePlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        ExoPlayerHelper.releaseActivePlayer()
    }
}

/**
 * Strict, Non-Dismissible Dialog for Reqable & Traffic Sniffer blocking.
 * Cannot be cancelled by back press or tapping outside.
 */
@Composable
private fun SnifferBlockDialog(detectedAppName: String, onExit: () -> Unit) {
    // Intercept back key and enforce exit
    BackHandler(enabled = true) {
        onExit()
    }

    Dialog(
        onDismissRequest = { /* Strictly non-dismissible */ },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xF00A0A0F))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141522)),
                border = BorderStroke(1.5.dp, Color(0xFFE50914)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE50914).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Alert",
                            tint = Color(0xFFE50914),
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    Text(
                        text = "If you want to continue our app then uninstall ( $detectedAppName )",
                        color = Color(0xFFFFB74D),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = 23.sp
                    )

                    Text(
                        text = "Traffic inspection and packet sniffer applications are strictly prohibited while running HD STREAM.",
                        color = Color(0xFFBBBBBB),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = onExit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50914)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "EXIT",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
